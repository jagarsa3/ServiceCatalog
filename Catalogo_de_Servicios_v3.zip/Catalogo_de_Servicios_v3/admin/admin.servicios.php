<?php 

defined('_JEXEC') or die('Restricted access');

//require_once(JApplicationHelper::getPath( 'admin_html' ));

require_once(JPATH_COMPONENT.DS.'controller.php');

	$class = 'serviciosController';

	$controller = new $class();

	$controller->execute(JRequest::getCmd('task', 'display'));

	$controller->redirect();


?>