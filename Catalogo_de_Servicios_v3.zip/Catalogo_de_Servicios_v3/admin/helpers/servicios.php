<?php

class TreeNodeHelper{
var $parent_id;
var $last;
var $id;
var $nombre_es;
var $childs = Array();
var $level;

function __construct(){
$parent_id=null;
$last=0;
$id=null;
$nombre_es=null;
$childs[]=null;
$elem[]=null;
$level=0;
}




public function getTreeList(& $lists_const){
$cat = new TreeNodeHelper();
$main_cat = $cat->getMainCategorias();

$cid = JRequest::getVar('cid', 0, '', 'int');
$id= $cat->getCategorias($cid);
$main_id=& $cat->getMainParent($id, $list);
$all_parent=& $cat->getChildsParents($id, $lists_const);
echo ('<pre>');
//print_r($all_parent);
echo ('</pre>');
$limit = JRequest::getVar('limit', 0, '', 'int');
$limitstart = JRequest::getVar('limitstart', 0, '', 'int');



foreach($main_cat as $cat){

	if($cat->id==$main_id->id){
	$cat = new TreeNodeHelper();
	$cat->getSortList($main_id,$lists_const,$id, $all_parent);			
	}
	else{
		$nombre_es = JHTML::link('index.php?option=com_servicios&task=show&cid='.$cat->id.'&limit='.$limit.'&limitstart='.$limitstart, $cat->nombre_es);
		?><li class="level0"><?php
		echo ($nombre_es);
		?></li><?php
	}
}

}


public function getSortList(& $list,& $lists_const,& $main_id,& $all_parent,& $sprawdzone=Array()){

	$liczba = count($lists_const);
	$li_parent= count($all_parent);



				$flaga=0;
				for($l=0;$l<count($sprawdzone);$l++){
					if($sprawdzone[$l]==$list->id){
						$flaga=1;
					}
				}
			
			if($flaga==0){
			$sprawdzone[]=$list->id;

			$this->parent_id = $list->parent_id;
			$this->id = $list->id;
			$this->nombre_es = $list->nombre_es;
			$limit		= JRequest::getVar('limit', 0, '', 'int');
			$limitstart	= 0;
		
			$this->nombre_es = JHTML::link('index.php?option=com_servicios&task=show&cid='.$list->id.'&limit='.$limit.'&limitstart='.$limitstart, $this->nombre_es);
			$checked = JHTML::_('grid.id', ++$i, $this->id );
			$published=JHTML::_('grid.published', $this, $i);
			$i++;
			?>
    <li class="level0">
        <?php echo $this->nombre_es; ?>
    </li>
<?php
			
			
				   for($i=0; $i<$liczba;$i++ ){
					if($lists_const[$i]->parent_id==$list->id){		
						$flaga=0;
						for($j=0;$j<$li_parent;$j++){
							if($lists_const[$i]->id==$all_parent[$j]){
								$flaga=1;
							}
						}
						if($flaga==1){
						$child=new TreeNodeHelper();
						$child->id=$lists_const[$i]->id;
						$child->parent_id=$lists_const[$i]->parent_id;
						$child->level=$list->level+1;
						$child->grant_id=$list->id;
						$new_nombre_es=$lists_const[$i]->nombre_es;
							for($lev=0;$lev<$child->level;$lev++){
								$new_nombre_es="&nbsp;&nbsp;&nbsp;&nbsp;".$new_nombre_es;
							}
								
						$child->nombre_es=$new_nombre_es;

							$this->childs[]=$child;						
							
							
							$this->getList($this->childs,$lists_const,$main_id,$all_parent,$sprawdzone);
							
					}}
				}	
				
			}

	return(null);		
}


public function getList(& $lists,& $lists_const,& $main_id,& $all_parent,& $sprawdzone=Array()){

	$liczba = count($lists_const);
		$li_parent= count($all_parent);
	foreach($lists as $list){

				$flaga=0;
				for($l=0;$l<count($sprawdzone);$l++){
					if($sprawdzone[$l]==$list->id){
						$flaga=1;
					}
				}
			
			if($flaga==0){
			$sprawdzone[]=$list->id;

			$this->parent_id = $list->parent_id;
			$this->id = $list->id;
			$this->nombre_es = $list->nombre_es;
			$this->level= $list->level;
			$limit		= JRequest::getVar('limit', 0, '', 'int');
			$limitstart	= 0;
		
			$this->nombre_es = JHTML::link('index.php?option=com_servicios&task=show&cid='.$list->id.'&limit='.$limit.'&limitstart='.$limitstart, $this->nombre_es);
			$checked = JHTML::_('grid.id', ++$i, $this->id );
			$published=JHTML::_('grid.published', $this, $i);
			$i++;

			?>

    <li class="level<?php echo $this->level; ?>" >
        <?php echo $this->nombre_es; ?>
    </li>
<?php
			
			
				   for($i=0; $i<$liczba;$i++ ){
					if($lists_const[$i]->parent_id==$list->id){	
						$flaga=0;

						for($j=0;$j<$li_parent;$j++){
							if($lists_const[$i]->id==$all_parent[$j]){
								$flaga=1;
							}
						}
					
						if($flaga==1){
						$child=new TreeNodeHelper();
//							echo($lists_const[$i]->id);
						$child->id=$lists_const[$i]->id;
						$child->parent_id=$lists_const[$i]->parent_id;
						$child->level=$list->level+1;
						$child->grant_id=$list->id;
						$new_nombre_es=$lists_const[$i]->nombre_es;
							for($lev=0;$lev<$child->level;$lev++){
								$new_nombre_es="&nbsp;&nbsp;&nbsp;&nbsp;".$new_nombre_es;
							}
								
						$child->nombre_es=$new_nombre_es;

			
						if($list->parent_id!=$main_id->id){
							$this->childs[]=$child;														
							$this->getList($this->childs,$lists_const,$main_id,$all_parent,$sprawdzone);
							}

					}}
				}	
				
			}
	}	
	return(null);		
}


function getMainParent(& $id, & $list){

	if($id->parent_id==0){
		$list = $id;
		

	}
	else{
		$new_id = $id->parent_id;
		$obj = new TreeNodeHelper();
		$new_id_ob=$obj->getCategorias($new_id);
		$obj->getMainParent($new_id_ob,& $list);
	}

		return $list;	
}

function getChildsParents(& $id,& $lists){
	$child_list=Array();
	foreach($lists as $list){
		if($list->parent_id==$id->id){
			$child_list[]=$list->id;
		}
	}
	$all_list=Array();
	$parent_list=Array();
	$obj = new TreeNodeHelper();
	$parent_list=$obj->getAllParent(& $id, & $all_list,$lists);
	$all_list=array_merge_recursive ($parent_list,$child_list);
	return($all_list);
}

function getAllParent(& $id, & $all_list=Array(),& $lists){

	if($id->parent_id==0){
		//$all_list[] = $id->id;
		
		

	}
	else{
		$new_id = $id->parent_id;
		$obj = new TreeNodeHelper();
		$new_id_ob=$obj->getCategorias($new_id);
		$siblings=$obj->getParent($id,$lists);
//		print_r($siblings);
		$all_list[]=$id->id;
		$all_list=array_merge_recursive ($all_list,$siblings);
		$obj->getAllParent($new_id_ob,& $all_list, $lists);
	}
		
		
		return $all_list;	
}

function getParent(& $id, & $lists){
	$result=Array();
	foreach($lists as $list){
		if($list->parent_id==$id->parent_id){
			$result[]=$list->id;
		}
	}
	return $result;
}

public function getCategorias($id){

		$db= &JFactory::getDBO();
		$query = "SELECT * FROM #__categorias WHERE id =".$id;
		$db->setQuery($query);
		$category=$db->loadObject();
		return $categoria;
	
}

public function getHardware($id){

		$db= &JFactory::getDBO();
		$query = "SELECT * FROM #__hardware WHERE id =".$id;
		$db->setQuery($query);
		$hardware=$db->loadObject();
		return $hardware;

}

public function getSoftware($id){

		$db= &JFactory::getDBO();
		$query = "SELECT * FROM #__software WHERE id =".$id;
		$db->setQuery($query);
		$software=$db->loadObject();
		return $software;

}

public function getHost($id){

		$db= &JFactory::getDBO();
		$query = "SELECT * FROM #__host WHERE id =".$id;
		$db->setQuery($query);
		$host=$db->loadObject();
		return $host;

}

public function getResponsable($id){

		$db= &JFactory::getDBO();
		$query = "SELECT * FROM #__responsable WHERE id =".$id;
		$db->setQuery($query);
		$responsable=$db->loadObject();
		return $responsable;

}

public function getDocumentos($id){

		$db= &JFactory::getDBO();
		$query = "SELECT * FROM #__tiposDoc WHERE Id =".$id;
		$db->setQuery($query);
		$documento=$db->loadObject();
		return $documento;

}

public function getAvisos($id){

		$db= &JFactory::getDBO();
		$query = "SELECT * FROM #__avisos WHERE Id =".$id;
		$db->setQuery($query);
		$avisos=$db->loadObject();
		return $avisos;

}

public function getRelacionados($id){

		$db= &JFactory::getDBO();
		$query = "SELECT * FROM #__relacionados WHERE Id =".$id;
		$db->setQuery($query);
		$relacionados=$db->loadObject();
		return $relacionados;

}


public function getMainCategorias(){
		
		$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__categorias WHERE parent_id=0";
			$db->setQuery($query);
			$main_categorias=$db->loadObjectList();
		

		return $main_categorias;
	}

}

class serviciosModelCategorias{
	
	var $_categorias;
        var $_hardware;
        var $_software;
        var $_host;
        var $_responsable;
        var $_documento;
        var $_avisos;
        var $_relacionados;
	
	function getCategorias(){
		
		$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__categorias";
			$db->setQuery($query);
			$_categorias=$db->loadObjectList();
		
		return $_categorias;
	}

        function getHardware(){

		$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__hardware";
			$db->setQuery($query);
			$_hardware=$db->loadObjectList();

		return $_hardware;
	}

        function getSoftware(){

		$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__software";
			$db->setQuery($query);
			$_software=$db->loadObjectList();

		return $_software;
	}


        function getHost(){

		$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__host";
			$db->setQuery($query);
			$_host=$db->loadObjectList();

		return $_host;
	}

        function getResponsable(){

		$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__responsable";
			$db->setQuery($query);
			$_responsable=$db->loadObjectList();

		return $_responsable;
	}

        function getDocumentos(){

		$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__tiposDoc";
			$db->setQuery($query);
			$_documento=$db->loadObjectList();

		return $_documento;
	}

        function getAvisos(){

		$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__tiposDoc";
			$db->setQuery($query);
			$_documento=$db->loadObjectList();

		return $_documento;
	}

        function getRelacionados(){

		$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__relacionados";
			$db->setQuery($query);
			$_relacionados=$db->loadObjectList();

		return $_relacionados;
	}
}
?>
