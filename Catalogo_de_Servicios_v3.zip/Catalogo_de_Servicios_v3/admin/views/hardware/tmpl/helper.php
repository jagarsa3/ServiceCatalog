<?php

class TreeNodeHelper{

var $Id;
var $NumCPV;
var $MarcaModelo;
var $checked;

function __construct(){

$Id=null;
$NumCPV=null;
$MarcaModelo=null;
$checked=null;
}



public function getSortList(& $lists,& $lists_const,& $ii,& $obj=Array(),& $sprawdzone=Array()){
	$liczba = count($lists_const);
	foreach($lists as $list){
				$flaga=0;
 				for($l=0;$l<count($sprawdzone);$l++)
 				{
 					if($sprawdzone[$l]==$list->Id)
 					{
 						$flaga=1;

					}

 				}
			
			if($flaga==0){
			$sprawdzone[]=$list->Id;
			//print_r($obj);
			$this->Id = $list->Id;
			$this->NumCPV = $list->NumCPV;
			$this->MarcaModelo = $list->MarcaModelo;
			$this->checked = $list->checked;	
			$this->NumCPV = JHTML::link('index.php?option=com_servicios&task=edit_hardware&cid[]='.$this->Id, $this->NumCPV);
			$checked = JHTML::_('grid.id', $ii, $list->Id );
			$ii++;


			?>
        <tr>
            <td align="center">
                <?php echo $checked; ?>
            </td>
            <td align="center">
                <?php echo $this->Id; ?>
            </td>
            <td align="center">
                <?php echo $this->NumCPV; ?>
            </td>
            <td align="center">
                <?php echo $this->MarcaModelo; ?>
            </td>
        </tr>
			<?php	
				
			}
	}
				
	return(null);		
}



}

?>

