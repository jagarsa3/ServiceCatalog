<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');



class serviciosViewedit_hardware extends JView

{

	function display($tpl = null)

	{

		  $model =& $this->getModel();
		  $nl = $model->getHard();
		  $cats = $model->getHardware();

    

		$this->assignRef('nl',$nl);
		$this->assignRef('list',$cats);

		

		JRequest::setVar('hidemainmenu',1);

		

		JToolBarHelper::title( JText::_('HARDWARE'), 'generic.png');

		JToolBarHelper::save('saveHardware', JText::_('SAVE'), 'save.png');

		JToolBarHelper::apply('applyHardware', JText::_('APPLY'), 'apply.png');

		JToolBarHelper::cancel('cancelHardware', JText::_('CANCEL'), 'cancel.png');


		parent::display($tpl);

	}

}



