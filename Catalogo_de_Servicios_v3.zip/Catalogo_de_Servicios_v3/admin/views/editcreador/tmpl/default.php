<?php
defined ('_JEXEC') or die('Restricted access');

?>
<form action="index.php" method="post" name="adminForm" id="adminForm">
    <fieldset class="adminform">
    <legend>
        <?php echo JText::_('DETAIL'); ?>
    </legend>
    <table class="admintable">
        <tr>
            <td width="100" align="right" class="key">
                <?php echo JText::_('CREADOR_NOMBRE');?>
            </td>
            <td>
                <input class="text_area" type="text" name="nombre" id="nombre" size="50" maxlength="250" value="<?php echo $this->nl->nombre; ?>" />
            </td>
        </tr>
		
    </table>

	<input type="hidden" name="id" value="<?php echo $this->nl->id; ?>" />
	<input type="hidden" name="option" value="<?php echo $option;?>" />
	<input type="hidden" name="task" value="creadores" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="catid" value="<?php echo JRequest::getVar('catid'); ?>" />
	<input type="hidden" name="ordering" value="<?php echo $this->nl->ordering; ?>" />

</form>
<script language="javascript" type="text/javascript">

	function submitbutton(pressbutton) {
		var form = document.adminForm;
		if (pressbutton == 'cancelCreador') {
			submitform( pressbutton );
			return;
		}

		// do field validation
		if (form.name.value == ""){
			alert( "<?php echo JText::_( 'ALERT_CREADOR_NOMBRE', true ); ?>" );
		} 
		else  {
			submitform( pressbutton );
		}
	}
</script>