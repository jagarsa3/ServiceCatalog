<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

class serviciosVieweditcreador extends JView

{

	function display($tpl = null)
	{

		$model =& $this->getModel();
		$nl = $model->getCreadores();
		$this->assignRef('nl',$nl);	
		

		JToolBarHelper::title( JText::_('Edit creadores'), 'generic.png');

		JToolBarHelper::save('saveCreador', JText::_('SAVE'), 'save.png');

		JToolBarHelper::apply('applyCreador', JText::_('APPLY'), 'apply.png');

		JToolBarHelper::cancel('cancelCreador', JText::_('CANCEL'), 'cancel.png');
		
		parent::display($tpl);		
		
	}

}
?>
