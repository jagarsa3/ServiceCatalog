<?php

defined ('_JEXEC') or die('Restricted access');

$editor =& JFactory::getEditor();

$getTexts = $editor->getContent('descripcion_es');

jimport('joomla.media.images');

$document=& JFactory::getDocument();
$js = JPATH_BASE.'/components/com_servicios/images/Moo.Form.js';
$document->addScript($js);
JHTML::_( 'behavior.Mootools' );
require_once(dirname(__FILE__).DS.'helper.php');
$sort_list=$this->list;

$_list = new TreeNodeHelper();


$db =& JFactory::getDBO();
$query = "SELECT * FROM #__servicios";
$db->setQuery( $query);
$rowserver = $db->loadObjectList();


$dbhardware =& JFactory::getDBO();
$queryhardware = "SELECT * FROM #__hardware";
$dbhardware->setQuery( $queryhardware);
$rowserverhardware = $dbhardware->loadObjectList();


$dbsoftware =& JFactory::getDBO();
$querysoftware = "SELECT * FROM #__software";
$dbsoftware->setQuery( $querysoftware);
$rowserversoftware = $dbsoftware->loadObjectList();

$dbhost =& JFactory::getDBO();
$queryhost = "SELECT * FROM #__host";
$dbhost->setQuery( $queryhost);
$rowserverhost = $dbhost->loadObjectList();

$dbresponsable =& JFactory::getDBO();
$queryresponsable = "SELECT * FROM #__responsable";
$dbresponsable->setQuery( $queryresponsable);
$rowserverresponsable = $dbresponsable->loadObjectList();

$dbdocumentos =& JFactory::getDBO();
$querydocumentos = "SELECT * FROM #__tiposDoc";
$dbdocumentos->setQuery( $querydocumentos);
$rowserverdocumentos = $dbdocumentos->loadObjectList();

$id_busqueda =  $this->nl->id;


$dbavisos =& JFactory::getDBO();
$queryavisos = "SELECT * FROM #__avisos WHERE IdServicio='$id_busqueda'";
$dbavisos->setQuery( $queryavisos);
$rowserveravisos= $dbavisos->loadRow();

?>
<form action="index.php" method="post" name="adminForm" id="adminForm"  enctype='multipart/form-data'>
    <fieldset class="adminform">
    	<center><img src='<?php echo JURI::base() ?>/components/com_servicios/images/long_loader.gif' alt='LOADING' style='display: none;' id='upload_loading' /><div id="alercik"></div></center>
		<legend>
            <?php echo JText::_('DETAIL'); ?>
        </legend>
        <table class="admintable">
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('NOMBRE_ES');?>
                </td>
                <td>
                    <input class="text_area" type="text" name="nombre_es" id="nombre_es" size="50" maxlength="250" value="<?php echo $this->nl->nombre_es; ?>" />		   
                </td>
            </tr>
	    <tr>
		  <td width="100" align="right" class="key">
                    <?php echo JText::_('NOMBRE_VAL');?>
		  </td>
		  <td>
                    <input class="text_area" type="text" name="nombre_val" id="nombre_es" size="50" maxlength="250" value="<?php echo $this->nl->nombre_val; ?>" />		   
		  </td>
	    </tr>
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('PARENT_CATEGORY');?>
                </td>
                <td>
                    <?php
							$optionss = array();
							$optionss=$_list->getSortList($sort_list,$sort_list);
							$main_tab = array();
							$main_tab[0]= JHTML::_('select.option', '0', JText::_('UNCATEGORIZED'));
							$options = array();
							$options = array_merge_recursive ($main_tab, $optionss);							
							echo JHTML::_('select.genericlist', $options, 'idCategoria', null, 'value', 'text', $this->nl->idCategoria);

						?>
                </td> 
            </tr>
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('SITIO_DESACTIVADO');?>
                </td>
                <td>
                    <input type="radio" name="disponibilidad" id="disponibilidad" value="1" <?php if($this->nl->disponibilidad=='1') echo "checked";?>/>ON
                    <input type="radio" name="disponibilidad" id="disponibilidad" value="0" <?php if($this->nl->disponibilidad=='0') echo "checked";?>/>OFF
                </td>
            </tr>
                 <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('AVISO');?>
                </td>
                <td>
                    <input type="radio" name="avisos" id="avisos" value="1"  onChange="muestra_oculta('uploader9',true);" <?php if($rowserveravisos) echo "checked";?>/>ON
                    <input type="radio" name="avisos" id="avisos" value="0"  onChange="muestra_oculta('uploader9',false);" <?php if(!$rowserveravisos) echo "checked";?> />OFF
                    <div id="uploader9" <?php if(!$rowserveravisos){ echo"style='display:none;'";}?>>
                            <br/><br/>
                           <?php $text = JText::_('Editar_Avisos');
                           if($rowserveravisos){
                            $text_ = JHTML::link('index.php?option=com_servicios&task=edit_avisos&cidA[]='.$this->nl->id.'&cid[]='.$rowserveravisos[0],$text);
                           }
                           else $text_ = JHTML::link('index.php?option=com_servicios&task=edit_avisos&cidA[]='.$this->nl->id,$text);
                           echo $text_;?>
                           <br/>
                    </div>
                </td>
            </tr>
            <tr>
               <td width="100" align="right" class="key">
                    <?php echo JText::_('DEPENDENCIAS_EXISTENTES');?>
                </td>
                <td>
                    <?php
                        $db_depend =& JFactory::getDBO();
                        $id_busqueda =  $this->nl->id;
                        $query_depend = "SELECT * FROM #__dependencias WHERE IdServHijo='$id_busqueda'";
                        $db_depend->setQuery( $query_depend);
                        $rowserver_depend = $db_depend->loadObjectList();
                        foreach ( $rowserver_depend as $row_depend ) {
                            $db_servicio =& JFactory::getDBO();
                            $query_servicio = "SELECT * FROM #__servicios WHERE id='$row_depend->IdServPadre'";
                            $db_servicio->setQuery( $query_servicio);
                            $rowserver_servicio = $db_servicio->loadRow();
                           ?>
                           <input type="text" id="<?php echo $row_depend->IdServPadre;?>" value="<?php
                           if(!$rowserver_servicio[0])
                           {
                               echo 'Sin Dependencias';
                           }
                           else
                                echo $rowserver_servicio[1];
                            ?>" readonly/>
                           <input type="checkbox" name="usun_depend[]" id="usun_depend[]" value="<?php echo $row_depend->IdServPadre; ?>"/>
                           <?php echo JText::_('CHECK_TO_DELETE'); ?>
                           <br/>

                    <?php

                        }
                    ?>

                </td>
            </tr>
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('DEPENDENCIAS');?>
                </td>
                <td>
                    <?php
                                                        $cuenta_dependencia=0;
                                                        $servicios[$cuenta_dependencia] = array('value' => '0','text'=>JText::_('Sin_Dependencias'));
                                                        $serviciosjava[$cuenta_dependencia] = JText::_('Sin_Dependencias');
                                                        $serviciosid[0] = '0';
							foreach ( $rowserver as $row ) {
                                                            $cuenta_dependencia++;
                                                            $servicios[$cuenta_dependencia] = array('value' => $row->id,'text'=>$row->nombre_es);
                                                            $serviciosjava[$cuenta_dependencia] = $row->nombre_es;
                                                            $serviciosid[$cuenta_dependencia] = $row->id;
                                                              
                                                        }
                                                        $rowServicios = & JTable::getInstance('dependencias', 'table');
                                                        //echo $rowServicios->IdServHijo;
                                                        ?>
                                                        
                                                        <?php
                                                        //echo JHTML::_('select.genericList',
                                                         //       $servicios,'servicios','class="inputbox" '.' ', 'value','text',
                                                          //      $rowServicios->IdServHijo);

						?>
                                        <div id="uploader3">

                                        <select name="servicios_depende[]" >
                                        <option selected value="0"> <?php echo $serviciosjava[0];?> </option>
					<?php
					foreach ( $rowserver as $row )
					{
					?><option value="<?=$row->id?>"><?php echo $row->nombre_es; ?></option><?php
					}
					?>
					</select>

					</div><br/>
                    <a href="#" onclick="addDependencia(); return false;" ><?php echo JText::_('ADD_DEPENDENCIA')?></a>
                </td>
            </tr>

            <tr>
               <td width="100" align="right" class="key">
                    <?php echo JText::_('RELACIONES_EXISTENTES');?>
                </td>
                <td>
                    <?php
                        $db_depend =& JFactory::getDBO();
                        $id_busqueda =  $this->nl->id;
                        $query_depend = "SELECT * FROM #__relacionados WHERE Id_Serv_A='$id_busqueda'";
                        $db_depend->setQuery( $query_depend);
                        $rowserver_depend = $db_depend->loadObjectList();
                        foreach ( $rowserver_depend as $row_depend ) {
                            $db_servicio =& JFactory::getDBO();
                            $query_servicio = "SELECT * FROM #__servicios WHERE id='$row_depend->Id_Serv_B'";
                            $db_servicio->setQuery( $query_servicio);
                            $rowserver_servicio = $db_servicio->loadRow();
                           ?>
                           <input type="text" id="<?php echo $row_depend->Id_Serv_B;?>" value="<?php
                           if(!$rowserver_servicio[0])
                           {
                               echo 'Sin Relacionados';
                           }
                           else
                                echo $rowserver_servicio[1];
                            ?>" readonly/>
                           <input type="checkbox" name="usun_relacion[]" id="usun_relacion[]" value="<?php echo $row_depend->Id_Serv_B; ?>"/>
                           <?php echo JText::_('CHECK_TO_DELETE'); ?>
                           <br/>

                    <?php

                        }
                    ?>

                </td>
            </tr>
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('RELACIONADOS');?>
                </td>
                <td>
                    <?php
                                                        $cuenta_relacionados1=0;
                                                        $servicios1[$cuenta_relacionados1] = array('value' => '0','text'=>JText::_('Sin_Relacionados'));
                                                        $serviciosjava1[$cuenta_relacionados1] = JText::_('Sin_Relacionados');
                                                        $serviciosid1[0] = '0';
							foreach ( $rowserver as $row ) {
                                                            $cuenta_relacionados1++;
                                                            $servicios1[$cuenta_relacionados1] = array('value' => $row->id,'text'=>$row->nombre_es);
                                                            $serviciosjava1[$cuenta_relacionados1] = $row->nombre_es;
                                                            $serviciosid1[$cuenta_relacionados1] = $row->id;

                                                        }
                                                        $rowServicios = & JTable::getInstance('relacionados', 'table');
                                                        //echo $rowServicios->IdServHijo;
                                                        ?>

                                                        <?php
                                                        //echo JHTML::_('select.genericList',
                                                         //       $servicios,'servicios','class="inputbox" '.' ', 'value','text',
                                                          //      $rowServicios->IdServHijo);

						?>
                                        <div id="uploader11">

                                        <select name="servicios_relacion[]" >
                                        <option selected value="0"> <?php echo $serviciosjava1[0];?> </option>
					<?php
					foreach ( $rowserver as $row )
					{
					?><option value="<?=$row->id?>"><?php echo $row->nombre_es; ?></option><?php
					}
					?>
					</select>

					</div><br/>
                    <a href="#" onclick="addRelacion(); return false;" ><?php echo JText::_('ADD_RELACION')?></a>
                </td>
            </tr>

            <tr>
               <td width="100" align="right" class="key">
                    <?php echo JText::_('HARDWARE_ASOCIADO');?>
                </td>
                <td>
                    <?php
                        $db_hardware =& JFactory::getDBO();
                        $id_busqueda =  $this->nl->id;
                        $query_hardware = "SELECT * FROM #__hardwareServicio WHERE IdServicio='$id_busqueda'";
                        $db_hardware->setQuery( $query_hardware);
                        $rowserver_hardware = $db_hardware->loadObjectList();
                        foreach ( $rowserver_hardware as $row_hardware ) {
                            $db_hard =& JFactory::getDBO();
                            $query_hard = "SELECT * FROM #__hardware WHERE id='$row_hardware->IdHw'";
                            $db_hard->setQuery( $query_hard);
                            $rowserver_hard = $db_hard->loadRow();
                            
                           ?>
                           <input type="text" id="<?php echo $row_hardware->IdHw;?>" value="<?php
                           if(!$rowserver_hard[2])
                           {
                               echo 'Sin relacionados';
                           }
                           else
                                echo $rowserver_hard[2];
                            ?>" readonly/>
                           <input type="checkbox" name="usun_hardware[]" id="usun_hardware[]" value="<?php echo $row_hardware->IdHw; ?>"/>
                           <?php echo JText::_('CHECK_TO_DELETE'); ?>
                           <br/>

                    <?php

                        }
                    ?>

                </td>
            </tr>
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('HARDWARE');?>
                </td>
                <td>
                    <?php
                                                        $cuenta_hardware=0;
                                                        $servicios_hardware[$cuenta_hardware] = array('value' => '0','text'=>JText::_('Sin_Hardware'));
                                                        $serviciosjava_hardware[$cuenta_hardware] = JText::_('Sin_Hardware');
                                                        $serviciosid_hardware[0] = '0';
							foreach ( $rowserverhardware as $rowhardware ) {
                                                            $cuenta_hardware++;
                                                            $servicios_hardware[$cuenta_hardware] = array('value' => $rowhardware->Id,'text'=>$rowhardware->MarcaModelo);
                                                            $serviciosjava_hardware[$cuenta_hardware] = $rowhardware->MarcaModelo;
                                                            
                                                            $serviciosid_hardware[$cuenta_hardware] = $rowhardware->Id;

                                                        }
                                                        $rowServicios_hardware = & JTable::getInstance('hardware', 'table');
                                                        //echo $rowServicios->IdServHijo;
                                                        ?>

                                                        <?php
                                                        //echo JHTML::_('select.genericList',
                                                         //       $servicios,'servicios','class="inputbox" '.' ', 'value','text',
                                                          //      $rowServicios->IdServHijo);

						?>
                                        <div id="uploader4">

                                        <select name="servicios_depende_hardware[]" >
                                        <option selected value="0"> <?php echo $serviciosjava_hardware[0];?> </option>
					<?php
					foreach ( $rowserverhardware as $rowhardware )
					{
					?><option value="<?=$rowhardware->Id?>"><?php echo $rowhardware->MarcaModelo; ?></option><?php
                                        
					}
					?>
					</select>
                                            
					</div><br/>
                    <a href="#" onclick="addHardware(); return false;" ><?php echo JText::_('ADD_HARDWARE')?></a>
                </td>
            </tr>
             <tr>
               <td width="100" align="right" class="key">
                    <?php echo JText::_('SOFTWARE_ASOCIADO');?>
                </td>
                <td>
                    <?php
                        $db_software =& JFactory::getDBO();
                        $id_busqueda =  $this->nl->id;
                        $query_software = "SELECT * FROM #__softwareServicio WHERE IdServicio='$id_busqueda'";
                        $db_software->setQuery( $query_software);
                        $rowserver_software = $db_software->loadObjectList();
                        foreach ( $rowserver_software as $row_software ) {
                            $db_soft =& JFactory::getDBO();
                            $query_soft = "SELECT * FROM #__software WHERE id='$row_software->IdSw'";
                            $db_soft->setQuery( $query_soft);
                            $rowserver_soft = $db_soft->loadRow();

                           ?>
                           <input type="text" id="<?php echo $row_software->IdSw;?>" value="<?php
                           if(!$rowserver_soft[1])
                           {
                               echo 'Sin relacionados';
                           }
                           else
                                echo $rowserver_soft[1];
                            ?>" readonly/>
                           <input type="checkbox" name="usun_software[]" id="usun_software[]" value="<?php echo $row_software->IdSw; ?>"/>
                           <?php echo JText::_('CHECK_TO_DELETE'); ?>
                           <br/>

                    <?php

                        }
                    ?>

                </td>
            </tr>
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('SOFTWARE');?>
                </td>
                <td>
                    <?php
                                                        $cuenta_software=0;
                                                        $servicios_software[$cuenta_software] = array('value' => '0','text'=>JText::_('Sin_Software'));
                                                        $serviciosjava_software[$cuenta_software] = JText::_('Sin_Software');
                                                        $serviciosid_software[0] = '0';
							foreach ( $rowserversoftware as $rowsoftware ) {
                                                            $cuenta_software++;
                                                            $servicios_software[$cuenta_software] = array('value' => $rowsoftware->Id,'text'=>$rowsoftware->Nombre);
                                                            $serviciosjava_software[$cuenta_software] = $rowsoftware->Nombre;

                                                            $serviciosid_software[$cuenta_software] = $rowsoftware->Id;

                                                        }
                                                        $rowServicios_software = & JTable::getInstance('software', 'table');
                                                        //echo $rowServicios->IdServHijo;
                                                        ?>

                                                        <?php
                                                        //echo JHTML::_('select.genericList',
                                                         //       $servicios,'servicios','class="inputbox" '.' ', 'value','text',
                                                          //      $rowServicios->IdServHijo);

						?>
                                        <div id="uploader5">

                                        <select name="servicios_depende_software[]" >
                                        <option selected value="0"> <?php echo $serviciosjava_software[0];?> </option>
					<?php
					foreach ( $rowserversoftware as $rowsoftware )
					{
					?><option value="<?=$rowsoftware->Id?>"><?php echo $rowsoftware->Nombre; ?></option><?php

					}
					?>
					</select>

					</div><br/>
                    <a href="#" onclick="addSoftware(); return false;" ><?php echo JText::_('ADD_SOFTWARE')?></a>
                </td>
            </tr>
            <tr>
               <td width="100" align="right" class="key">
                    <?php echo JText::_('HOST_ASOCIADO');?>
                </td>
                <td>
                    <?php
                        $db_host =& JFactory::getDBO();
                        $id_busqueda =  $this->nl->id;
                        $query_host = "SELECT * FROM #__hostServicio WHERE IdServicio='$id_busqueda'";
                        $db_host->setQuery( $query_host);
                        $rowserver_host = $db_host->loadObjectList();
                        foreach ( $rowserver_host as $row_host ) {
                            $db_hos =& JFactory::getDBO();
                            $query_hos = "SELECT * FROM #__host WHERE id='$row_host->IdHost'";
                            $db_hos->setQuery( $query_hos);
                            $rowserver_hos = $db_hos->loadRow();

                           ?>
                           <input type="text" id="<?php echo $row_host->IdHost;?>" value="<?php
                           if(!$rowserver_hos[1])
                           {
                               echo 'Sin Host';
                           }
                           else
                                echo $rowserver_hos[1];
                            ?>" readonly/>
                           <input type="checkbox" name="usun_host[]" id="usun_host[]" value="<?php echo $row_host->IdHost; ?>"/>
                           <?php echo JText::_('CHECK_TO_DELETE'); ?>
                           <br/>

                    <?php

                        }
                    ?>

                </td>
            </tr>
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('HOST');?>
                </td>
                <td>
                    <?php
                                                        $cuenta_host=0;
                                                        $servicios_host[$cuenta_host] = array('value' => '0','text'=>JText::_('Sin_Host'));
                                                        $serviciosjava_host[$cuenta_host] = JText::_('Sin_Host');
                                                        $serviciosid_host[0] = '0';
							foreach ( $rowserverhost as $rowhost ) {
                                                            $cuenta_host++;
                                                            $servicios_host[$cuenta_host] = array('value' => $rowhost->Id,'text'=>$rowhost->NombreDns);
                                                            $serviciosjava_host[$cuenta_host] = $rowhost->NombreDns;

                                                            $serviciosid_host[$cuenta_host] = $rowhost->Id;

                                                        }
                                                        $rowServicios_host = & JTable::getInstance('host', 'table');
                                                        //echo $rowServicios->IdServHijo;
                                                        ?>

                                                        <?php
                                                        //echo JHTML::_('select.genericList',
                                                         //       $servicios,'servicios','class="inputbox" '.' ', 'value','text',
                                                          //      $rowServicios->IdServHijo);

						?>
                                        <div id="uploader6">

                                        <select name="servicios_depende_host[]" >
                                        <option selected value="0"> <?php echo $serviciosjava_host[0];?> </option>
					<?php
					foreach ( $rowserverhost as $rowhost )
					{
					?><option value="<?=$rowhost->Id?>"><?php echo $rowhost->NombreDns; ?></option><?php

					}
					?>
					</select>

					</div><br/>
                    <a href="#" onclick="addHost(); return false;" ><?php echo JText::_('ADD_HOST')?></a>
                </td>
            </tr>
            <tr>
               <td width="100" align="right" class="key">
                    <?php echo JText::_('RESPONSABLE_ASOCIADO');?>
                </td>
                <td>
                    <?php
                        $db_responsable =& JFactory::getDBO();
                        $id_busqueda =  $this->nl->id;
                        $query_responsable = "SELECT * FROM #__responsableServicio WHERE IdServicio='$id_busqueda'";
                        $db_responsable->setQuery( $query_responsable);
                        $rowserver_responsable = $db_responsable->loadObjectList();
                        foreach ( $rowserver_responsable as $row_responsable ) {
                            $db_resp =& JFactory::getDBO();
                            $query_resp = "SELECT * FROM #__responsable WHERE id='$row_responsable->IdResponsable'";
                            $db_resp->setQuery( $query_resp);
                            $rowserver_resp = $db_resp->loadRow();

                           ?>
                           <input type="text" id="<?php echo $row_responsable->IdResponsable;?>" value="<?php
                           if(!$rowserver_resp[2])
                           {
                               echo 'Sin Responsable';
                           }
                           else
                                echo $rowserver_resp[1];
                            ?>" readonly/>
                           <input type="checkbox" name="usun_responsable[]" id="usun_responsable[]" value="<?php echo $row_responsable->IdResponsable; ?>"/>
                           <?php echo JText::_('CHECK_TO_DELETE'); ?>
                           <br/>

                    <?php

                        }
                    ?>

                </td>
            </tr>
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('RESPONSABLE');?>
                </td>
                <td>
                    <?php
                                                        $cuenta_responsable=0;
                                                        $servicios_responsable[$cuenta_responsable] = array('value' => '0','text'=>JText::_('Sin_Responsable'));
                                                        $serviciosjava_responsable[$cuenta_responsable] = JText::_('Sin_Responsable');
                                                        $serviciosid_responsable[0] = '0';
							foreach ( $rowserverresponsable as $rowresponsable ) {
                                                            $cuenta_responsable++;
                                                            $servicios_responsable[$cuenta_responsable] = array('value' => $rowresponsable->id,'text'=>$rowresponsable->nombre);
                                                            $serviciosjava_responsable[$cuenta_responsable] = $rowresponsable->nombre;

                                                            $serviciosid_responsable[$cuenta_responsable] = $rowresponsable->id;

                                                        }
                                                        $rowServicios_responsable = & JTable::getInstance('responsable', 'table');
                                                        //echo $rowServicios->IdServHijo;
                                                        ?>

                                                        <?php
                                                        //echo JHTML::_('select.genericList',
                                                         //       $servicios,'servicios','class="inputbox" '.' ', 'value','text',
                                                          //      $rowServicios->IdServHijo);

						?>
                                        <div id="uploader7">

                                        <select name="servicios_depende_responsable[]" >
                                        <option selected value="0"> <?php echo $serviciosjava_responsable[0];?> </option>
					<?php
					foreach ( $rowserverresponsable as $rowresponsable )
					{
					?><option value="<?=$rowresponsable->id?>"><?php echo $rowresponsable->nombre; ?></option><?php

					}
					?>
					</select>

					</div><br/>
                    <a href="#" onclick="addResponsable(); return false;" ><?php echo JText::_('ADD_RESPONSABLE')?></a>
                </td>
            </tr>


            <tr>
               <td width="100" align="right" class="key">
                    <?php echo JText::_('DOCUMENTOS_ASOCIADO');?>
                </td>
                <td>
                    <?php
                        $db_documentos =& JFactory::getDBO();
                        $id_busqueda =  $this->nl->id;
                        $query_documentos = "SELECT * FROM #__documentosAsociados WHERE IdServicio='$id_busqueda'";
                        $db_documentos->setQuery( $query_documentos);
                        $rowserver_documentos = $db_documentos->loadObjectList();
                        foreach ( $rowserver_documentos as $row_documentos ) {
                            $db_doc =& JFactory::getDBO();
                            $query_doc = "SELECT * FROM #__tiposDoc WHERE Id='$row_documentos->IdDoc'";
                            $db_doc->setQuery( $query_doc);
                            $rowserver_doc = $db_doc->loadRow();

                           ?>
                           <input type="text" id="<?php echo $row_documentos->IdDoc;?>" value="<?php
                           if(!$rowserver_hard[1])
                           {
                               echo 'Sin Documentos Asociados';
                           }
                           else
                                echo $rowserver_doc[1];
                            ?>" readonly/>
                           <input type="checkbox" name="usun_documentos[]" id="usun_documentos[]" value="<?php echo $row_documentos->IdDoc; ?>"/>
                           <?php echo JText::_('CHECK_TO_DELETE'); ?>
                           <br/><br/>
                           <?php $text = JText::_('Editar_Documento_Asociados');
                           $text_ = JHTML::link('index.php?option=com_servicios&task=edit_documento_asociado&cid[]='.$row_documentos->IdDocumentos.'&cidS[]='.$this->nl->id,$text);
                           echo $text_;?>
                           <br/>

                    <?php

                        }
                    ?>

                </td>
            </tr>
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('DOCUMENTOS');?>
                </td>
                <td>
                    <?php
                                                        $cuenta_documentos=0;
                                                        $servicios_documentos[$cuenta_documentos] = array('value' => '0','text'=>JText::_('Sin_Documentos'));
                                                        $serviciosjava_documentos[$cuenta_documentos] = JText::_('Sin_Documentos');
                                                        $serviciosid_documentos[0] = '0';
							foreach ( $rowserverdocumentos as $rowdocumentos ) {
                                                            $cuenta_documentos++;
                                                            $servicios_documentos[$cuenta_documentos] = array('value' => $rowdocumentos->Id,'text'=>$rowdocumentos->Descripcion_es);
                                                            $serviciosjava_documentos[$cuenta_documentos] = $rowdocumentos->Descripcion_es;

                                                            $serviciosid_documentos[$cuenta_documentos] = $rowdocumentos->Id;

                                                        }
                                                        $rowServicios_documentos = & JTable::getInstance('documentos', 'table');
                                                        //echo $rowServicios->IdServHijo;
                                                        ?>

                                                        <?php
                                                        //echo JHTML::_('select.genericList',
                                                         //       $servicios,'servicios','class="inputbox" '.' ', 'value','text',
                                                          //      $rowServicios->IdServHijo);

						?>
                                        <div id="uploader8">

                                        <select name="servicios_depende_documentos[]" >
                                        <option selected value="0"> <?php echo $serviciosjava_documentos[0];?> </option>
					<?php
					foreach ( $rowserverdocumentos as $rowdocumentos )
					{
					?><option value="<?=$rowdocumentos->Id?>"><?php echo $rowdocumentos->Descripcion_es; ?></option><?php

					}
					?>
					</select>

					</div><br/>
                    <a href="#" onclick="addDocumentos(); return false;" ><?php echo JText::_('ADD_DOCUMENTOS')?></a>
                </td>
            </tr>



			<tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('PRODUCER');?>
                </td>
                <td>
                    <?php
							$options = array();
							$options[] = JHTML::_('select.option', 0,JText::_('CHOOSE_PRODUCER') );
							foreach($this->creador as $creador){
								$options[] = JHTML::_('select.option', $creador->id, $creador->nombre);
								
							}
							echo JHTML::_('select.genericlist', $options, 'creador_id', null, 'value', 'text', $this->nl->creador_id);
						?>
                </td>
            </tr>
			<tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('INTRO_DESCRIPCION_ES');?>
                </td>
                <td>
                	<?php echo $editor->display( 'intro_desc_es', $this->nl->intro_desc_es, '100%', '180', '40', '10',false);?>
                </td>
            </tr>

	    <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('INTRO_DESCRIPCION_VAL');?>
                </td>
                <td>
                	<?php echo $editor->display( 'intro_desc_val', $this->nl->intro_desc_val, '100%', '180', '40', '10',false);?>
                </td>
            </tr>

            <tr>
            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('DESCRIPCION_ES');?>
                </td>
                <td>
                    <?php echo $editor->display( 'descripcion_es', $this->nl->descripcion_es, '100%', '250', '40', '10',true );?>
                </td>
            </tr>

       <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('DESCRIPCION_VAL');?>
                </td>
                <td>
                    <?php echo $editor->display( 'descripcion_val', $this->nl->descripcion_val, '100%', '250', '40', '10',true );?>
                </td>
            </tr>








            <tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('IMAGES_INCLUDED');?>
                </td>
                <td>
                	 <input type="hidden" name="image_url" id="image_url" value="<?php echo $this->nl->image_url ?>" />
                    <?php
							$images_count = 0;
							$images = array();
							if(!$image = $this->nl->image_url){
								echo JText::_('NO_IMAGES_INCLUDED');
							}else{
							for($i=0; $i<strlen($image); $i++){
								if($image[$i]!=';'){
									$images[$images_count].=$image[$i];
								}else{
									
									$images_count++;
								}
							}
							for($i=0; $i<count($images); $i++){
								?>
									<?php $sciezka = str_replace('/administrator','',JURI::base());
									      $sciezka .= '/components/com_servicios/images/';
										  $sciezka .= $images[$i];
										  ?>
                         <img alt=""  src="<?php echo $sciezka;?>.th.jpg"/>
										  <input type="checkbox" name="usun[]" id="usun[]" value="<?php echo $images[$i];?>"/>
										  <?php echo JText::_('CHECK_TO_DELETE'); ?>
										  <br/>
								<?php
							}
							}
						?>
                </td>
            </tr>
			<tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('ADD_IMAGE');?>
                </td>
                <td>
                    <?php $image_urls = ""?>
					<div id="uploader">
					<input type="file"  name="image[]" />

					</div><br/><a href="#" onclick="addImage(); return false;" ><?php echo JText::_('ADD_IMG_LINK')?></a>
                </td>
            </tr>
			<tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('FILES_INCLUDED');?>
                </td>
                <td>
                	<input type="hidden" name="files_url" id="files_url" value="<?php echo $this->nl->files_url ?>" />
                    <?php
							$files_count = 0;
							$files = array();
							if(!$file = $this->nl->files_url){
								echo JText::_('NO_FILES_INCLUDED');
							}else{
							for($i=0; $i<strlen($file); $i++){
								if($file[$i]!=';'){
									$files[$files_count].=$file[$i];
								}else{
									
									$files_count++;
								}
							}
							
							
							for($i=0; $i<count($files); $i++){
								?>
									<?php $sciezka = str_replace('/administrator','',JURI::base());
									      $sciezka .= 'components/com_servicios/files/';
										  $sciezka .= $files[$i];
										  echo $sciezka;
										  ?>
										  <input type="checkbox" name="usun_plik[]" id="usun_plik[]" value="<?php echo $files[$i]; ?>"/>
										  <?php echo JText::_('CHECK_TO_DELETE');?>
										  <br/>
								<?php
							}
							}
						?>
                </td>
            </tr>
			<tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('ADD_FILE');?>
                </td>
                <td>
                    <?php $file_urls = ""?>
					<div id="uploader2">
					<input type="file"  name="files[]" />

					</div><br/><a href="#" onclick="addFile(); return false;" ><?php echo JText::_('ADD_FILE_LINK')?></a>
                </td>
            </tr>
	<!--		<tr>
                <td width="100" align="right" class="key">
                    <?php echo JText::_('SET_PRICE');?>
                </td>
                <td>
                    <input class="text_area" type="text" name="price" id="price" size="50" maxlength="250" value="<?php echo $this->nl->price; ?>" onChange="check()"/> <div id="price_alert" name="price_alert"></div>
					
                </td>
            </tr>
      -->
        </table>
    </fieldset>
    <input type="hidden" name="id" value="<?php echo $this->nl->id; ?>" />
	<input type="hidden" name="ordering" value="<?php echo $this->nl->ordering; ?>" />
	<input type="hidden" name="option" value="<?php echo $option;?>" />
	<input type="hidden" name="task" value="items" />
	<input type="hidden" name="boxchecked" value="0" />
</form>

<script type="text/javascript">	

function check(){
	if(document.adminForm.price.value.search(/^[0-9]+(\,{1}[0-9]{2})?$/i)){
				document.adminForm.price.style.backgroundColor='#F00000';
				$('price_alert').innerHTML = "<?php echo JText::_('ALERT_PRICE')?>";
				$('price_alert').setStyle('background','#f00000');
				$('price_alert').setStyle('color','#ffffff');
				$('price_alert').setStyle('font-weight','bold');
			}
			else{
				document.adminForm.price.style.backgroundColor='';
				$('price_alert').innerHTML = '';
				$('price_alert').setStyle('background','none');
			}
}
	
function addImage(){
	var inputdiv = document.createElement('input');
	inputdiv.setAttribute('name','image[]');
	inputdiv.setAttribute('type','file');

	var ni = $('uploader');
	
	ni.appendChild(document.createElement('br'))
	ni.appendChild(inputdiv);
}

function addFile(){
	var inputdiv = document.createElement('input');
	inputdiv.setAttribute('name','files[]');
	inputdiv.setAttribute('type','file');

	var ni = $('uploader2');
	
	ni.appendChild(document.createElement('br'))
	ni.appendChild(inputdiv);
}


function addDependencia(){
	var inputdiv = document.createElement('select');
        inputdiv.setAttribute('name', 'servicios_depende[]');
        //inputdiv.setAttribute('type','select');

        var var1="<?php echo $cuenta_dependencia; ?>";
        var datos = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php 
        for($i=0;$i<=$cuenta_dependencia;$i++)
        {
            echo "\n datos[".$i."] = '".$serviciosjava[$i]."';";

        }
        ?>
        var datos_id = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_dependencia;$i++)
        {
            echo "\n datos_id[".$i."] = '".$serviciosid[$i]."';";

        }
        ?>
        var i = 0;
        for(i=0;i<=var1;i++)
        {
            var op1 = new Option(datos[i],datos_id[i]);
            inputdiv.appendChild(op1);
        }
        
	var ni = $('uploader3');

	ni.appendChild(document.createElement('br'))
        ni.appendChild(document.createElement('br'))
	ni.appendChild(inputdiv);
}


function addRelacion(){
	var inputdiv = document.createElement('select');
        inputdiv.setAttribute('name', 'servicios_relacion[]');
        //inputdiv.setAttribute('type','select');

        var var1="<?php echo $cuenta_relacionados1; ?>";
        var datos = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_relacionados1;$i++)
        {
            echo "\n datos[".$i."] = '".$serviciosjava1[$i]."';";

        }
        ?>
        var datos_id = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_relacionados1;$i++)
        {
            echo "\n datos_id[".$i."] = '".$serviciosid1[$i]."';";

        }
        ?>
        var i = 0;
        for(i=0;i<=var1;i++)
        {
            var op1 = new Option(datos[i],datos_id[i]);
            inputdiv.appendChild(op1);
        }

	var ni = $('uploader11');

	ni.appendChild(document.createElement('br'))
        ni.appendChild(document.createElement('br'))
	ni.appendChild(inputdiv);
}


function addHardware(){
	var inputdiv_hardware = document.createElement('select');
        inputdiv_hardware.setAttribute('name', 'servicios_depende_hardware[]');
        //inputdiv.setAttribute('type','select');

        var var1_hardware="<?php echo $cuenta_hardware; ?>";
        var datos_hardware = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_hardware;$i++)
        {
            echo "\n datos_hardware[".$i."] = '".$serviciosjava_hardware[$i]."';";
        }
        ?>
        var datos_id_hardware = new Array();
        
        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_hardware;$i++)
        {
            echo "\n datos_id_hardware[".$i."] = '".$serviciosid_hardware[$i]."';";
        }
        ?>
        var i = 0;
        for(i=0;i<=var1_hardware;i++)
        {
            var op1_hardware = new Option(datos_hardware[i],datos_id_hardware[i]);
            inputdiv_hardware.appendChild(op1_hardware);
        }

	var ni = $('uploader4');

	ni.appendChild(document.createElement('br'))
        ni.appendChild(document.createElement('br'))
	ni.appendChild(inputdiv_hardware);
}


function addSoftware(){
	var inputdiv_software = document.createElement('select');
        inputdiv_software.setAttribute('name', 'servicios_depende_software[]');
        //inputdiv.setAttribute('type','select');

        var var1_software="<?php echo $cuenta_software; ?>";
        var datos_software = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_software;$i++)
        {
            echo "\n datos_software[".$i."] = '".$serviciosjava_software[$i]."';";
        }
        ?>
        var datos_id_software = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_software;$i++)
        {
            echo "\n datos_id_software[".$i."] = '".$serviciosid_software[$i]."';";
        }
        ?>
        var i = 0;
        for(i=0;i<=var1_software;i++)
        {
            var op1_software = new Option(datos_software[i],datos_id_software[i]);
            inputdiv_software.appendChild(op1_software);
        }

	var ni = $('uploader5');

	ni.appendChild(document.createElement('br'))
        ni.appendChild(document.createElement('br'))
	ni.appendChild(inputdiv_software);
}


function addHost(){
	var inputdiv_host = document.createElement('select');
        inputdiv_host.setAttribute('name', 'servicios_depende_host[]');
        //inputdiv.setAttribute('type','select');

        var var1_host="<?php echo $cuenta_host; ?>";
        var datos_host = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_host;$i++)
        {
            echo "\n datos_host[".$i."] = '".$serviciosjava_host[$i]."';";
        }
        ?>
        var datos_id_host = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_host;$i++)
        {
            echo "\n datos_id_host[".$i."] = '".$serviciosid_host[$i]."';";
        }
        ?>
        var i = 0;
        for(i=0;i<=var1_host;i++)
        {
            var op1_host = new Option(datos_host[i],datos_id_host[i]);
            inputdiv_host.appendChild(op1_host);
        }

	var ni = $('uploader6');

	ni.appendChild(document.createElement('br'))
        ni.appendChild(document.createElement('br'))
	ni.appendChild(inputdiv_host);
}



function addResponsable(){
	var inputdiv_responsable = document.createElement('select');
        inputdiv_responsable.setAttribute('name', 'servicios_depende_responsable[]');
        //inputdiv.setAttribute('type','select');

        var var1_responsable="<?php echo $cuenta_responsable; ?>";
        var datos_responsable = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_responsable;$i++)
        {
            echo "\n datos_responsable[".$i."] = '".$serviciosjava_responsable[$i]."';";
        }
        ?>
        var datos_id_responsable = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_responsable;$i++)
        {
            echo "\n datos_id_responsable[".$i."] = '".$serviciosid_responsable[$i]."';";
        }
        ?>
        var i = 0;
        for(i=0;i<=var1_responsable;i++)
        {
            var op1_responsable = new Option(datos_responsable[i],datos_id_responsable[i]);
            inputdiv_responsable.appendChild(op1_responsable);
        }

	var ni = $('uploader7');

	ni.appendChild(document.createElement('br'))
        ni.appendChild(document.createElement('br'))
	ni.appendChild(inputdiv_responsable);
}


function addDocumentos(){
	var inputdiv_documentos = document.createElement('select');
        inputdiv_documentos.setAttribute('name', 'servicios_depende_documentos[]');
        //inputdiv.setAttribute('type','select');

        var var1_documentos="<?php echo $cuenta_documentos; ?>";
        var datos_documentos = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_documentos;$i++)
        {
            echo "\n datos_documentos[".$i."] = '".$serviciosjava_documentos[$i]."';";
        }
        ?>
        var datos_id_documentos = new Array();

        // PASAMOS UN ARRAY DE PHP A JAVA
        <?php
        for($i=0;$i<=$cuenta_documentos;$i++)
        {
            echo "\n datos_id_documentos[".$i."] = '".$serviciosid_documentos[$i]."';";
        }
        ?>
        var i = 0;
        for(i=0;i<=var1_documentos;i++)
        {
            var op1_documentos = new Option(datos_documentos[i],datos_id_documentos[i]);
            inputdiv_documentos.appendChild(op1_documentos);
        }

	var ni = $('uploader8');
        


	ni.appendChild(document.createElement('br'))
        ni.appendChild(document.createElement('br'))
	ni.appendChild(inputdiv_documentos);

        
}


                   /* <!--div id="uploader9" <?php if(!$rowserveravisos){ echo"style='display:none;'";}?>>
                            <br/><br/>
                           <?php $text = JText::_('Editar_Avisos');
                           if($rowserveravisos){
                            $text_ = JHTML::link('index.php?option=com_servicios&task=edit_avisos&cidA[]='.$this->nl->id.'&cid[]='.$rowserveravisos[0],$text);
                           }
                           else $text_ = JHTML::link('index.php?option=com_servicios&task=edit_avisos&cidA[]='.$this->nl->id,$text);
                           echo $text_;?>
                           <br/>
                    </div-->*/




function submitbutton(pressbutton) {
		var form = document.adminForm;
		if (pressbutton == 'cancelItem') {
			submitform( pressbutton );
			return;
		}

		// do field validation
		if (form.name.value == ""){
			alert( "<?php echo JText::_( 'ALERT_ITEM_NAME', true ); ?>" );
		} 
		else if (form.creador_id.value == "0"){
			alert( "<?php echo JText::_( 'ALERT_ITEM_PRODUCER', true ); ?>" );
		} else  {
			$('upload_loading').setStyle('display', 'block');
			$('alercik').innerHTML = "<?php echo JText::_('ALERT_SUBMIT');?>";
			submitform( pressbutton );
			document.adminForm.button.disabled=true;
		}
	}


function muestra_oculta(id,variable){

    if (document.getElementById){ //se obtiene el id
        var el = document.getElementById(id); //se define la variable "el" igual a nuestro div
        if(variable)
        {
            el.style.display = 'block'
        }
        else
        {
            el.style.display = 'none'
        }
        //el.style.display = (el.style.display == 'none') ? 'block' : 'none'; //damos un atributo display:none que oculta el div
    }
}

window.onload = function(){/*hace que se cargue la función lo que predetermina que div estará oculto hasta llamar a la función nuevamente*/
    muestra_oculta('contenido_a_mostrar',variable);/* "contenido_a_mostrar" es el nombre de la etiqueta DIV que deseamos mostrar */
}


</script>