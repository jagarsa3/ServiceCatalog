<?php

class OptionList{
var $text;
var $value;
var $disabled;	

function __construct(){
$text=null;
$value=null;			
$disabled=null;
}
	
}


class TreeNodeHelper{
var $idCategoria;
var $id;
var $nombre_es;
var $nombre_val;
var $childs = Array();
var $level;

function __construct(){
$idCategoria=null;
$id=null;
$nombre_es=null;
$nombre_val=null;
$childs[]=null;
$elem[]=null;
$level=0;
}
public function getServicio()
{

    
}

public function getSortList(& $lists,& $lists_const,& $option=Array(),& $sprawdzone=Array()){

	$liczba = count($lists_const);
	foreach($lists as $list){

				$flaga=0;
				for($l=0;$l<count($sprawdzone);$l++){
					if($sprawdzone[$l]==$list->id){
						$flaga=1;
					}
				}
			
			if($flaga==0){
			$sprawdzone[]=$list->id;
			
			$this->idCategoria = $list->idCategoria;
			$this->id = $list->id;
			$this->nombre_es = $list->nombre_es;
			$this->nombre_val = $list->nombre_val;
			$op= new OptionList;
			$op->text=$this->nombre_es;
			$op->text=$this->nombre_val;
			$op->value=$this->id;
			$option[]=$op;
			
			
				   for($i=0; $i<$liczba;$i++ ){
					if($lists_const[$i]->idCategoria==$list->id){		
						$child=new TreeNodeHelper();
						$child->id=$lists_const[$i]->id;
						$child->idCategoria=$lists_const[$i]->idCategoria;
						$child->level=$list->level+1;
						$new_nombre_es=$lists_const[$i]->nombre_es;
						$new_nombre_val=$lists_const[$i]->nombre_val;
							for($lev=0;$lev<$child->level;$lev++){
								$new_nombre_es="&nbsp;&nbsp;&nbsp;".$new_nombre_es;
								$new_nombre_val="&nbsp;&nbsp;&nbsp;".$new_nombre_val;
							}
						$child->nombre_es=$new_nombre_es;
						$child->nombre_val=$new_nombre_val;

						
						$this->childs[]=$child;
						$this->getSortList($this->childs,$lists_const,$option,$sprawdzone);
					
					}
				}	
				
			}
	}
	return($option);		
}



}

?>

