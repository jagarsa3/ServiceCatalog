  function check(){
  for(var i=0;i<document.form1["checka[]"].length; i++){
    if(document.form1["checka[]"][i].checked){
    var cos=document.form1["checka[]"][i].value;
    }     
     var e = document.getElementsByName(cos);
     for(var a=0 ; a<e.length;a++)
      {
        e.item(0).disabled=false;
		
      }
  }
  
  for(var ii=0;ii<document.form1["checka[]"].length; ii++)
  {
    
	
	if(document.form1["checka[]"][ii].checked==false)
	{
      var coss=document.form1["checka[]"][ii].value;
	  var nazwa= "wynik"+(ii+2);
    }
      var ee = document.getElementsByName(coss);
      for(var aa=0 ; aa<ee.length;aa++)
      {
        ee.item(0).disabled=true;
			document.getElementById(nazwa).innerHTML = "";
      }
  }
  
  		suma=0;
		var podatek = w_podatek_vat;
  		for (var l = 0; l < tab.length; l++) {
			var na = "wynik" + l;
			var xxx = parseInt(document.getElementById(na).innerHTML);
			if (xxx > 0) {
				suma = suma + xxx;
			}
		}
				document.getElementById("wartosc_netto").innerHTML=suma;
				document.getElementById("wartosc_brutto").innerHTML=suma+suma*podatek;
 				documenr.getElementById("podatek").innerHTML=podatek_p;
				document.getElementById("h_brutto").value = suma + suma*podatek;
				document.getElementById("h_netto").value = suma ;
				document.getElementById("h_podatek").value = podatek_p;
 }

 
 function wartosc(e){
						
			var i = e.id;
			var x = e.value * tab[i];
			var nazwa = "wynik"+i;
			var ukryty = "ukryty"+i;
			if(isNaN(x)){x=""}
			document.getElementById(nazwa).innerHTML = x;

			
			if(e.value.search(/^[0-9]+$/i)){
				e.style.backgroundColor='#F00000';
			}
			else{
				e.style.backgroundColor='';
			}


			var suma=0;
			var podatek =w_podatek_vat;
			for (var l = 0; l < tab.length; l++) {
				var na = "wynik" + l;
				var xxx = parseInt(document.getElementById(na).innerHTML);
						if(xxx>0){
						suma = suma + xxx;				
					}
				}
				document.getElementById("wartosc_netto").innerHTML=suma;
				document.getElementById("wartosc_brutto").innerHTML=suma+suma*podatek;
 				documenr.getElementById("podatek").innerHTML=podatek_p;
				document.getElementById("h_brutto").value = suma + suma*podatek;
				document.getElementById("h_netto").value = suma ;
				document.getElementById("h_podatek").value = podatek_p;

 }
 
function suma(){
	var suma=0;
			var podatek =w_podatek_vat;
//				document.getElementById("podatekkk").innerHTML="sasdhjkashdkah";	
			for (var l = 0; l < tab.length; l++) {
				var na = "wynik" + l;
				var xxx = parseInt(document.getElementById(na).innerHTML);
					if(xxx>0){
						suma = suma + xxx;				
					}

				}
				document.getElementById("wartosc_netto").innerHTML=suma;
				document.getElementById("wartosc_brutto").innerHTML=suma+suma*podatek;
 				documenr.getElementById("podatek").innerHTML=podatek_p;
				document.getElementById("h_brutto").value = suma + suma*podatek;
				document.getElementById("h_netto").value = suma ;
				document.getElementById("h_podatek").value = podatek_p;
}









