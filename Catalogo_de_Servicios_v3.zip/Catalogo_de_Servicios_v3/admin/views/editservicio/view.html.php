<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');
jimport('joomla.filesystem.path');
jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');


class serviciosViewEditservicio extends JView

{
 
	function display($tpl = null)

	{

		  $model =& $this->getModel();

		  $nl = $model->getServicio();
		  $cats = $model->getCategorias();
		  $creador = $model->getCreador();

    

	$this->assignRef('nl',$nl);
	$this->assignRef('list',$cats);
	$this->assignRef('creador',$creador);

		

		JRequest::setVar('hidemainmenu',1);

		

		JToolBarHelper::title( JText::_('ITEMS'), 'generic.png');

		JToolBarHelper::save('saveItem', JText::_('SAVE'), 'save.png');

		JToolBarHelper::apply('applyItem', JText::_('APPLY'), 'apply.png');

		JToolBarHelper::cancel('cancelItem', JText::_('CANCEL'), 'cancel.png');
		
		

		parent::display($tpl);

	}

}



