<?php

class TreeNodeHelper{

var $Id;
var $NombreDns;
var $HardwareAsociado;
var $checked;
var $IdHw;

function __construct(){

$Id=null;
$IdHw=null;
$NombreDns=null;
$HardwareAsociado=null;
$checked=null;
}



public function getSortList(& $lists,& $lists_const,& $ii,& $obj=Array(),& $sprawdzone=Array()){
	$liczba = count($lists_const);
	foreach($lists as $list){
				$flaga=0;
 				for($l=0;$l<count($sprawdzone);$l++)
 				{
 					if($sprawdzone[$l]==$list->Id)
 					{
 						$flaga=1;

					}

 				}
			
			if($flaga==0){
			$sprawdzone[]=$list->Id;
			//print_r($obj);
			$this->Id = $list->Id;
			$this->NombreDns = $list->NombreDns;



                        $db_hardware =& JFactory::getDBO();
                        $query_hardware = "SELECT * FROM #__hardware WHERE Id='$list->IdHw'";
                        $db_hardware->setQuery( $query_hardware);
                        $rowserver_hardware = $db_hardware->loadRow();

                        $this->IdHw = $list->IdHw;

			$this->HardwareAsociado = $rowserver_hardware[2];
			$this->checked = $list->checked;	
			$this->NombreDns = JHTML::link('index.php?option=com_servicios&task=edit_host&cid[]='.$this->Id, $this->NombreDns);
			$checked = JHTML::_('grid.id', $ii, $list->Id );
			$ii++;


			?>
        <tr>
            <td align="center">
                <?php echo $checked; ?>
            </td>
            <td align="center">
                <?php echo $this->Id; ?>
            </td>
            <td align="center">
                <?php echo $this->NombreDns; ?>
            </td>
            <td align="center">
                <?php echo $this->HardwareAsociado; ?>
            </td>
        </tr>
			<?php	
				
			}
	}
				
	return(null);		
}



}

?>

