<?php

defined ('_JEXEC') or die('Restricted access');
require_once(dirname(__FILE__).DS.'helper.php');
$sort_list=$this->list;
$_list = new TreeNodeHelper();


?>
<form action="index.php" method="post" name="adminForm">
	<table>
	<tr>

        	</tr>
			</table>
    <table class="adminlist">
        <thead>
            <tr>
                <th width="20">
                    <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php  echo count($this->list); ?>);"/>
                </th>
                <th width="5px">
                    <?php echo JText::_( 'id' ); ?>
                </th>
                <th width="200px">
                    <?php echo JText::_( 'NombreDNS' ); ?>
                </th>
		<th width="200px">
                    <?php echo JText::_( 'HardwareAsociado' ); ?>
                </th>

            </tr>
        </thead>
        <?php
		$z=0;
		$_list->getSortList($sort_list,$sort_list,$z);
		$i=0;
		foreach($sort_list as $list):
		$checked = JHTML::_('grid.id', ++$i, $this->Id );
		$i++;
		endforeach;
		?>

    </table>
    <input type="hidden" name="option" value="<?php echo $option; ?>" />
    <input type="hidden" name="task" value="host" />
    <input type="hidden" name="boxchecked" value="0" />
</form>