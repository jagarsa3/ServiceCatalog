<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');



class serviciosViewedit_documento_asociado extends JView

{

	function display($tpl = null)

	{

		  $model =& $this->getModel();
		  $nl = $model->getDocs();
		  $cats = $model->getDocumentos();

    

		$this->assignRef('nl',$nl);
		$this->assignRef('list',$cats);

		

		JRequest::setVar('hidemainmenu',1);

		

		JToolBarHelper::title( JText::_('DOCUMENTO_ASOCIADO'), 'generic.png');

		JToolBarHelper::save('saveDocumentoasociado', JText::_('SAVE'), 'save.png');

		JToolBarHelper::apply('applyDocumentoasociado', JText::_('APPLY'), 'apply.png');

		JToolBarHelper::cancel('cancel_documento_asociado', JText::_('CANCEL'), 'cancel.png');


		parent::display($tpl);

	}

}



