<?php

defined ('_JEXEC') or die('Restricted access');

$editor =& JFactory::getEditor();
defined ('_JEXEC') or die('Restricted access');
require_once(dirname(__FILE__).DS.'helper.php');
$sort_list=$this->list;
$_list = new TreeNodeHelper();

$cid = JRequest::getVar('cidS', array (), '', 'array');

$IDDOC = $this->nl->IdDoc;

$dbdocumentos =& JFactory::getDBO();
$querydocumentos = "SELECT * FROM #__tiposDoc WHERE Id='$IDDOC'";
$dbdocumentos->setQuery( $querydocumentos);
$rowserverdocumentos = $dbdocumentos->loadRow();

JHTML::_('behavior.calendar');

if(isset($this->nl->Fecha))
{
    $anyo =  substr($this->nl->Fecha, 2, 2);  // abcd
    $mes =  substr($this->nl->Fecha, 5, 2);  // abcd
    $dia =  substr($this->nl->Fecha, 8, 2);  // abcd
    $this->nl->Fecha = $anyo."-".$mes."-".$dia;
}
   
?>
<?php 
?>
		<form action="index.php" method="post" name="adminForm" id="adminForm">
			<fieldset class="adminform">	
			<legend><?php echo JText::_('DETAIL'); ?></legend>
				<table class="admintable">
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('Version');?>
					</td>
					
					<td>
	
                                <input class="text_area" type="text" name="Version" id="Version" size="50" maxlength="250" value="<?php echo $this->nl->Version; ?>" />

					</td>
				</tr>
				<tr>
			      
				<td width="100" align="right" class="key">
						<?php echo JText::_( 'Fecha'); ?>
					
					</td>
					<td>
						<input class="inputbox" type="text" name="Fecha" id="Fecha" size="10" maxlength="10"
							value="<?php echo $this->nl->Fecha;?>" />
						<input type="reset" class="button" value="..."
							onclick="return showCalendar('Fecha','%y-%m-%d');"/>
					</td>
				</tr>
                                <tr>
					 <td width="100" align="right" class="key">
						<?php echo JText::_('RutaDoc_es');?>
					</td>

<td>

				<?php echo $editor->display( 'RutaDoc_es', $this->nl->RutaDoc_es, '100%', '250', '40', '10',true );?>
</td>
				</tr>
                                <tr>
					 <td width="100" align="right" class="key">
						<?php echo JText::_('RutaDoc_val');?>
					</td>

<td>

				<?php echo $editor->display( 'RutaDoc_val', $this->nl->RutaDoc_val, '100%', '250', '40', '10',true );?>
                                
</td>
				</tr>

			</table>

			</fieldset>
                        <input type="hidden" name="TipoDoc" value="<?php echo $rowserverdocumentos[1]; ?>" />
			<input type="hidden" name="IdDoc" value="<?php echo $this->nl->IdDoc; ?>" />
                        <input type="hidden" name="IdServicio" value="<?php echo $cid[0]; ?>" />
                        <input type="hidden" name="IdDocumentos" value="<?php echo $this->nl->IdDocumentos; ?>" />
			<input type="hidden" name="option" value="<?php echo $option;?>" />
			<input type="hidden" name="task" value="servicios" />
			<input type="hidden" name="boxchecked" value="1" />
		</form>
<script language="javascript" type="text/javascript">

	function submitbutton(pressbutton) {
		var form = document.adminForm;
		if (pressbutton == 'cancel_documento_asociado') {
			submitform( pressbutton );
			return;
		}


                var anyo,mes,dia;

                dia = document.forms.adminForm.Fecha.value.substring(6,8);
                mes = document.forms.adminForm.Fecha.value.substring(3,5);
                anyo = document.forms.adminForm.Fecha.value.substring(0,2);


                temp = "2"+"0";
                anyo = temp+anyo;
                fecha_correcta=anyo+"-"+mes+"-"+dia;

                //document.forms.adminForm.Fecha.value = fecha_correcta;


                // COMPROBACIONES PARA LA FECHA DEL DOCUMENTO

                if (document.forms.adminForm.Fecha.value==''){
                           var error = "<?php echo JText::_( 'Error14'); ?>";
                           alert(error);
                	   return false;
                }


                if (document.forms.adminForm.Fecha.value!=''){
			if(!validarFecha(dia,mes,anyo)){
                                document.forms.adminForm.Fecha.value='';
				var error = "<?php echo JText::_( 'Error14'); ?>";
                		alert(error);
                		return false;

	  		}

		}


                // VALIDAR FECHA
                valor = document.forms.adminForm.Fecha.value;
                if (document.forms.adminForm.Fecha.value!=''){
                    if( !(/^\d{2}\-\d{2}\-\d{2}$/.test(valor)) ) {
                        document.forms.adminForm.Fecha.value='';
                        var error = "<?php echo JText::_( 'Error14'); ?>";
                        alert(error);
                        return false;
                    }

                }



		// do field validation
		if (form.Version.value == ""){
			alert( "<?php echo JText::_( 'ALERT_DESCRIPCION_NAME', true ); ?>" );
		} 
		else  {
			submitform( pressbutton );
		}
	}


        function validarFecha(dia,mes,anyo)
        {

	   	diaok=validarEntero(dia);
		mesok=validarEntero(mes);
		anyook=validarEntero(anyo);

		if((diaok!="" && diaok>0 && diaok<=31) && (mesok!="" && mesok>0 && mesok<=12) && (anyook!="" && anyook>=2000)){
			//comprobar febrero:
			if(mesok==2){
				if(diaok<=29){
					restoanyook=anyook%4;
					if(restoanyook > 0 && diaok>28)	return false;
					else return true;
				}
				else return false;
			}
			else if((mesok==4 || mesok==6 || mesok==9 || mesok==11) && diaok>30)
					return false;
			else return true;
		}
		 return false;
	}


        function validarEntero(valor)
        {
		//intento convertir a entero.
	    //si era un entero no le afecta, si no lo era lo intenta convertir a un numero decimal
	    valor = parseInt(valor,10);
	    //Compruebo si es un valor numérico
	    if (isNaN(valor)) {
		    return "";
	    }
		else{
	        return valor;
	    }
	}
</script>