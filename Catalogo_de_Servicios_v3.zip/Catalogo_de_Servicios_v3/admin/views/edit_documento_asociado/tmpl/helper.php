<?php

class OptionList{
var $text;
var $value;
var $disabled;	

function __construct(){
$text=null;
$value=null;			
$disabled=null;
}
	
}


class TreeNodeHelper{

var $IdDocumentos;
var $IdDoc;
var $Version;
var $Fecha;
var $RutaDoc_es;
var $RutaDoc_val;

function __construct(){

$IdDoc=null;
$IdDocumentos=null;
$Version=null;
$elem[]=null;
$Fecha=null;
$RutaDoc_es=null;
$Ruta_Doc_val=null;
}


public function getSortList(& $lists,& $lists_const,& $option=Array(),& $sprawdzone=Array()){

	$liczba = count($lists_const);
	foreach($lists as $list){

				$flaga=0;
				for($l=0;$l<count($sprawdzone);$l++){
					if($sprawdzone[$l]==$list->IdDocumentos){
						$flaga=1;
					}
				}
			
			if($flaga==0){
			$sprawdzone[]=$list->IdDocumentos;
			
			$this->IdDocumentos = $list->IdDocumentos;
			$this->IdDoc = $list->IdDoc;
			$this->Version = $list->Version;
                        $this->Version = $list->Version;
                        $this->Fecha = $list->Fecha;
                        $this->RutaDoc_es = $list->RutaDoc_es;
                        $this->RutaDoc_val = $list->RutaDoc_val;
			$op= new OptionList;
			$op->text=$this->Version;
			$op->value=$this->Id;
			$option[]=$op;
	
				
			}
	}
	return($option);		
}



}

?>

