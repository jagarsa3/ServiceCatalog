<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');



class serviciosViewavisos extends JView

{

	function display($tpl = null)

	{

		  $model =& $this->getModel();
		  $nl = $model->getAv();
		  $cats = $model->getAvisos();

    

		$this->assignRef('nl',$nl);
		$this->assignRef('list',$cats);

		

		JRequest::setVar('hidemainmenu',1);

		

		JToolBarHelper::title( JText::_('AVISOS'), 'generic.png');

		JToolBarHelper::save('saveAvisos', JText::_('SAVE'), 'save.png');

		JToolBarHelper::apply('applyAvisos', JText::_('APPLY'), 'apply.png');

		JToolBarHelper::cancel('cancelAvisos', JText::_('CANCEL'), 'cancel.png');


		parent::display($tpl);

	}

}



