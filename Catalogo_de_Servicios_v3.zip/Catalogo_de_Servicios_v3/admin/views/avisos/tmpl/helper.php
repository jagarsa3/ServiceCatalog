<?php

class OptionList{
var $text;
var $value;
var $disabled;	

function __construct(){
$text=null;
$value=null;			
$disabled=null;
}
	
}


class TreeNodeHelper{

var $Id;
var $Fecha;
var $TextoAviso;
var $IdServicio;
var $FechaFinAviso;

function __construct(){

$Id=null;
$Fecha=null;
$TextoAviso=null;
$elem[]=null;
$IdServicio=null;
$FechaFinAviso=null;
}


public function getSortList(& $lists,& $lists_const,& $option=Array(),& $sprawdzone=Array()){

	$liczba = count($lists_const);
	foreach($lists as $list){

				$flaga=0;
				for($l=0;$l<count($sprawdzone);$l++){
					if($sprawdzone[$l]==$list->Id){
						$flaga=1;
					}
				}
			
			if($flaga==0){
			$sprawdzone[]=$list->Id;
			
			
			$this->Id = $list->Id;
			$this->Fecha = $list->Fecha;
                        $this->TextoAviso = $list->TextoAviso;
                        $this->IdServicio = $list->IdServicio;
                        $this->FechaFinAviso = $list->FechaFinAviso;
			$op= new OptionList;
			$op->text=$this->TextoAviso;
			$op->value=$this->Id;
			$option[]=$op;
	
				
			}
	}
	return($option);		
}



}

?>

