<?php

defined ('_JEXEC') or die('Restricted access');

$editor =& JFactory::getEditor();
defined ('_JEXEC') or die('Restricted access');
require_once(dirname(__FILE__).DS.'helper.php');
$sort_list=$this->list;
$_list = new TreeNodeHelper();
JHTML::_('behavior.calendar');
$cid = JRequest::getVar('cid', array (), '', 'array');
$cidA = JRequest::getVar('cidA', array (), '', 'array');


if(isset($this->nl->Fecha))
{
    $anyo =  substr($this->nl->Fecha, 2, 2);  // abcd
    $mes =  substr($this->nl->Fecha, 5, 2);  // abcd
    $dia =  substr($this->nl->Fecha, 8, 2);  // abcd
    $this->nl->Fecha = $anyo."-".$mes."-".$dia;
}

if(isset($this->nl->FechaFinAviso))
{
    $anyo =  substr($this->nl->FechaFinAviso, 2, 2);  // abcd
    $mes =  substr($this->nl->FechaFinAviso, 5, 2);  // abcd
    $dia =  substr($this->nl->FechaFinAviso, 8, 2);  // abcd
    $this->nl->FechaFinAviso = $anyo."-".$mes."-".$dia;
}
   
?>
<?php 
?>
		<form action="index.php" method="post" name="adminForm" id="adminForm">
			<fieldset class="adminform">	
			<legend><?php echo JText::_('DETAIL'); ?></legend>
				<table class="admintable">
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('Fecha');?>
					</td>
					
					<td>
	

						<input class="inputbox" type="text" name="Fecha" id="Fecha" size="10" maxlength="10"
							value="<?php echo $this->nl->Fecha;?>" />
						<input type="reset" class="button" value="..."
							onclick="return showCalendar('Fecha','%y-%m-%d');"/>


					</td>
				</tr>
				<tr>
					 <td width="100" align="right" class="key">
						<?php echo JText::_('TextoAviso');?>
					</td>
  
<td>
			      
				<?php echo $editor->display( 'TextoAviso', $this->nl->TextoAviso, '100%', '10', '10', '5',true );?>
</td>
				</tr>
                                				<tr>
					 <td width="100" align="right" class="key">
						<?php echo JText::_('FechaFinAviso');?>
					</td>

<td>

				<input class="inputbox" type="text" name="FechaFinAviso" id="FechaFinAviso" size="10" maxlength="10"
							value="<?php echo $this->nl->FechaFinAviso;?>" />
						<input type="reset" class="button" value="..."
							onclick="return showCalendar('FechaFinAviso','%y-%m-%d');"/>

</td>
				</tr>

			</table>

			</fieldset>
                        <?php if(isset($cidA))
                        {
                            echo "<input type='hidden' name='Id' value='$cid[0]'/>";
                        }
                        ?>
                        <input type="hidden" name="IdServicio" value="<?php echo $cidA[0]; ?>" />
			<input type="hidden" name="option" value="<?php echo $option;?>" />
			<input type="hidden" name="task" value="avisos" />
			<input type="hidden" name="boxchecked" value="1" />
		</form>
<script language="javascript" type="text/javascript">



	function submitbutton(pressbutton) {
		//var form = document.adminForm;
		if (pressbutton == 'cancelAvisos') {
			submitform( pressbutton );
			return;
		}




                var anyo,mes,dia;

                dia = document.forms.adminForm.Fecha.value.substring(6,8);
                mes = document.forms.adminForm.Fecha.value.substring(3,5);
                anyo = document.forms.adminForm.Fecha.value.substring(0,2);


                temp = "2"+"0";
                anyo = temp+anyo;
                fecha_correcta=anyo+"-"+mes+"-"+dia;

                //document.forms.adminForm.Fecha.value = fecha_correcta;




                var anyoFin,mesFin,diaFin;

                diaFin = document.forms.adminForm.FechaFinAviso.value.substring(6,8);
                mesFin = document.forms.adminForm.FechaFinAviso.value.substring(3,5);
                anyoFin = document.forms.adminForm.FechaFinAviso.value.substring(0,2);


                tempFin = "2"+"0";
                anyoFin = tempFin+anyoFin;
                fecha_correctaFin=anyoFin+"-"+mesFin+"-"+diaFin;

                //document.forms.adminForm.FechaFinAviso.value = fecha_correctaFin;



                // COMPROBACIONES PARA LA FECHA AVISO

                if (document.forms.adminForm.Fecha.value==''){
                           var error = "<?php echo JText::_( 'Error14'); ?>";
                           alert(error);
                	   return false;
                }

                if (document.forms.adminForm.Fecha.value!=''){
			if(!validarFecha(dia,mes,anyo)){
                                document.forms.adminForm.Fecha.value='';
				var error = "<?php echo JText::_( 'Error14'); ?>";
                		alert(error);
                		return false;

	  		}

		}

                // VALIDAR FECHA
                valor = document.forms.adminForm.Fecha.value;
                if (document.forms.adminForm.Fecha.value!=''){
                    if( !(/^\d{2}\-\d{2}\-\d{2}$/.test(valor)) ) {
                        document.forms.adminForm.Fecha.value='';
                        var error = "<?php echo JText::_( 'Error14'); ?>";
                        alert(error);
                        return false;
                    }

                }


                // COMPROBACIONES PARA LA FECHA DEL FIN DEL AVISO

                if (document.forms.adminForm.FechaFinAviso.value==''){
                           var error = "<?php echo JText::_( 'Error14'); ?>";
                           alert(error);
                	   return false;
                }

                if (document.forms.adminForm.FechaFinAviso.value!=''){
			if(!validarFecha(diaFin,mesFin,anyoFin)){
                                document.forms.adminForm.FechaFinAviso.value='';
				var error = "<?php echo JText::_( 'Error14'); ?>";
                		alert(error);
                		return false;

	  		}

		}

                // VALIDAR FECHA
                valor = document.forms.adminForm.FechaFinAviso.value;
                if (document.forms.adminForm.FechaFinAviso.value!=''){
                    if( !(/^\d{2}\-\d{2}\-\d{2}$/.test(valor)) ) {
                        document.forms.adminForm.FechaFinAviso.value='';
                        var error = "<?php echo JText::_( 'Error14'); ?>";
                        alert(error);
                        return false;
                    }

                }

                fechaActual = new Date();
                diahoy = fechaActual.getDate();
                meshoy = fechaActual.getMonth() +1;
                anyohoy = fechaActual.getFullYear();
                if (diahoy <10) dia = "0" + dia;
                if (meshoy <10) mes = "0" + mes;


                // POSTERIOR A LA FECHA ACTUAL
                /*if (document.forms.adminForm.FechaFinAviso.value!=''){
                    if (DiferenciaFechas(diaFin,mesFin,anyoFin,diahoy,meshoy,anyohoy)<0){
                                document.forms.adminForm.FechaFinAviso.value='';
				var error = "<?php echo JText::_( 'Error20'); ?>";
                		alert(error);
                		return false;
                    }


                }*/

                // PERIODO DE FECHAS CORRECTO
                if (document.forms.adminForm.Fecha.value!='' && document.forms.adminForm.FechaFinAviso.value!=''){
                    if(restarFechasperiodos(dia,mes,diaFin,mesFin)<0) {
                        document.forms.adminForm.Fecha.value='';
                        document.forms.adminForm.FechaFinAviso.value='';
			var error = "<?php echo JText::_( 'Error18'); ?>";
                	alert(error);
                	return false;
                    }
                }



		
		submitform( pressbutton );

	}



	function validarEntero(valor)
        {
		//intento convertir a entero.
	    //si era un entero no le afecta, si no lo era lo intenta convertir a un numero decimal
	    valor = parseInt(valor,10);
	    //Compruebo si es un valor numérico
	    if (isNaN(valor)) {
		    return "";
	    }
		else{
	        return valor;
	    }
	}



        function validarFecha(dia,mes,anyo)
        {

	   	diaok=validarEntero(dia);
		mesok=validarEntero(mes);
		anyook=validarEntero(anyo);

		if((diaok!="" && diaok>0 && diaok<=31) && (mesok!="" && mesok>0 && mesok<=12) && (anyook!="" && anyook>=2000)){
			//comprobar febrero:
			if(mesok==2){
				if(diaok<=29){
					restoanyook=anyook%4;
					if(restoanyook > 0 && diaok>28)	return false;
					else return true;
				}
				else return false;
			}
			else if((mesok==4 || mesok==6 || mesok==9 || mesok==11) && diaok>30)
					return false;
			else return true;
		}
		 return false;
	}


        function DiferenciaFechas (dia,mes,anyo,diam,mesm,anyom) {

          //Obtiene objetos Date
          var miFecha1 = new Date( anyo, mes-1, dia )
          var miFecha2 = new Date( anyom, mesm-1, diam )

          //Resta fechas y redondea
          var diferencia = miFecha1.getTime() - miFecha2.getTime()
          var dias = Math.floor(diferencia / (1000 * 60 * 60 * 24))

          return dias
         }


         function restarFechasperiodos(diaini,mesini, diafin, mesfin)
        {
            diafunc = diafin - diaini;
            mesfunc = mesfin - mesini;
            mesfunc = mesfunc * 31;
            diafunc = diafunc + mesfunc;

            return diafunc;
        }





</script>