<?php

class OptionList{
var $text;
var $value;
var $disabled;	

function __construct(){
$text=null;
$value=null;			
$disabled=null;
}
	
}


class TreeNodeHelper{

var $Id;
var $Nombre;

function __construct(){

$Id=null;
$Nombre=null;
$elem[]=null;
}


public function getSortList(& $lists,& $lists_const,& $option=Array(),& $sprawdzone=Array()){

	$liczba = count($lists_const);
	foreach($lists as $list){

				$flaga=0;
				for($l=0;$l<count($sprawdzone);$l++){
					if($sprawdzone[$l]==$list->Id){
						$flaga=1;
					}
				}
			
			if($flaga==0){
			$sprawdzone[]=$list->Id;
			
			
			$this->Id = $list->Id;
			$this->Nombre = $list->Nombre;
			$op= new OptionList;
			$op->text=$this->NumCPV;
			$op->value=$this->Id;
			$option[]=$op;
	
				
			}
	}
	return($option);		
}



}

?>

