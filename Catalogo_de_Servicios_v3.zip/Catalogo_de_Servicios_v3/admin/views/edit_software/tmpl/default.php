<?php

defined ('_JEXEC') or die('Restricted access');

$editor =& JFactory::getEditor();
defined ('_JEXEC') or die('Restricted access');
require_once(dirname(__FILE__).DS.'helper.php');
$sort_list=$this->list;
$_list = new TreeNodeHelper();
   
?>
<?php 
?>
		<form action="index.php" method="post" name="adminForm" id="adminForm">
			<fieldset class="adminform">	
			<legend><?php echo JText::_('DETAIL'); ?></legend>
				<table class="admintable">
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('Nombre');?>
					</td>
					
					<td>
	
                                <input class="text_area" type="text" name="Nombre" id="Nombre" size="50" maxlength="250" value="<?php echo $this->nl->Nombre; ?>" />

					</td>
				</tr>

			</table>

			</fieldset>
			<input type="hidden" name="Id" value="<?php echo $this->nl->Id; ?>" />
			<input type="hidden" name="option" value="<?php echo $option;?>" />
			<input type="hidden" name="task" value="software" />
			<input type="hidden" name="boxchecked" value="1" />
		</form>
<script language="javascript" type="text/javascript">

	function submitbutton(pressbutton) {
		var form = document.adminForm;
		if (pressbutton == 'cancelSoftware') {
			submitform( pressbutton );
			return;
		}

		// do field validation
		if (form.Nombre.value == ""){
			alert( "<?php echo JText::_( 'ALERT_Nombre_NAME', true ); ?>" );
		} 
		else  {
			submitform( pressbutton );
		}
	}
</script>