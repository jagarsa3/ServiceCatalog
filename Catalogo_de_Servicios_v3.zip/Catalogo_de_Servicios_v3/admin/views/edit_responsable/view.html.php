<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');



class serviciosViewedit_responsable extends JView

{

	function display($tpl = null)

	{

		  $model =& $this->getModel();
		  $nl = $model->getResp();
		  $cats = $model->getResponsable();

    

		$this->assignRef('nl',$nl);
		$this->assignRef('list',$cats);

		

		JRequest::setVar('hidemainmenu',1);

		

		JToolBarHelper::title( JText::_('RESPONSABLE'), 'generic.png');

		JToolBarHelper::save('saveResponsable', JText::_('SAVE'), 'save.png');

		JToolBarHelper::apply('applyResponsable', JText::_('APPLY'), 'apply.png');

		JToolBarHelper::cancel('cancelResponsable', JText::_('CANCEL'), 'cancel.png');


		parent::display($tpl);

	}

}



