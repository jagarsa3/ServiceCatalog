<?php

class OptionList{
var $text;
var $value;
var $disabled;	

function __construct(){
$text=null;
$value=null;			
$disabled=null;
}
	
}


class TreeNodeHelper{

var $id;
var $nombre;
var $email;
var $telefono;
var $extension;


function __construct(){

$id=null;
$nombre=null;
$email=null;
$telefono=null;
$extension=null;
$elem[]=null;

}


public function getSortList(& $lists,& $lists_const,& $option=Array(),& $sprawdzone=Array()){

	$liczba = count($lists_const);
	foreach($lists as $list){

				$flaga=0;
				for($l=0;$l<count($sprawdzone);$l++){
					if($sprawdzone[$l]==$list->id){
						$flaga=1;
					}
				}
			
			if($flaga==0){
			$sprawdzone[]=$list->id;
			
			
			$this->id = $list->id;
			$this->nombre = $list->nombre;
			$op= new OptionList;
			$op->text=$this->nombre;
                        $op->text=$this->email;
                        $op->text=$this->telefono;
                        $op->text=$this->extension;
			$op->value=$this->id;
			$option[]=$op;
	
				
			}
	}
	return($option);		
}



}

?>

