<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');



class serviciosViewNocategoryitems extends JView

{

	function display($tpl = null)

	{
		$model =& $this->getModel();
		
		$limit = JRequest::getVar('limit', 5, '', 'int');
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');

		jimport('joomla.html.pagination');
		$lista_count_items = $model->getCount();
		$pagination = new JPagination($lista_count_items, $limitstart, $limit);


		$this->assignRef('pagination',$pagination);


		

		$nl = $model->getServicios();

		$this->assignRef('list',$nl);
		
		
		

		

		JToolBarHelper::title(JText::_('NO_CATEGORY_ITEMS'));
		
		JToolBarHelper::preferences('com_servicios','500');

		JToolBarHelper::addNew('addItem',JText::_('ADD'));

		JToolBarHelper::editList('editServicio',JText::_('EDIT'));

		JToolBarHelper::deleteList(JText::_('REMOVE_ACCEPTATION'),'removeItem');

		

		

    	JSubMenuHelper::addEntry(JText::_('CATEGORIES'), 'index.php?option=com_servicios', false);

		JSubMenuHelper::addEntry(JText::_('ITEMS'), 'index.php?option=com_servicios&task=servicios', false);

		JSubMenuHelper::addEntry(JText::_('NO_CATEGORY_ITEMS'), 'index.php?option=com_servicios&task=nocategoryitems', true);
		
		JSubMenuHelper::addEntry(JText::_('creadores'), 'index.php?option=com_servicios&task=creadores', false);

                JSubMenuHelper::addEntry(JText::_('HARDWARE'), 'index.php?option=com_servicios&task=hardware', false);

                JSubMenuHelper::addEntry(JText::_('SOFTWARE'), 'index.php?option=com_servicios&task=software', false);

                JSubMenuHelper::addEntry(JText::_('HOST'), 'index.php?option=com_servicios&task=host', false);

                JSubMenuHelper::addEntry(JText::_('RESPONSABLE'), 'index.php?option=com_servicios&task=responsable', false);

                JSubMenuHelper::addEntry(JText::_('DOCUMENTOS'), 'index.php?option=com_servicios&task=documentos', false);

		parent::display($tpl);

	}

}