<?php

defined ('_JEXEC') or die('Restricted access');

?>
<form action="index.php?option=com_servicios&task=nocategoryitems" method="post" name="adminForm">
    <table class="adminlist">
        <thead>
            <tr>
                <th width="20">
                    <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->list); ?>);"/>
                </th>
                <th width="5px">
                    <?php echo JText::_( 'id' ); ?>
                </th>
                <th width="100px">
                    <?php echo JText::_( 'NAME' ); ?>
                </th>
                <th width="200px">
                    <?php echo JText::_( 'DESCRIPTION' ); ?>
                </th>
                <th width="5px">
                    <?php echo JText::_( 'PUBLISHED' ); ?>
                </th>
            </tr>
        </thead>
        <?php $i=0; 
		

	foreach($this->list as $l): 

	$l->nombre_es = JHTML::link('index.php?option=com_servicios&task=editServicio&cid[]='.$l->id, $l->nombre_es);

	$checked = JHTML::_('grid.id', $i, $l->id );
	

	$published=JHTML::_('grid.published', $l, $i);

	?>
        <tr>
            <td>
                <?php echo $checked ?>
            </td>
            <td>
                <?php echo $l->id; ?>
            </td>
            <td>
                <?php echo $l->nombre_es; ?>
            </td>
            <td>
                <?php echo $l->intro_desc_es; ?>
            </td>
            <td align="center">
                <?php echo $published; ?>
            </td>
        </tr>
        <?php $i++; endforeach; ?>
    
    <tfoot>
        <td colspan="5">
            <?php echo $this->pagination->getListFooter(); ?>
        </td>
    </tfoot>
	</table>
    <input type="hidden" name="option" value="<?php echo $option; ?>" />
	<input type="hidden" name="task" value="items" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="t" value="nocategoryitems" />
</form>