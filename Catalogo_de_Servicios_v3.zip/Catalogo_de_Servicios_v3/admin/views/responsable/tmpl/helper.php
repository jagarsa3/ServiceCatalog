<?php

class TreeNodeHelper{

var $id;
var $nombre;
var $email;
var $telefono;
var $extension;
var $checked;

function __construct(){

$id=null;
$nombre=null;
$email=null;
$telefono=null;
$extension=null;
$checked=null;
}



public function getSortList(& $lists,& $lists_const,& $ii,& $obj=Array(),& $sprawdzone=Array()){
	$liczba = count($lists_const);
	foreach($lists as $list){
				$flaga=0;
 				for($l=0;$l<count($sprawdzone);$l++)
 				{
 					if($sprawdzone[$l]==$list->id)
 					{
 						$flaga=1;

					}

 				}
			
			if($flaga==0){
			$sprawdzone[]=$list->id;
			//print_r($obj);
			$this->id = $list->id;
			$this->nombre = $list->nombre;
			$this->email = $list->email;
                        $this->telefono = $list->telefono;
                        $this->extension = $list->extension;
			$this->checked = $list->checked;	
			$this->nombre = JHTML::link('index.php?option=com_servicios&task=edit_responsable&cid[]='.$this->id, $this->nombre);
			$checked = JHTML::_('grid.id', $ii, $list->id );
			$ii++;


			?>
        <tr>
            <td align="center">
                <?php echo $checked; ?>
            </td>
            <td align="center">
                <?php echo $this->id; ?>
            </td>
            <td align="center">
                <?php echo $this->nombre; ?>
            </td>
            <td align="center">
                <?php echo $this->email; ?>
            </td>
            <td align="center">
                <?php echo $this->telefono; ?>
            </td>
            <td align="center">
                <?php echo $this->extension; ?>
            </td>
        </tr>
			<?php	
				
			}
	}
				
	return(null);		
}



}

?>

