<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');



class serviciosViewresponsable extends JView

{

	function display($tpl = null)

	{

		$model =& $this->getModel();

		$nl = $model->getResponsable();

		$this->assignRef('list',$nl);
		
		$lists = array();
		
		global $mainframe, $option;
		
		
		$filter_state = $mainframe->getUserStateFromRequest($option.'filter_state', 'filter_state');
		
		$lists['state'] = JHTML::_('grid.state', $filter_state);
		
		$this->assignRef('lists', $lists);


		JToolBarHelper::title(JText::_('RESPONSABLE'));

		JToolBarHelper::preferences('com_servicios','500');

		JToolBarHelper::addNew('add_responsable',JText::_('ADD'));

		JToolBarHelper::editList('edit_responsable',JText::_('EDIT'));

		JToolBarHelper::deleteList(JText::_('REMOVE_ACCEPTATION'),'remove_responsable');

		

		

    	JSubMenuHelper::addEntry(JText::_('CATEGORIES'), 'index.php?option=com_servicios', false);

	JSubMenuHelper::addEntry(JText::_('ITEMS'), 'index.php?option=com_servicios&task=servicios', false);
		
	JSubMenuHelper::addEntry(JText::_('NO_CATEGORY_ITEMS'), 'index.php?option=com_servicios&task=nocategoryitems', false);
		
	JSubMenuHelper::addEntry(JText::_('CREADORES'), 'index.php?option=com_servicios&task=creadores', false);

        JSubMenuHelper::addEntry(JText::_('HARDWARE'), 'index.php?option=com_servicios&task=hardware', false);

        JSubMenuHelper::addEntry(JText::_('SOFTWARE'), 'index.php?option=com_servicios&task=software', false);

        JSubMenuHelper::addEntry(JText::_('HOST'), 'index.php?option=com_servicios&task=host', false);

        JSubMenuHelper::addEntry(JText::_('RESPONSABLE'), 'index.php?option=com_servicios&task=responsable', true);

        JSubMenuHelper::addEntry(JText::_('DOCUMENTOS'), 'index.php?option=com_servicios&task=documentos', false);

		parent::display($tpl);

	}

}