<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');



class serviciosViewedit_host extends JView

{

	function display($tpl = null)

	{

		  $model =& $this->getModel();
		  $nl = $model->getHo();
		  $cats = $model->getHost();

    

		$this->assignRef('nl',$nl);
		$this->assignRef('list',$cats);

		

		JRequest::setVar('hidemainmenu',1);

		

		JToolBarHelper::title( JText::_('HOST'), 'generic.png');

		JToolBarHelper::save('saveHost', JText::_('SAVE'), 'save.png');

		JToolBarHelper::apply('applyHost', JText::_('APPLY'), 'apply.png');

		JToolBarHelper::cancel('cancelHost', JText::_('CANCEL'), 'cancel.png');


		parent::display($tpl);

	}

}



