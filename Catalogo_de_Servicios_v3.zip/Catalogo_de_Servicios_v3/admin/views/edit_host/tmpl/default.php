<?php

defined ('_JEXEC') or die('Restricted access');

$editor =& JFactory::getEditor();
defined ('_JEXEC') or die('Restricted access');
require_once(dirname(__FILE__).DS.'helper.php');
$sort_list=$this->list;
$_list = new TreeNodeHelper();
   
?>
<?php 
?>
		<form action="index.php" method="post" name="adminForm" id="adminForm">
			<fieldset class="adminform">	
			<legend><?php echo JText::_('DETAIL'); ?></legend>
				<table class="admintable">
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('NombreDns');?>
					</td>
					
					<td>
	
                                <input class="text_area" type="text" name="NombreDns" id="NombreDns" size="50" maxlength="250" value="<?php echo $this->nl->NombreDns; ?>" />

					</td>
				</tr>
				<tr>
					 <td width="100" align="right" class="key">
						<?php echo JText::_('IdHw');?>
					</td>
  
<td>                            <?php
                                $dbhost =& JFactory::getDBO();
                                $IDhardware = $this->nl->IdHw;
                                $queryhost = "SELECT * FROM #__hardware WHERE IdHw='$IDharware'";
                                $dbhost->setQuery( $queryhost);
                                $rowserverhost = $dbhost->loadRow();
                                if(!$rowserverhost)
                                {
                                    $dbhost2 =& JFactory::getDBO();
                                    $queryhost2 = "SELECT * FROM #__hardware";
                                    $dbhost2->setQuery( $queryhost2);
                                    $rowserverhost2 = $dbhost2->loadObjectList();
                                }


                                ?>
                                 <select name="IdHw" >
                                        <option selected value="0"> <?php 
                                        if(!$rowserverhost) echo JText::_('Sin_Hardware_Asociado');
                                        else echo $rowserverhost[2];
                                        ?> </option>
					<?php                                        
					foreach ( $rowserverhost2 as $row )
					{
					?><option value="<?=$row->Id?>"><?php echo $row->MarcaModelo; ?></option><?php
					}
					?>
				 </select>

</td>




				</tr>

			</table>

			</fieldset>
			<input type="hidden" name="Id" value="<?php echo $this->nl->Id; ?>" />
			<input type="hidden" name="option" value="<?php echo $option;?>" />
			<input type="hidden" name="task" value="host" />
			<input type="hidden" name="boxchecked" value="1" />
		</form>
<script language="javascript" type="text/javascript">

	function submitbutton(pressbutton) {
		var form = document.adminForm;
		if (pressbutton == 'cancelHost') {
			submitform( pressbutton );
			return;
		}

		// do field validation
		if (form.NombreDns.value == ""){
			alert( "<?php echo JText::_( 'ALERT_NombreDns_NAME', true ); ?>" );
		} 
		else  {
			submitform( pressbutton );
		}
	}
</script>