<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');



class serviciosViewCategorias extends JView

{

	function display($tpl = null)

	{

		$model =& $this->getModel();

		$nl = $model->getCategorias();

		$this->assignRef('list',$nl);
		
		$lists = array();
		
		global $mainframe, $option;
		
		
		$filter_state = $mainframe->getUserStateFromRequest($option.'filter_state', 'filter_state');
		
		$lists['state'] = JHTML::_('grid.state', $filter_state);
		
		$this->assignRef('lists', $lists);


		JToolBarHelper::title(JText::_('CATEGORIES'));

		JToolBarHelper::preferences('com_servicios','500');

		JToolBarHelper::addNew('add',JText::_('ADD'));

		JToolBarHelper::editList('edit',JText::_('EDIT'));

		JToolBarHelper::deleteList(JText::_('REMOVE_ACCEPTATION'),'remove');

		

		

    	JSubMenuHelper::addEntry(JText::_('CATEGORIES'), 'index.php?option=com_servicios', true);

	JSubMenuHelper::addEntry(JText::_('ITEMS'), 'index.php?option=com_servicios&task=servicios', false);
		
	JSubMenuHelper::addEntry(JText::_('NO_CATEGORY_ITEMS'), 'index.php?option=com_servicios&task=nocategoryitems', false);
		
	JSubMenuHelper::addEntry(JText::_('CREADORES'), 'index.php?option=com_servicios&task=creadores', false);

        JSubMenuHelper::addEntry(JText::_('HARDWARE'), 'index.php?option=com_servicios&task=hardware', false);

        JSubMenuHelper::addEntry(JText::_('SOFTWARE'), 'index.php?option=com_servicios&task=software', false);

        JSubMenuHelper::addEntry(JText::_('HOST'), 'index.php?option=com_servicios&task=host', false);

        JSubMenuHelper::addEntry(JText::_('RESPONSABLE'), 'index.php?option=com_servicios&task=responsable', false);

        JSubMenuHelper::addEntry(JText::_('DOCUMENTOS'), 'index.php?option=com_servicios&task=documentos', false);

		parent::display($tpl);

	}

}