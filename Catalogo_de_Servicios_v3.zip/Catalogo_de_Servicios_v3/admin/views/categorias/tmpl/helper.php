<?php

class TreeNodeHelper{
var $idCategoria;
var $id;
var $name;
var $name2;
var $childs = Array();
var $level;
var $published;
var $checked;

function __construct(){
$idCategoria=null;
$id=null;
$name=null;
$name2=null;
$childs[]=null;
$elem[]=null;
$level=0;
$published=null;
$checked=null;
}



public function getSortList(& $lists,& $lists_const,& $ii,& $obj=Array(),& $sprawdzone=Array()){
	$liczba = count($lists_const);
	foreach($lists as $list){
				$flaga=0;
 				for($l=0;$l<count($sprawdzone);$l++)
 				{
 					if($sprawdzone[$l]==$list->id)
 					{
 						$flaga=1;

					}

 				}
			
			if($flaga==0){
			$sprawdzone[]=$list->id;
			//print_r($obj);
			$this->idCategoria = $list->idCategoria;
			$this->id = $list->id;
			$this->name = $list->nombre_es;
			$this->name2 = $list->nombre_val;
			$this->checked = $list->checked;
			//print_r($list);
			$this->published = $list->published;		
			$obj[]=$this;
			$this->name = JHTML::link('index.php?option=com_servicios&task=edit&cid[]='.$this->id, $this->name);
			$checked = JHTML::_('grid.id', $ii, $list->id );
			$published=JHTML::_('grid.published', $list, $ii);
			$ii++;


			?><tr>
            <td>
                <?php echo $checked; ?>
            </td>
            <td align="center">
                <?php echo $this->id; ?>
            </td>
            <td align="center">
                <?php echo $this->name; ?>
            </td>
            <td align="center">
                <?php echo $this->name2; ?>
            </td>
            <td align="center">
            	<?php echo $this->idCategoria;?>
                <?php echo $published;?>
            </td>
        </tr>
			<?php
			
			
				   for($i=0; $i<$liczba;$i++ ){
					if($lists_const[$i]->idCategoria==$list->id){		
						$child=new TreeNodeHelper();
						$child->id=$lists_const[$i]->id;
						$child->idCategoria=$lists_const[$i]->idCategoria;
						$child->level=$list->level+1;
						$child->published=$lists_const[$i]->published;
						$new_name=$lists_const[$i]->name;
							for($lev=0;$lev<$child->level;$lev++){
								$new_name="&nbsp;&nbsp;&nbsp;&nbsp;".$new_name;
							}
								
						$child->name=$new_name;

						
						$this->childs[]=$child;
						$this->getSortList($this->childs,$lists_const,$ii,$obj,$sprawdzone);
					
					}
				}	
				
			}
	}
				
	return(null);		
}



}

?>

