<?php

defined ('_JEXEC') or die('Restricted access');
require_once(dirname(__FILE__).DS.'helper.php');
$document=& JFactory::getDocument();
$lista=new serviciosModelServicios();
$sort_list=$lista->getCategorias();
$cs = JURI::base().'components/com_servicios/views/servicios/tmpl/style.css';

$document->addStyleSheet($cs); 

$cid = JRequest::getVar('cid',0,'','int');
$idCategoria = JRequest::getVar('idCategoria',0,'','int');

$limit = JRequest::getVar('limit', 10, '', 'int');
$limitstart = JRequest::getVar('limitstart', 0, '', 'int');

if (JRequest::getVar('order') == 'ordering' && $idCategoria!=0) 
	$ordering = true;
?>


<form action="index.php" method="get" name="adminForm">
<table style="float: left; margin-right: 20px;"><div id="mod_servicios">
<ul class="servicios" style="float: left; margin-right: 20px; margin-left:0px;">
	<?php
	$_list = new TreeNodeHelper();
$_list->getTreeList($sort_list); ?>
</ul></div>
	
</table>
<table>
	<tr>
      	<td align="left" width="100%">
      		<input type="text" nombre_es="find_nombre_es" size="30" maxlength="250" value="<?php echo JRequest::getVar('find_nombre_es');?>"/>
			<input type="submit" class="button" value="Buscar" />
        </td>
	</tr>
</table>
    <table class="adminlist" style="width: 80%;">
        <thead>
            <tr>
                <th width="5%">
                    <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->list); ?>);"/>
                </th>
                <th width="5%">
                    <a href="index.php?option=com_servicios&task=servicios&order=id&idCategoria=<?php echo $idCategoria ; ?>&limit=<?php echo $limit; ?>&limitstart=<?php echo $limitstart;?>"><?php echo JText::_( 'id' ); ?></a>
                </th>
                <th width="15%">
                    <a href="index.php?option=com_servicios&task=servicios&order=nombre_es&idCategoria=<?php echo $idCategoria ; ?>&limit=<?php echo $limit; ?>&limitstart=<?php echo $limitstart;?>"><?php echo JText::_( 'NAME' ); ?></a>
                </th>
                <th width="15%">
                    <a href="index.php?option=com_servicios&task=servicios&order=categoria&idCategoria=<?php echo $idCategoria ; ?>&limit=<?php echo $limit; ?>&limitstart=<?php echo $limitstart;?>"><?php echo JText::_( 'CATEGORY' ); ?></a>
                </th>
				<th width="15%">
                    <a href="index.php?option=com_servicios&task=servicios&order=producer&idCategoria=<?php echo $idCategoria ; ?>&limit=<?php echo $limit; ?>&limitstart=<?php echo $limitstart;?>"><?php echo JText::_( 'PRODUCER' ); ?></a>
                </th>
				<th width="10%" align="center">
                    <a href="index.php?option=com_servicios&task=servicios&order=ordering&idCategoria=<?php echo $idCategoria ; ?>&limit=<?php echo $limit; ?>&limitstart=<?php echo $limitstart;?>"><?php echo JText::_( 'POSITION' ); ?></a>
					<?php if ($ordering) 
							echo JHTML::_('grid.order',  $this->list ); 
						?>
                </th>
                <th width="5%">
                    <a href="index.php?option=com_servicios&task=servicios&order=published&idCategoria=<?php echo $idCategoria ; ?>&limit=<?php echo $limit; ?>&limitstart=<?php echo $limitstart;?>"><?php echo JText::_( 'PUBLISHED' ); ?></a>
                </th>
            </tr>
        </thead>
        <?php $i=0; 
		
for ($i=0, $n=count( $this->list ); $i < $n; $i++) {
		
	$l = &$this->list[$i]; 

	$l->nombre_es = JHTML::link('index.php?option=com_servicios&task=editServicio&cid[]='.$l->id, $l->nombre_es);
        


	$checked = JHTML::_('grid.id', $i, $l->id );
	

	$published=JHTML::_('grid.published', $l, $i);

	?>
        <tr>
            <td>
                <?php echo $checked ?>
            </td>
            <td>
                <?php echo $l->id; ?>
            </td>
            <td>

                <?php echo $l->nombre_es; ?>
            </td>
            <td>
                <?php echo $l->cat_nombre_es; ?>
            </td>
			<td>
                <?php echo $l->cr_nombre; ?>
            </td>
			<td class="order">
				<span><?php echo $this->pagination->orderUpIcon( $i, true,'orderup', 'Move Up', $ordering ); ?></span>
				<span><?php echo $this->pagination->orderDownIcon( $i, $n, true, 'orderdown', 'Move Down', $ordering ); ?></span>
				<?php $disabled = $ordering ?  '' : 'disabled="disabled"'; ?>
				<input type="text" name="order[]" size="5" value="<?php echo $l->ordering;?>" <?php echo $disabled ?> class="text_area" style="text-align: center" />
			</td>
            <td align="center">
                <?php echo $published; ?>
            </td>
        </tr>
        <?php } ?>
   
    <tfoot>
        <td colspan="7">
            <?php echo $this->pagination->getListFooter(); ?>
        </td>
    </tfoot>
	 </table>
    <input type="hidden" name="option" value="com_servicios" />
	<input type="hidden" name="task" value="servicios" />
	<input type="hidden" name="t" value="servicios" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="order" value="<?php echo JRequest::getVar('order') ?>" />
	<input type="hidden" name="idCategoria" value="<?php echo $idCategoria; ?>" />
</form>