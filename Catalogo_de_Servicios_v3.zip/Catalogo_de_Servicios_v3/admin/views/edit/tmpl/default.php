<?php

defined ('_JEXEC') or die('Restricted access');

$editor =& JFactory::getEditor();
defined ('_JEXEC') or die('Restricted access');
require_once(dirname(__FILE__).DS.'helper.php');
$sort_list=$this->list;
$_list = new TreeNodeHelper();
   
?>
<?php 
?>
		<form action="index.php" method="post" name="adminForm" id="adminForm">
			<fieldset class="adminform">	
			<legend><?php echo JText::_('DETAIL'); ?></legend>
				<table class="admintable">
				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('NOMBRE_ES');?>
					</td>
					
					<td>

<input class="text_area" type="text" name="nombre_es" id="nombre_es" size="50" maxlength="250" value="<?php echo $this->nl->nombre_es; ?>" />

					</td>
				</tr>
				<tr>
					 <td width="100" align="right" class="key">
						<?php echo JText::_('NOMBRE_VAL');?>
					</td>
  
<td>
			      
				<input class="text_area" type="text" name="nombre_val" id="nombre_val" size="50" maxlength="250" value="<?php echo $this->nl->nombre_val; ?>" />
</td>
				</tr>

				<tr>
					<td width="100" align="right" class="key">
						<?php echo JText::_('PARENT_CATEGORY');?>
					</td>
					<td>
                                                <?php
                                                $db =& JFactory::getDBO();
                                                $id_categoria = $this->nl->id;
                                                $query = "SELECT * FROM #__categorias WHERE id NOT LIKE '$id_categoria'";
                                                $db->setQuery( $query);
                                                $rowserver = $db->loadObjectList();

                                                $db1 =& JFactory::getDBO();
                                                $id_categoria1 = $this->nl->parent_id;
                                                $query1 = "SELECT * FROM #__categorias WHERE id='$id_categoria1'";
                                                $db1->setQuery( $query);
                                                $rowserver1 = $db1->loadRow();

                                                ?>
	


                                                <select name="parent_id" >
                                                <option selected value="<?php
                                                if($this->nl->parent_id !=0)
                                                {
                                                    echo $rowserver1[0];
                                                }
                                                else echo "0";
                                                ?>">
                                                <?php
                                                if($this->nl->parent_id !=0)
                                                {
                                                    
                                                    echo $rowserver1[1];
                                                }
                                                else echo "Categoría Principal";?>
                                                </option>
                                                <?php

                                                foreach ( $rowserver as $row )
                                                {
                                                ?><option value="<?=$row->id?>"><?php echo $row->nombre_es; ?></option><?php
                                                }
                                                if($this->nl->parent_id !=0)
                                                {
                                                    echo "<option value='0'>Categoría Principal</option>";
                                                }
                                                ?>
                                                </select>
					</td>
				</tr>
			</table>
			</fieldset>
			<input type="hidden" name="id" value="<?php echo $this->nl->id; ?>" />
			<input type="hidden" name="option" value="<?php echo $option;?>" />
			<input type="hidden" name="task" value="" />
			<input type="hidden" name="boxchecked" value="1" />
		</form>
<script language="javascript" type="text/javascript">

	function submitbutton(pressbutton) {
		var form = document.adminForm;
		if (pressbutton == 'cancel') {
			submitform( pressbutton );
			return;
		}

		// do field validation
		if (form.nombre_es.value == ""){
			alert( "<?php echo JText::_( 'ALERT_CATEGORY_NAME', true ); ?>" );
		}
                if (form.nombre_val.value == ""){
			alert( "<?php echo JText::_( 'ALERT_CATEGORY_NAME', true ); ?>" );
		}
		else  {
			submitform( pressbutton );
		}
	}
</script>