<?php

class OptionList{
var $text;
var $value;
var $disabled;	

function __construct(){
$text=null;
$value=null;			
$disabled=null;
}
	
}


class TreeNodeHelper{
var $idCategoria;
var $id;
var $nombre_es;
var $parent_id;
var $childs = Array();
var $level;

function __construct(){
$idCategoria=null;
$id=null;
$parent_id;
$nombre_es=null;
$childs[]=null;
$elem[]=null;
$level=0;
}


public function getSortList(& $lists,& $lists_const,& $option=Array(),& $sprawdzone=Array()){

	$liczba = count($lists_const);
	foreach($lists as $list){

				$flaga=0;
				for($l=0;$l<count($sprawdzone);$l++){
					if($sprawdzone[$l]==$list->id){
						$flaga=1;
					}
				}
			
			if($flaga==0){
			$sprawdzone[]=$list->id;
			
			$this->idCategoria = $list->idCategoria;
			$this->id = $list->id;
                        $this->parent_id = $list->parent_id;
			$this->nombre_es = $list->nombre_es;
			$op= new OptionList;
			$op->text=$this->nombre_es;
			$op->value=$this->id;
			$option[]=$op;
			
			
				   for($i=0; $i<$liczba;$i++ ){
					if($lists_const[$i]->idCategoria==$list->id){		
						$child=new TreeNodeHelper();
						$child->id=$lists_const[$i]->id;
						$child->idCategoria=$lists_const[$i]->idCategoria;
						$child->level=$list->level+1;
						$new_name=$lists_const[$i]->nombre_es;
							for($lev=0;$lev<$child->level;$lev++){
								$new_name="&nbsp;&nbsp;&nbsp;".$new_name;
							}
						$child->nombre_es=$new_name;

						
						$this->childs[]=$child;
						$this->getSortList($this->childs,$lists_const,$option,$sprawdzone);
					
					}
				}	
				
			}
	}
	return($option);		
}



}

?>

