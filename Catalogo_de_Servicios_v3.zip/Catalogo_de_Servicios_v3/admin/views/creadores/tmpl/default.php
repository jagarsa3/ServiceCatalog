<?php

defined ('_JEXEC') or die('Restricted access');


?>
<form action="index.php" method="post" name="adminForm">
	<table>
	<tr>
        		<td align="left" width="100%"></td>
				<td nowrap="nowrap">
					<?php echo $this->lists['state'];?>
				</td>
        	</tr>
			</table>
    <table class="adminlist">
        <thead>
            <tr>
                <th width="5%">
                   <!-- <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->list); ?>);"/>-->
                </th>
                <th width="20px">
                    <?php echo JText::_( 'ID' ); ?>
                </th>
                <th width="300px">
                   <?php echo JText::_( 'NOMBRE' ); ?>
                </th>
            </tr>
        </thead>
<?php $i=0; 
	foreach($this->list as $l):
	
$name = JHTML::link('index.php?option=com_servicios&task=editCreador&cid[]='.$l->id, $l->nombre);

	$checked = JHTML::_('grid.id', $i, $l->id );

		?>
		<tr>
            <td>
                <?php echo $checked ?>
            </td>
            <td align="center">
                <?php echo $l->id; ?>
            </td>
            <td align="center">
                <?php echo $l->nombre; ?>
            </td>
		</tr>
		<?php $i++; endforeach; ?>
	<tfoot>
        <td colspan="3" align="center">
            <?php echo $this->pagination->getListFooter(); ?>
        </td>
    </tfoot>	
    </table>	
    <input type="hidden" name="option" value="<?php echo $option; ?>" /><input type="hidden" name="task" value="creadores" /><input type="hidden" name="t" value="creadores" /><input type="hidden" name="boxchecked" value="0" />
</form>