<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');



class serviciosViewCreadores extends JView

{

	function display($tpl = null)

	{

		$model =& $this->getModel();

		$nl = $model->getCreadores();
		$limit = JRequest::getVar('limit', 25, '', 'int');
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		$cnl = $model->getCountCreadores();

		jimport('joomla.html.pagination');
		$pagination = new JPagination($cnl, $limitstart, $limit);

		$this->assignRef('list',$nl);
		$this->assignRef('pagination',$pagination);

		JToolBarHelper::title(JText::_('EDITAR_CREADORES'));
		
		JToolBarHelper::preferences('com_servicios','500');
		
		JToolBarHelper::addNew('addCreador',JText::_('ADD'));

		JToolBarHelper::editList('editCreador',JText::_('EDIT'));

		JToolBarHelper::deleteList(JText::_('REMOVE_ACCEPTATION'),'removeCreadores');

		

    	JSubMenuHelper::addEntry(JText::_('CATEGORIES'), 'index.php?option=com_servicios', false);

		JSubMenuHelper::addEntry(JText::_('ITEMS'), 'index.php?option=com_servicios&task=servicios', false);
		
		JSubMenuHelper::addEntry(JText::_('NO_CATEGORY_ITEMS'), 'index.php?option=com_servicios&task=nocategoryitems', false);
		
		JSubMenuHelper::addEntry(JText::_('CREADORES'), 'index.php?option=com_servicios&task=creadores', true);
                JSubMenuHelper::addEntry(JText::_('HARDWARE'), 'index.php?option=com_servicios&task=hardware', false);

                JSubMenuHelper::addEntry(JText::_('SOFTWARE'), 'index.php?option=com_servicios&task=software', false);

                JSubMenuHelper::addEntry(JText::_('HOST'), 'index.php?option=com_servicios&task=host', false);

                JSubMenuHelper::addEntry(JText::_('RESPONSABLE'), 'index.php?option=com_servicios&task=responsable', false);

                JSubMenuHelper::addEntry(JText::_('DOCUMENTOS'), 'index.php?option=com_servicios&task=documentos', false);

		parent::display($tpl);

	}

}