<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');



class serviciosViewedit_documentos extends JView

{

	function display($tpl = null)

	{

		  $model =& $this->getModel();
		  $nl = $model->getDocs();
		  $cats = $model->getDocumentos();

    

		$this->assignRef('nl',$nl);
		$this->assignRef('list',$cats);

		

		JRequest::setVar('hidemainmenu',1);

		

		JToolBarHelper::title( JText::_('DOCUMENTOS'), 'generic.png');

		JToolBarHelper::save('saveDocumentos', JText::_('SAVE'), 'save.png');

		JToolBarHelper::apply('applyDocumentos', JText::_('APPLY'), 'apply.png');

		JToolBarHelper::cancel('cancelDocumentos', JText::_('CANCEL'), 'cancel.png');


		parent::display($tpl);

	}

}



