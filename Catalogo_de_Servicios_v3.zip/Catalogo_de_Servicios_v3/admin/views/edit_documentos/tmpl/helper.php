<?php

class OptionList{
var $text;
var $value;
var $disabled;	

function __construct(){
$text=null;
$value=null;			
$disabled=null;
}
	
}


class TreeNodeHelper{

var $Id;
var $Descripcion_es;
var $Descripcion_val;

function __construct(){

$Id=null;
$Descripcion_es=null;
$elem[]=null;
$Descripcion_val=null;
}


public function getSortList(& $lists,& $lists_const,& $option=Array(),& $sprawdzone=Array()){

	$liczba = count($lists_const);
	foreach($lists as $list){

				$flaga=0;
				for($l=0;$l<count($sprawdzone);$l++){
					if($sprawdzone[$l]==$list->Id){
						$flaga=1;
					}
				}
			
			if($flaga==0){
			$sprawdzone[]=$list->Id;
			
			
			$this->Id = $list->Id;
			$this->Descripcion_es = $list->Descripcion_es;
			$op= new OptionList;
			$op->text=$this->Descripcion_es;
			$op->value=$this->Id;
			$option[]=$op;
	
				
			}
	}
	return($option);		
}



}

?>

