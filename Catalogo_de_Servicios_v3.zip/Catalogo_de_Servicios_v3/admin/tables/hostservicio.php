<?php

defined('_JEXEC') or die('Restricted access');



class Tablehostservicio extends JTable

{

        var $Id = null;
        var $IdHost = null;
	var $IdServicio = null;

	function __construct(&$db)

	{

		parent::__construct( '#__hostServicio','Id',$db);

	}

}

?>