<?php

defined('_JEXEC') or die('Restricted access');



class TableCreador extends JTable

{

	var $id = null;

	var $nombre = null;



	function __construct(&$db)

	{

		parent::__construct( '#__creador', 'id', $db);

	}

}

?>