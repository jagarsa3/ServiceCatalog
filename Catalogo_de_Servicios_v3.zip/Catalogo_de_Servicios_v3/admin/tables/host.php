<?php

defined('_JEXEC') or die('Restricted access');



class TableHost extends JTable

{
        var $Id = null;

	var $NombreDns = null;

	var $IdHw = null;



	function __construct(&$db)

	{

		parent::__construct( '#__host','Id',$db);

	}

}

?>