<?php

defined('_JEXEC') or die('Restricted access');



class Tableresponsableservicio extends JTable

{

        var $IdResponsableServicio = null;
        var $IdResponsable = null;
	var $IdServicio = null;
        var $IdOrden = null;

	function __construct(&$db)

	{

		parent::__construct( '#__responsableServicio','IdResponsableServicio',$db);

	}

}

?>