<?php

defined('_JEXEC') or die('Restricted access');



class TableSoftware extends JTable

{
        var $Id = null;

	var $Nombre = null;



	function __construct(&$db)

	{

		parent::__construct( '#__software','Id',$db);

	}

}

?>