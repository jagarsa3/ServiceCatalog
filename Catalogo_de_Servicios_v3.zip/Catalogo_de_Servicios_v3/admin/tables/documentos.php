<?php

defined('_JEXEC') or die('Restricted access');



class TableDocumentos extends JTable

{
        var $Id = null;

	var $Descripcion_es = null;

	var $Descripcion_val = null;



	function __construct(&$db)

	{

		parent::__construct( '#__tiposDoc','Id',$db);

	}

}

?>