<?php

defined('_JEXEC') or die('Restricted access');



class TableServicios extends JTable

{

	var $id = null;

	var $nombre_es = null;

	var $nombre_val = null;

	var $cat_id = null;
	
	var $producer_id = null;
	
	var $descripcion_es = null;
	
	var $intro_desc_es = null;
	
	var $price = null;
	
	var $image_url = null;
	
	var $files_url = null;

	var $ordering = 0;

	var $creador_id=null;


	function __construct(&$db)

	{

		parent::__construct( '#__servicios', 'id', $db);

	}

}

?>