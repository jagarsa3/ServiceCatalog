<?php

defined('_JEXEC') or die('Restricted access');



class TableAvisos extends JTable

{
	var $Id = null;
	var $Fecha = null;
	var $TextoAviso = null;
	var $IdServicio = null;
        var $FechaFinAviso = null;

	function __construct(&$db)

	{

		parent::__construct( '#__avisos', 'Id', $db);

	}

}

?>
