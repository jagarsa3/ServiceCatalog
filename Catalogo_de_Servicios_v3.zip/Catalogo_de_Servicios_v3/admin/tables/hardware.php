<?php

defined('_JEXEC') or die('Restricted access');



class TableHardware extends JTable

{
        var $Id = null;

	var $NumCPV = null;

	var $MarcaModelo = null;



	function __construct(&$db)

	{

		parent::__construct( '#__hardware','Id',$db);

	}

}

?>