<?php

defined('_JEXEC') or die('Restricted access');



class Tabledocumentosasociados extends JTable

{
        var $IdDocumentos = null;
        var $IdDoc = null;
        var $Version = null;
	var $Fecha = null;
        var $RutaDoc_es = null;
        var $RutaDoc_val = null;
        var $TipoDoc = null;
        var $IdServicio = null;

	function __construct(&$db)

	{

		parent::__construct( '#__documentosAsociados','IdDocumentos',$db);

	}

}

?>