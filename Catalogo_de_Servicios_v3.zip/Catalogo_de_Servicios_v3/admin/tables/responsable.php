<?php

defined('_JEXEC') or die('Restricted access');



class TableResponsable extends JTable

{
        var $id = null;

	var $nombre = null;

	var $email = null;

        var $telefono = null;

        var $extension = null;



	function __construct(&$db)

	{

		parent::__construct( '#__responsable','id',$db);

	}

}

?>