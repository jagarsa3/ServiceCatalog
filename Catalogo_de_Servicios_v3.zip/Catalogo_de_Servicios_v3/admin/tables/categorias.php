<?php

defined('_JEXEC') or die('Restricted access');



class TableCategorias extends JTable

{

	var $id = null;

	var $nombre_es = null;

	var $nombre_val = null;

        var $parent_id = null;



	function __construct(&$db)

	{

		parent::__construct( '#__categorias','id',$db);

	}

}

?>