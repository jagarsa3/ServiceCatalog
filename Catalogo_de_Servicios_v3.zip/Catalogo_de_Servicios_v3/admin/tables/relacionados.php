<?php

defined('_JEXEC') or die('Restricted access');



class TableRelacionados extends JTable

{
        var $IdRelacionados = null;
	var $Id_Serv_A = null;
	var $Id_Serv_B = null;
	var $Relacion_es = null;
	var $Relacion_val = null;
        var $se_relaciona_con = null;

	function __construct(&$db)

	{

		parent::__construct( '#__relacionados', 'IdRelacionados', $db);

	}

}

?>
