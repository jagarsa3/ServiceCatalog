<?php

defined('_JEXEC') or die('Restricted access');



class TableDependencias extends JTable

{
	var $idDependencia = null;
	var $IdServHijo = null;
	var $IdServPadre = null;
	var $descripcion = null;

	function __construct(&$db)

	{

		parent::__construct( '#__dependencias', 'idDependencia', $db);

	}

}

?>
