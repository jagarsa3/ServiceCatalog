<?php

defined('_JEXEC') or die('Restricted access');



class Tablehardwareservicio extends JTable

{

        var $IdHardware = null;
        var $IdHw = null;
	var $IdServicio = null;
        
	function __construct(&$db)

	{

		parent::__construct( '#__hardwareServicio','IdHardware',$db);

	}

}

?>