<?php

defined('_JEXEC') or die('Restricted access');



class Tablesoftwareservicio extends JTable

{

        var $IdSoftware = null;
        var $IdSw = null;
	var $IdServicio = null;

	function __construct(&$db)

	{

		parent::__construct( '#__softwareServicio','IdSoftware',$db);

	}

}

?>