<?php

defined('_JEXEC') or die ('Restricted access');
jimport('joomla.application.component.controller');
jimport('joomla.filesystem.file');
JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
$lang = & JFactory::GetLanguage();
$lang->load('com_servicios');

class serviciosController extends JController
{
    function __construct($default = array ())
    {
        parent::__construct($default);

        $this->registerTask('add', 'edit');
        $this->registerTask('addServicio', 'editServicio');
        $this->registerTask('apply', 'save');
        $this->registerTask('applyItem', 'saveItem');
        $this->registerTask('applyHardware', 'saveHardware');
        $this->registerTask('add_hardware','edit_hardware');
        //$this->registerTask('remove_hardware');
        $this->registerTask('applySoftware', 'saveSoftware');
        $this->registerTask('add_software','edit_software');
        //$this->registerTask('remove_software');
        $this->registerTask('applyHost', 'saveHost');
        $this->registerTask('add_host','edit_host');
        //$this->registerTask('remove_host');
        $this->registerTask('applyResponsable', 'saveResponsable');
        $this->registerTask('add_responsable','edit_responsable');
        //$this->registerTask('remove_responsable');
        $this->registerTask('applyDocumentos', 'saveDocumentos');
        $this->registerTask('add_documentos','edit_documentos');
        //$this->registerTask('remove_documentos');
        $this->registerTask('applyDocumentoasociado', 'saveDocumentoasociado');

        $this->registerTask('applyAvisos', 'saveAvisos');
        $this->registerTask('add_Avisos','edit_Avisos');
        
        //$this->registerTask('remove_Avisos');
        $this->registerTask('unpublish', 'publish');
        $this->registerTask('applyConfig', 'saveConfig');
	$this->registerTask('addCreador', 'editCreador');
	$this->registerTask('applyCreador', 'saveCreador');
		
		//$this->footer = '<br /><div style="margin: 0 auto; text-align: center; width: 100%"><a target="_blank" href="http://design-joomla.eu"><img src="'.JURI::base().'components/com_servicios/images/designjoomla.jpg" alt="Design-Joomla.eu" /><br/>joomla templates & addons</a></div>';
		$this->footer = '<br /><div style="margin: 0 auto; text-align: center; width: 100%"><br/></a></div>';
    }


    


    function display()
    {
        JRequest::setVar('view', 'categorias');
        parent::display(); echo $this->footer;
    }

    function makeimg($adres)
    {
        $par = &JComponentHelper::getParams( 'com_servicios' );
    
    	$nw = -1;
		$nh = -1;
		
        $nw = (int)$par->get('th_width',-1);
        $nh = (int)$par->get('th_height',-1);
		
		/* ------------------- */
		if (!$adres)
            return false;
		
		 if (! list ($w, $h, $type, $attr) = getimagesize($adres)) {
            if (! list ($w, $h, $type, $attr) = getimagesize($adres)) {
                return false;
    	    }
	    }
		
        switch($type)
        {
            case 1:
                $simg = imagecreatefromgif($adres);
                break;
            case 2:
                $simg = imagecreatefromjpeg($adres);
                break;
            case 3:
                $simg = imagecreatefrompng($adres);
                break;
        }
		
		$x = 0;
		$y = 0;
		$cw = $w;
		$ch = $h;
		
		$nw_half = (int)floor($nw/2);
		$nh_half = (int)floor($nh/2);
		$w_half = (int)floor($w/2);
		$h_half = (int)floor($h/2);
		
		if ($nw == 0 && $nh == 0) {
			$nw = 200;
			$nh = (int)(floor(($nw * $h) / $w));
		}
		elseif ($nw == 0) {
			$nw = (int)(floor(($nh * $w) / $h));
		}
		elseif ($nh == 0) {
			$nh = (int)(floor(($nw * $h) / $w));
		}
		elseif ($nw < $w || $nh < $h) {
	        if ($nw <= $nh)
	        {
				if ($w <= $h) {
					$ch = $h;
					$temp_w = (int)floor(($h * $nw)/$nh);
					if ($temp_w > $w) {
						$cw = $w;
					}
					else {
						$cw = $temp_w;
						$x = $w_half - (int)($temp_w/2);
					}
				}
				elseif ($w > $h) {
					$ch = $h;
					$temp_w = (int)floor(($h * $nw)/$nh);
					if ($temp_w > $w) {
						$cw = $w;
					}
					else {
						$cw = $temp_w;
						$x = $w_half - (int)($temp_w/2);
					}
				}
	        } 
			elseif ($nw > $nh) {
	        	if ($w <= $h) {
					$cw = $w;
					$temp_h = (int)floor(($nh * $w)/$nw);
					if ($temp_h > $h) {
						$ch = $h;
					}
					else {
						$ch = $temp_h;
						$y = $h_half - (int)($temp_h/2);
					}
				}
				elseif ($w > $h) {
					$cw = $w;
					$temp_h = (int)floor(($nh * $w)/$nw);
					if ($temp_h > $h) {
						$ch = $h;
					}
					else {
						$ch = $temp_h;
						$y = $h_half - (int)($temp_h/2);
					}
				}        
	        }
		}
		elseif ($nw == -1 || $nh == -1) {
			return false;
		}
		$dimg = imagecreatetruecolor($nw, $nh);
		$bgColor = imagecolorallocate($dimg, 255, 255, 255);
	    imagefill($dimg, 0, 0, $bgColor);
 		imagecopyresampled($dimg, $simg, 0, 0, $x, $y, $nw, $nh, $cw, $ch);
		
		$thumb_path = $adres.'.th.jpg';
	    if (is_file($thumb_path))
			unlink($thumb_path);
	  
	    imagejpeg($dimg, $thumb_path, 85);
		
		return true;
	}
		
    function makeimg_s($adres)
    {
        $par = &JComponentHelper::getParams( 'com_servicios' );
    
    	$nw = -1;
		$nh = -1;
        $nw = $par->get('smallth_width',-1);
        $nh = $par->get('smallth_height',-1);
		
		/* ------------------- */
		if (!$adres)
            return false;
		
		 if (! list ($w, $h, $type, $attr) = getimagesize($adres)) {
            if (! list ($w, $h, $type, $attr) = getimagesize($adres)) {
                return false;
    	    }
	    }
		
        switch($type)
        {
            case 1:
                $simg = imagecreatefromgif($adres);
                break;
            case 2:
                $simg = imagecreatefromjpeg($adres);
                break;
            case 3:
                $simg = imagecreatefrompng($adres);
                break;
        }
		
		$x = 0;
		$y = 0;
		$cw = $w;
		$ch = $h;
		
		$nw_half = (int)floor($nw/2);
		$nh_half = (int)floor($nh/2);
		$w_half = (int)floor($w/2);
		$h_half = (int)floor($h/2);
		
		if ($nw == 0 && $nh == 0) {
			$nw = 50;
			$nh = (int)(floor(($nw * $h) / $w));
		}
		elseif ($nw == 0) {
			$nw = (int)(floor(($nh * $w) / $h));
		}
		elseif ($nh == 0) {
			$nh = (int)(floor(($nw * $h) / $w));
		}
		elseif ($nw < $w || $nh < $h) {
	        if ($nw <= $nh)
	        {
				if ($w <= $h) {
					$ch = $h;
					$temp_w = (int)floor(($h * $nw)/$nh);
					if ($temp_w > $w) {
						$cw = $w;
					}
					else {
						$cw = $temp_w;
						$x = $w_half - (int)($temp_w/2);
					}
				}
				elseif ($w > $h) {
					$ch = $h;
					$temp_w = (int)floor(($h * $nw)/$nh);
					if ($temp_w > $w) {
						$cw = $w;
					}
					else {
						$cw = $temp_w;
						$x = $w_half - (int)($temp_w/2);
					}
				}
	        } 
			elseif ($nw > $nh) {
	        	if ($w <= $h) {
					$cw = $w;
					$temp_h = (int)floor(($w * $nh)/$nw);
					if ($temp_h > $h) {
						$ch = $h;
					}
					else {
						$ch = $temp_h;
						$y = $h_half - (int)($temp_h/2);
					}
				}
				elseif ($w > $h) {
					$cw = $w;
					$temp_h = (int)floor(($nh * $w)/$nw);
					if ($temp_h > $h) {
						$ch = $h;
					}
					else {
						$ch = $temp_h;
						$y = $h_half - (int)($temp_h/2);
					}
				}        
	        }
		}
		elseif ($nw == -1 || $nh == -1) {
			return false;
		}
		$dimg = imagecreatetruecolor($nw, $nh);
		$bgColor = imagecolorallocate($dimg, 255, 255, 255);
	    imagefill($dimg, 0, 0, $bgColor);
		
 		imagecopyresampled($dimg, $simg, 0, 0, $x, $y, $nw, $nh, $cw, $ch);
		
		$thumb_path = $adres.'.ths.jpg';
	    if (is_file($thumb_path))
			unlink($thumb_path);
	  
	    imagejpeg($dimg, $thumb_path, 85);
		
		return true;
	}

    function servicios()
    {
        JRequest::setVar('view', 'servicios');
        parent::display(); echo $this->footer;
    }
    
    function creadores()
    {
        JRequest::setVar('view', 'creadores');
        parent::display(); echo $this->footer;
    }

     function hardware()
    {
        JRequest::setVar('view', 'hardware');
        parent::display(); echo $this->footer;
    }

    function software()
    {
        JRequest::setVar('view', 'software');
        parent::display(); echo $this->footer;
    }

    function host()
    {
        JRequest::setVar('view', 'host');
        parent::display(); echo $this->footer;
    }

    function responsable()
    {
        JRequest::setVar('view', 'responsable');
        parent::display(); echo $this->footer;
    }

    function documentos()
    {
        JRequest::setVar('view', 'documentos');
        parent::display(); echo $this->footer;
    }



    function config()
    {
        JRequest::setVar('view', 'config');
        parent::display(); echo $this->footer;
    }
    
    function edit()
    {
        JRequest::setVar('view', 'edit');
        parent::display(); echo $this->footer;
    }
    
    function nocategoryitems()
    {
        JRequest::setVar('view', 'nocategoryitems');
        parent::display(); echo $this->footer;
    }
	
	function editCreador()
	{	
		JRequest::setVar('view','editCreador');
		parent::display(); echo $this->footer;
	}

	function edit_hardware()
	{
		JRequest::setVar('view','edit_hardware');
		parent::display(); echo $this->footer;
	}

        function edit_software()
	{
		JRequest::setVar('view','edit_software');
		parent::display(); echo $this->footer;
	}

        function edit_host()
	{
		JRequest::setVar('view','edit_host');
		parent::display(); echo $this->footer;
	}

        function edit_responsable()
	{
		JRequest::setVar('view','edit_responsable');
		parent::display(); echo $this->footer;
	}

        function edit_documentos()
	{
		JRequest::setVar('view','edit_documentos');
		parent::display(); echo $this->footer;
	}

        function edit_documento_asociado()
	{
		JRequest::setVar('view','edit_documento_asociado');
		parent::display(); echo $this->footer;
	}

        function edit_Avisos()
	{
		JRequest::setVar('view','avisos');
		parent::display(); echo $this->footer;
	}

function editServicio()
{
    JRequest::setVar('view', 'editservicio');
    parent::display(); echo $this->footer;
}




function save()
{
    global $mainframe;
    $row = & JTable::getInstance('categorias', 'table');
    if (!$row->bind(JRequest::get('post')))
    {
        echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
        exit ();
    }
	
    if (!$row->store())
    {
        echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
        exit ();
    }
    switch($this->_task)
    {
        case 'apply':
            $link = 'index.php?option=com_servicios&task=edit&cid[]='.$row->id;
            $msg = JText::_('CHANGES_SAVED');
            break;
        case 'save':
        default:
            $link = 'index.php?option=com_servicios';
            $msg = JText::_('ITEM_SAVED');
            break;
    }
    
    $mainframe->redirect($link, $msg);
}


function saveCreador()
	{
		global $mainframe;
		$row =& JTable::getInstance('creador','table');
		if(!$row->bind(JRequest::get('post')))
		{
			echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
			exit();
		}
			if(!$row->store())
		{
			echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
			exit();
		}
		switch($this->_task)
		{
			case 'applyCreador':
				$link = 'index.php?option=com_servicios&task=editCreador&cid[]='.$row->id;
				$msg = JText::_('CHANGES_SAVED');
				break;
			case 'saveCreador':
			default:
				$link = 'index.php?option=com_servicios&task=creadores';
				$msg = JText::_('ITEM_SAVED');
				break;
		}

		$mainframe->redirect($link, $msg);
	}



function saveHardware()
{
    global $mainframe;

    
    
    $row = & JTable::getInstance('hardware', 'table');
    if (!$row->bind(JRequest::get('post')))
    {

        echo "<script> alert('".$row->getError()."');

			window.history.go(-1); </script>\n";

        exit ();

    }

    if (!$row->store())
    {
        echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
        exit ();
    }

    switch($this->_task)
    {
        case 'applyHardware':
            $link = 'index.php?option=com_servicios&task=edit_Hardware&cid[]='.$row->Id;
            $msg = JText::_('CHANGES_SAVED');
            break;
        case 'saveHardware':
        default:
            $link = 'index.php?option=com_servicios&task=hardware';
            $msg = JText::_('ITEM_SAVED');
            break;
    }
    $mainframe->redirect($link, $msg);



}



function saveSoftware()
{
    global $mainframe;



    $row = & JTable::getInstance('software', 'table');
    if (!$row->bind(JRequest::get('post')))
    {

        echo "<script> alert('".$row->getError()."');

			window.history.go(-1); </script>\n";

        exit ();

    }

    if (!$row->store())
    {
        echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
        exit ();
    }

    switch($this->_task)
    {
        case 'applySoftware':
            $link = 'index.php?option=com_servicios&task=edit_Software&cid[]='.$row->Id;
            $msg = JText::_('CHANGES_SAVED');
            break;
        case 'saveSoftware':
        default:
            $link = 'index.php?option=com_servicios&task=software';
            $msg = JText::_('ITEM_SAVED');
            break;
    }
    $mainframe->redirect($link, $msg);



}



function saveHost()
{
    global $mainframe;



    $row = & JTable::getInstance('host', 'table');
    if (!$row->bind(JRequest::get('post')))
    {

        echo "<script> alert('".$row->getError()."');

			window.history.go(-1); </script>\n";

        exit ();

    }

    if (!$row->store())
    {
        echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
        exit ();
    }

    switch($this->_task)
    {
        case 'applyHost':
            $link = 'index.php?option=com_servicios&task=edit_Host&cid[]='.$row->Id;
            $msg = JText::_('CHANGES_SAVED');
            break;
        case 'saveHost':
        default:
            $link = 'index.php?option=com_servicios&task=host';
            $msg = JText::_('ITEM_SAVED');
            break;
    }
    $mainframe->redirect($link, $msg);



}


function saveResponsable()
{
    global $mainframe;



    $row = & JTable::getInstance('responsable', 'table');
    if (!$row->bind(JRequest::get('post')))
    {

        echo "<script> alert('".$row->getError()."');

			window.history.go(-1); </script>\n";

        exit ();

    }

    if (!$row->store())
    {
        echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
        exit ();
    }

    switch($this->_task)
    {
        case 'applyResponsable':
            $link = 'index.php?option=com_servicios&task=edit_Responsable&cid[]='.$row->id;
            $msg = JText::_('CHANGES_SAVED');
            break;
        case 'saveResponsable':
        default:
            $link = 'index.php?option=com_servicios&task=responsable';
            $msg = JText::_('ITEM_SAVED');
            break;
    }
    $mainframe->redirect($link, $msg);



}

function saveDocumentos()
{
    global $mainframe;



    $row = & JTable::getInstance('documentos', 'table');
    if (!$row->bind(JRequest::get('post')))
    {

        echo "<script> alert('".$row->getError()."');

			window.history.go(-1); </script>\n";

        exit ();

    }


    if (!$row->store())
    {
        echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
        exit ();
    }

    switch($this->_task)
    {
        case 'applyDocumentos':
            $link = 'index.php?option=com_servicios&task=edit_Documentos&cid[]='.$row->Id;
            $msg = JText::_('CHANGES_SAVED');
            break;
        case 'saveDocumentos':
        default:
            $link = 'index.php?option=com_servicios&task=documentos';
            $msg = JText::_('ITEM_SAVED');
            break;
    }
    $mainframe->redirect($link, $msg);



}


function saveDocumentoAsociado()
{
    global $mainframe;



    $row = & JTable::getInstance('documentosasociados', 'table');
    $cid = JRequest::getVar('IdServicio');

    if (!$row->bind(JRequest::get('post')))
    {

        echo "<script> alert('".$row->getError()."');

			window.history.go(-1); </script>\n";

        exit ();

    }

    $row->RutaDoc_es = JRequest::getVar('RutaDoc_es', '', 'post', 'string', JREQUEST_ALLOWRAW);
    $row->RutaDoc_val = JRequest::getVar('RutaDoc_val', '', 'post', 'string', JREQUEST_ALLOWRAW);

    if (!$row->store())
    {
        echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
        exit ();
    }

    switch($this->_task)
    {
        case 'applyDocumentoasociado':
            $link = 'index.php?option=com_servicios&task=edit_documento_asociado&cid[]='.$row->IdDoc.'&cidS[]='.$cid;
            $msg = JText::_('CHANGES_SAVED');
            break;
        case 'saveDocumentoasociado':
        default:
            
            $link = 'index.php?option=com_servicios&task=editServicio&cid[]='.$cid;
            $msg = JText::_('ITEM_SAVED');
            break;
    }
    $mainframe->redirect($link, $msg);



}

function saveAvisos()
{
    global $mainframe;



    $row = & JTable::getInstance('avisos', 'table');
    $cid = JRequest::getVar('IdServicio');
    if (!$row->bind(JRequest::get('post')))
    {

        echo "<script> alert('".$row->getError()."');

			window.history.go(-1); </script>\n";

        exit ();

    }

    if (!$row->store())
    {
        echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
        exit ();
    }

    switch($this->_task)
    {
        case 'applyAvisos':
            $link = 'index.php?option=com_servicios&task=edit_avisos&cidA[]='.$cid.'&cid[]='.$row->Id;
            $msg = JText::_('CHANGES_SAVED');
            break;
        case 'saveAvisos':
        default:
            $link = 'index.php?option=com_servicios&task=editServicio&cid[]='.$cid;
            $msg = JText::_('ITEM_SAVED');
            break;
    }
    $mainframe->redirect($link, $msg);



}


function saveItem()

{

    global $mainframe;

    
    
    $row = & JTable::getInstance('servicios', 'table');
    if (!$row->bind(JRequest::get('post')))
    {

        echo "<script> alert('".$row->getError()."');

			window.history.go(-1); </script>\n";

        exit ();

    }
    $avisos = $_POST['avisos'];
    if($avisos == 0)
    {
        $db_aviso =& JFactory::getDBO();
        $query_aviso = "DELETE FROM #__avisos WHERE IdServicio IN ( ".$row->id." )";
        $db_aviso->setQuery($query_aviso);
        if (!$db_aviso->query())
        {
            echo "script alert('".$db_aviso->getErrorMsg()."');
			window.history.go(-1); </script>\n";
        }
    }



    // BORRAMOS LAS DEPENDENCIAS DE LA BD
    $row->disponibilidad = $_POST['disponibilidad'];
    if($row->disponibilidad == 0)
    {
        disponible_hijos($row->id);
    }
    
    //JError::raiseWarning( 500, $disponible."HOLA" );
    //echo $row->diponibilidad."HOLA";
    //$files = $row->files_url;
    $dependencias = $_POST['usun_depend'];
        
    for ($i = 0; $i < count($dependencias); $i++)
    {




        $db_dependencias =& JFactory::getDBO();
        $query_dependencias = "SELECT * FROM #__dependencias WHERE IdServHijo='$row->id' and IdServPadre='$dependencias[$i]'";
        $db_dependencias->setQuery( $query_dependencias);
        $rowserver_dependencias = $db_dependencias->loadRow();
        //JError::raiseWarning( 500, $rowserver_dependencias[0]."HOLA" );
        $db_ab =& JFactory::getDBO();
        $query_ab = "DELETE FROM #__dependencias WHERE IdDependencias IN ( ".$rowserver_dependencias[0]." )";
        //JError::raiseWarning( 500, $rowserver_dependencias[0].$query_ab."HOLA" );
        $db_ab->setQuery($query_ab);
        if (!$db_ab->query())
        {
            echo "script alert('".$db_ab->getErrorMsg()."');
			window.history.go(-1); </script>\n";
        }
        
    }



     $relacion = $_POST['usun_relacion'];

    for ($i = 0; $i < count($relacion); $i++)
    {

        $db_relacion =& JFactory::getDBO();
        $query_relacion = "DELETE FROM #__relacionados WHERE Id_Serv_A IN ( ".$row->id." ) and Id_Serv_B IN ( ".$relacion[$i]." )";
        $db_relacion->setQuery( $query_relacion);
        $rowserver_relacion = $db_relacion->loadRow();
        //JError::raiseWarning( 500, $rowserver_dependencias[0]."HOLA" );
        //$db_ab =& JFactory::getDBO();
        //$query_ab = "DELETE FROM #__relacionServicio WHERE IdHW IN ( ".$rowserver_dependencias[0]." )";
        //JError::raiseWarning( 500, $rowserver_dependencias[0].$query_ab."HOLA" );
        //$db_ab->setQuery($query_ab);
        if (!$db_relacion->query())
        {
            echo "script alert('".$db_relacion->getErrorMsg()."');
			window.history.go(-1); </script>\n";
        }

    }

    $plik_relacion = $_POST['servicios_relacion'];

    for ($i = 0; $i < count($plik_relacion); $i++)
    {
        $row_relacion = & JTable::getInstance('relacionados', 'table');

        if (!$row_relacion->bind(JRequest::get('post'))) {
            return JError::raiseWarning( 500, $row_relacion->getError() );
        }

        if($plik_relacion[$i] == '0');
        else
        {

            $row_relacion->Id_Serv_B = $plik_relacion[$i];

            $row_relacion->Id_Serv_A = $row->id;

            if(repetido_relacionados($row_relacion->Id_Serv_B,$row_relacion->Id_Serv_A) == 1);
            else{

                if (!$row_relacion->store())
                {
                    return JError::raiseWarning( 500, $row_relacion->getError() );
                }
            }

        }
    }





    $hardware = $_POST['usun_hardware'];

    for ($i = 0; $i < count($hardware); $i++)
    {

        $db_hardware =& JFactory::getDBO();
        $query_hardware = "DELETE FROM #__hardwareServicio WHERE IdHw IN ( ".$hardware[$i]." ) and IdServicio IN ( ".$row->id." )";
        $db_hardware->setQuery( $query_hardware);
        $rowserver_hardware = $db_hardware->loadRow();
        //JError::raiseWarning( 500, $rowserver_dependencias[0]."HOLA" );
        //$db_ab =& JFactory::getDBO();
        //$query_ab = "DELETE FROM #__hardwareServicio WHERE IdHW IN ( ".$rowserver_dependencias[0]." )";
        //JError::raiseWarning( 500, $rowserver_dependencias[0].$query_ab."HOLA" );
        //$db_ab->setQuery($query_ab);
        if (!$db_hardware->query())
        {
            echo "script alert('".$db_hardware->getErrorMsg()."');
			window.history.go(-1); </script>\n";
        }

    }

    $plik_hardware = $_POST['servicios_depende_hardware'];
    
    for ($i = 0; $i < count($plik_hardware); $i++)
    {
        $row_hardware = & JTable::getInstance('hardwareservicio', 'table');

        if (!$row_hardware->bind(JRequest::get('post'))) {
            return JError::raiseWarning( 500, $row_hardware->getError() );
        }
        
        if($plik_hardware[$i] == '0');
        else
        {

            $row_hardware->IdHw = $plik_hardware[$i];

            $row_hardware->IdServicio = $row->id;

            if(repetido_hardware($row_hardware->IdHw,$row_hardware->IdServicio) == 1);
            else{

                if (!$row_hardware->store())
                {
                    return JError::raiseWarning( 500, $row_hardware->getError() );
                }
            }
           
        }
    }




    $software = $_POST['usun_software'];

    for ($i = 0; $i < count($software); $i++)
    {

        $db_software =& JFactory::getDBO();
        $query_software = "DELETE FROM #__softwareServicio WHERE IdSw IN ( ".$software[$i]." ) and IdServicio IN ( ".$row->id." )";
        $db_software->setQuery( $query_software);
        $rowserver_software = $db_software->loadRow();
        //JError::raiseWarning( 500, $rowserver_dependencias[0]."HOLA" );
        //$db_ab =& JFactory::getDBO();
        //$query_ab = "DELETE FROM #__softwareServicio WHERE IdHW IN ( ".$rowserver_dependencias[0]." )";
        //JError::raiseWarning( 500, $rowserver_dependencias[0].$query_ab."HOLA" );
        //$db_ab->setQuery($query_ab);
        if (!$db_software->query())
        {
            echo "script alert('".$db_software->getErrorMsg()."');
			window.history.go(-1); </script>\n";
        }

    }

    $plik_software = $_POST['servicios_depende_software'];

    for ($i = 0; $i < count($plik_software); $i++)
    {
        $row_software = & JTable::getInstance('softwareservicio', 'table');

        if (!$row_software->bind(JRequest::get('post'))) {
            return JError::raiseWarning( 500, $row_software->getError() );
        }

        if($plik_software[$i] == '0');
        else
        {

            $row_software->IdSw = $plik_software[$i];

            $row_software->IdServicio = $row->id;

            if(repetido_software($row_software->IdSw,$row_software->IdServicio) == 1);
            else{

                if (!$row_software->store())
                {
                    return JError::raiseWarning( 500, $row_software->getError() );
                }
            }

        }
    }


    $host = $_POST['usun_host'];

    for ($i = 0; $i < count($host); $i++)
    {

        $db_host =& JFactory::getDBO();
        $query_host = "DELETE FROM #__hostServicio WHERE IdHost IN ( ".$host[$i]." ) and IdServicio IN ( ".$row->id." )";
        $db_host->setQuery( $query_host);
        $rowserver_host = $db_host->loadRow();
        //JError::raiseWarning( 500, $rowserver_dependencias[0]."HOLA" );
        //$db_ab =& JFactory::getDBO();
        //$query_ab = "DELETE FROM #__hostServicio WHERE IdHW IN ( ".$rowserver_dependencias[0]." )";
        //JError::raiseWarning( 500, $rowserver_dependencias[0].$query_ab."HOLA" );
        //$db_ab->setQuery($query_ab);
        if (!$db_host->query())
        {
            echo "script alert('".$db_host->getErrorMsg()."');
			window.history.go(-1); </script>\n";
        }

    }

    $plik_host = $_POST['servicios_depende_host'];

    for ($i = 0; $i < count($plik_host); $i++)
    {
        $row_host = & JTable::getInstance('hostservicio', 'table');

        if (!$row_host->bind(JRequest::get('post'))) {
            return JError::raiseWarning( 500, $row_host->getError() );
        }

        if($plik_host[$i] == '0');
        else
        {

            $row_host->IdHost = $plik_host[$i];

            $row_host->IdServicio = $row->id;

            if(repetido_host($row_host->IdHost,$row_host->IdServicio) == 1);
            else{

                if (!$row_host->store())
                {
                    return JError::raiseWarning( 500, $row_host->getError() );
                }
            }

        }
    }


    $responsable = $_POST['usun_responsable'];

    for ($i = 0; $i < count($responsable); $i++)
    {

        $db_responsable =& JFactory::getDBO();
        $query_responsable = "DELETE FROM #__responsableServicio WHERE IdResponsable IN ( ".$responsable[$i]." ) and IdServicio IN ( ".$row->id." )";
        $db_responsable->setQuery( $query_responsable);
        $rowserver_responsable = $db_responsable->loadRow();
        //JError::raiseWarning( 500, $rowserver_dependencias[0]."HOLA" );
        //$db_ab =& JFactory::getDBO();
        //$query_ab = "DELETE FROM #__responsableServicio WHERE IdHW IN ( ".$rowserver_dependencias[0]." )";
        //JError::raiseWarning( 500, $rowserver_dependencias[0].$query_ab."HOLA" );
        //$db_ab->setQuery($query_ab);
        if (!$db_responsable->query())
        {
            echo "script alert('".$db_responsable->getErrorMsg()."');
			window.history.go(-1); </script>\n";
        }

    }

    $plik_responsable = $_POST['servicios_depende_responsable'];

    for ($i = 0; $i < count($plik_responsable); $i++)
    {
        $row_responsable = & JTable::getInstance('responsableservicio', 'table');

        if (!$row_responsable->bind(JRequest::get('post'))) {
            return JError::raiseWarning( 500, $row_responsable->getError() );
        }

        if($plik_responsable[$i] == '0');
        else
        {

            $row_responsable->IdResponsable = $plik_responsable[$i];

            $row_responsable->IdServicio = $row->id;

            if(repetido_responsable($row_responsable->IdResponsable,$row_responsable->IdServicio) == 1);
            else{

                if (!$row_responsable->store())
                {
                    return JError::raiseWarning( 500, $row_responsable->getError() );
                }
            }

        }
    }

    $documentos = $_POST['usun_documentos'];

    for ($i = 0; $i < count($documentos); $i++)
    {

        $db_documentos =& JFactory::getDBO();
        $query_documentos = "DELETE FROM #__documentosAsociados WHERE IdDoc IN ( ".$documentos[$i]." ) and IdServicio IN ( ".$row->id." )";
        $db_documentos->setQuery( $query_documentos);
        $rowserver_documentos = $db_documentos->loadRow();
        //JError::raiseWarning( 500, $rowserver_dependencias[0]."HOLA" );
        //$db_ab =& JFactory::getDBO();
        //$query_ab = "DELETE FROM #__documentosAsociados WHERE IdHW IN ( ".$rowserver_dependencias[0]." )";
        //JError::raiseWarning( 500, $rowserver_dependencias[0].$query_ab."HOLA" );
        //$db_ab->setQuery($query_ab);
        if (!$db_documentos->query())
        {
            echo "script alert('".$db_documentos->getErrorMsg()."');
			window.history.go(-1); </script>\n";
        }

    }

    $plik_documentos = $_POST['servicios_depende_documentos'];

    for ($i = 0; $i < count($plik_documentos); $i++)
    {
        $row_documentos = & JTable::getInstance('documentosAsociados', 'table');

        if (!$row_documentos->bind(JRequest::get('post'))) {
            return JError::raiseWarning( 500, $row_documentos->getError() );
        }

        if($plik_documentos[$i] == '0');
        else
        {

            $row_documentos->IdDoc = $plik_documentos[$i];

            $row_documentos->IdServicio = $row->id;

            if(repetido_documentos($row_documentos->IdDoc,$row_documentos->IdServicio) == 1);
            else{

                if (!$row_documentos->store())
                {
                    return JError::raiseWarning( 500, $row_documentos->getError() );
                }
            }

        }
    }




    $plik_depende = $_POST['servicios_depende'];
    for ($i = 0; $i < count($plik_depende); $i++)
    {

        $rowdepende = & JTable::getInstance('dependencias', 'table');

        if (!$rowdepende->bind(JRequest::get('post'))) {
            return JError::raiseWarning( 500, $rowdepende->getError() );
        }
        if($plik_depende[$i] == '0');
        else
        {
            $rowdepende->IdServPadre = $plik_depende[$i];
            $rowdepende->IdServHijo = $row->id;


            // ALGRORTIMO PARA RECORRER UN GRAFO


            $db =& JFactory::getDBO();
            $query = "SELECT * FROM #__dependencias";
            $db->setQuery( $query);
            $rowserver = $db->loadObjectList();

            $dbnumero =& JFactory::getDBO();
            $querynumero = "SELECT COUNT(*) FROM #__dependencias";
            $dbnumero->setQuery( $querynumero);
            $rowservernumero = $dbnumero->loadRow();

            //JError::raiseError(500, $rowservernumero['0'] );
            $se_guarda = 0;
            if($rowservernumero == 0)
            {
                    // HASTA AQUI

                if (!$rowdepende->store()) {
                    JError::raiseError(500, $rowdepende->getError() );
                }

            }
            else
            {
                if(repetido($rowdepende->IdServHijo,$rowdepende->IdServPadre) == 1)
                {
                    $se_guarda = 2;
                }
                if(ciclos($rowservernumero,$rowdepende->IdServHijo,$rowdepende->IdServPadre)!=0)
                {
                    $se_guarda = 1;
                }
                else if($se_guarda == 0)
                {
                    // HASTA AQUI

                    if (!$rowdepende->store()) {
                        JError::raiseError(500, $rowdepende->getError() );
                    }
                }

            }
        }
    }


    


    $row->descripcion_es = JRequest::getVar('descripcion_es', '', 'post', 'string', JREQUEST_ALLOWRAW);
    $row->intro_desc_es = JRequest::getVar('intro_desc_es', '', 'post', 'string', JREQUEST_ALLOWRAW);

    $row->descripcion_val = JRequest::getVar('descripcion_val', '', 'post', 'string', JREQUEST_ALLOWRAW);
    $row->intro_desc_val = JRequest::getVar('intro_desc_val', '', 'post', 'string', JREQUEST_ALLOWRAW);

	//removing images from folder and from database
    $images = $row->image_url;
    $usun = $_POST['usun'];
    $sciezka_do_usuniecia = JPATH_BASE."/../components/com_servicios/images/";

    for ($i = 0; $i < count($usun); $i++)
    {

        $images = str_replace($usun[$i].';', '', $images);
        //deleting the main image
        if (JFile::exists($sciezka_do_usuniecia.$usun[$i]))
        {
            JFile::delete($sciezka_do_usuniecia.$usun[$i]);
        }
        //deleting thumbnail of image
        if (JFile::exists($sciezka_do_usuniecia.$usun[$i].'.th.jpg'))
        {
            JFile::delete($sciezka_do_usuniecia.$usun[$i].'.th.jpg');
        }
        //deleting icon of image
        if (JFile::exists($sciezka_do_usuniecia.$usun[$i].'.ths.jpg'))
        {
            JFile::delete($sciezka_do_usuniecia.$usun[$i].'.ths.jpg');
        }
    }

    //removing file from folder and from database
    $files = $row->files_url;
    $usun = $_POST['usun_plik'];
    $sciezka_do_usuniecia = JPATH_BASE."/../components/com_servicios/files/";

    for ($i = 0; $i < count($usun); $i++)
    {

        $files = str_replace($usun[$i].';', '', $files);
        //deleting the file
        if (JFile::exists($sciezka_do_usuniecia.$usun[$i]))
        {
            JFile::delete($sciezka_do_usuniecia.$usun[$i]);
        }
    }

    //add images
    $pliki = $_FILES['image'];

    for ($i = 0; $i < count($pliki['name']); $i++)
    {
        if (substr($pliki['type'][$i], 0, 5) == "image")
        {
            //$nazwa = md5(microtime()).''.$pliki['name'][$i];
	    $nazwa = $pliki['name'][$i];
            $images .= $nazwa;
            $images .= ";";
            $sciezka = JPATH_BASE."/../components/com_servicios/images/".$nazwa;
            move_uploaded_file($pliki['tmp_name'][$i], $sciezka);
            $this->makeimg($sciezka);
            if ($i == 0)
            {
                $this->makeimg_s($sciezka);
            } //tylko dla pierwszego obrazka miniaturka

        }
    }
    $row->image_url = $images;


    //add files
    $plikii = $_FILES['files'];

    for ($i = 0; $i < count($plikii['name']); $i++)
    {
        if ($plikii['type'][$i] != "")
        {
            //$nazwaa = md5(microtime()).''.$plikii['name'][$i];
	    $nazwaa = $plikii['name'][$i];
            $files .= $nazwaa;
            $files .= ";";
            $sciezka = JPATH_BASE."/../components/com_servicios/files/".$nazwaa;
            move_uploaded_file($plikii['tmp_name'][$i], $sciezka);
        }
    }
    $row->files_url = $files;

    //setting producer
    if (JRequest::getVar('new_creador', 0, 'post'))
    {
        $c_nombre = JRequest::getVar('new_creador');
        $db = & JFactory::getDBO();
        $query = "INSERT INTO #__creador (id, nombre) VALUES (NULL, '".$c_nombre."')";
        $db->setQuery($query);
        if (!$db->query())
        {
            echo "script alert('".$db->getErrorMsg()."');
				window.history.go(-1); </script>\n";
        }
        $query = "SELECT id FROM #__creador WHERE name = '".$c_nombre."'";
        $db->setQuery($query);
        $c_id = $db->loadResult();
        $row->creador_id = $c_id;
    }
	
	/*if(!$row->ordering){
			$query = "SELECT ordering FROM #__servicios WHERE idCategoria = ".$row->idCategoria." ORDER BY ordering DESC LIMIT 1";
			$db =& JFactory::getDBO();		
			$db->setQuery($query);
			$order =$db->loadObject();
			$row->ordering = $order->ordering + 1;
	}*/
	
    if (!$row->store())
    {
        echo "<script> alert('".$row->getError()."');
			window.history.go(-1); </script>\n";
        exit ();
    }

    switch($this->_task)
    {
        case 'applyServicio':
            $link = 'index.php?option=com_servicios&task=editServicio&cid[]='.$row->id;
            if($se_guarda == 0){
                $msg = JText::_('CHANGES_SAVED');
            }
            if($se_guarda == 1)
            {
                $msg = JText::_('CHANGES_SAVED_CON_CICLO');
            }
            if($se_guarda == 2)
            {
                $msg = JText::_('CHANGES_SAVED_REPETIDO');
            }
            //$msg = JText::_('CHANGES_SAVED');
            break;
        case 'saveServicio':
        default:
            $link = 'index.php?option=com_servicios&task=servicios&idCategoria='.$row->idCategoria;
            if($se_guarda == 0){
                $msg = JText::_('ITEM_SAVED');
            }
            if($se_guarda == 1)
            {
                $msg = JText::_('ITEM_SAVED_CON_CICLO');
            }
            if($se_guarda == 2)
            {
                $msg = JText::_('ITEM_SAVED_REPETIDO');
            }
            //$msg = JText::_('ITEM_SAVED');
            break;
    }
    $mainframe->redirect($link, $msg);
}




















function publish()
{
    global $option;
    $task = JRequest::getVar('t', 'post');
    $cid = JRequest::getVar('cid', array (), '', 'array');

    if ($task == "servicios" or $task == "nocategoryitems")
    {
        if ($this->_task == 'publish')
        {
            $publish = 1;
        }
        else
        {
            $publish = 0;
        }
        $nlTable = & JTable::getInstance('servicios', 'table');
        $nlTable->publish($cid, $publish);
        $this->setRedirect('index.php?option=com_servicios&task='.$task.'');
    }
    else
    {
        if ($this->_task == 'publish')
        {
            $publish = 1;
        }
        else
        {
            $publish = 0;
        }
        $nlTable = & JTable::getInstance('categorias', 'table');
        $nlTable->publish($cid, $publish);
        $this->setRedirect('index.php?option=com_servicios');
    }


}

function cancel()
{
    global $mainframe;
    $mainframe->redirect('index.php?option=com_servicios');
}

function cancelHardware()
{
    global $mainframe;
    $mainframe->redirect('index.php?option=com_servicios&task=hardware');
}

function cancelSoftware()
{
    global $mainframe;
    $mainframe->redirect('index.php?option=com_servicios&task=software');
}

function cancelHost()
{
    global $mainframe;
    $mainframe->redirect('index.php?option=com_servicios&task=host');
}

function cancelResponsable()
{
    global $mainframe;
    $mainframe->redirect('index.php?option=com_servicios&task=responsable');
}

function cancelDocumentos()
{
    global $mainframe;
    $mainframe->redirect('index.php?option=com_servicios&task=documentos');
}

function cancel_documento_asociado()
{
    global $mainframe;
    $cid = JRequest::getVar('IdServicio');
    $mainframe->redirect('index.php?option=com_servicios&task=editServicio&cid[]='.$cid);
}

function cancelItem()
{
    global $mainframe;
    $mainframe->redirect('index.php?option=com_servicios&task=servicios');

}

function cancelCreador()
{
    global $mainframe;
    $mainframe->redirect('index.php?option=com_servicios&task=creadores');

}

function cancelAvisos()
{
    global $mainframe;
    $cid = JRequest::getVar('IdServicio');

    $mainframe->redirect('index.php?option=com_servicios&task=editServicio&cid[]='.$cid);
}

function remove()
{
    global $mainframe;
    $cid = JRequest::getVar('cid', array (), '', 'array');
    $db = & JFactory::getDBO();
    if (count($cid))
    {
        $cids = implode(',', $cid);
        $query = "DELETE FROM #__categorias WHERE ID IN ( ".$cids." )";
        $db->setQuery($query);
        if (!$db->query())
        {
            echo "script alert('".$db->getErrorMsg()."');
				window.history.go(-1); </script>\n";
        }
        $query = "DELETE FROM #__categorias WHERE parent_id IN ( ".$cids." )";
        $db->setQuery($query);
        if (!$db->query())
        {
            echo "script alert('".$db->getErrorMsg()."');
				window.history.go(-1); </script>\n";
        }


    }
    $mainframe->redirect('index.php?option=com_servicios', JText::_('ITEM_REMOVED'));
}



function remove_hardware()
{
    global $mainframe;
    $cid = JRequest::getVar('cid', array (), '', 'array');
    $task = "hardware";
    $db = & JFactory::getDBO();
    if (count($cid))
    {
        $cids = implode(',', $cid);
        $query = "DELETE FROM #__hardware WHERE ID IN ( ".$cids." )";
        $db->setQuery($query);
        if (!$db->query())
        {
            echo "script alert('".$db->getErrorMsg()."');
				window.history.go(-1); </script>\n";
        }
    }
    $mainframe->redirect('index.php?option=com_servicios&task='.$task.'', JText::_('ITEM_REMOVED'));
}


function remove_software()
{
    global $mainframe;
    $cid = JRequest::getVar('cid', array (), '', 'array');
    $task = "software";
    $db = & JFactory::getDBO();
    if (count($cid))
    {
        $cids = implode(',', $cid);
        $query = "DELETE FROM #__software WHERE ID IN ( ".$cids." )";
        $db->setQuery($query);
        if (!$db->query())
        {
            echo "script alert('".$db->getErrorMsg()."');
				window.history.go(-1); </script>\n";
        }
    }
    $mainframe->redirect('index.php?option=com_servicios&task='.$task.'', JText::_('ITEM_REMOVED'));
}


function remove_host()
{
    global $mainframe;
    $cid = JRequest::getVar('cid', array (), '', 'array');
    $task = "host";
    $db = & JFactory::getDBO();
    if (count($cid))
    {
        $cids = implode(',', $cid);
        $query = "DELETE FROM #__host WHERE ID IN ( ".$cids." )";
        $db->setQuery($query);
        if (!$db->query())
        {
            echo "script alert('".$db->getErrorMsg()."');
				window.history.go(-1); </script>\n";
        }
    }
    $mainframe->redirect('index.php?option=com_servicios&task='.$task.'', JText::_('ITEM_REMOVED'));
}


function remove_responsable()
{
    global $mainframe;
    $cid = JRequest::getVar('cid', array (), '', 'array');
    $task = "responsable";
    $db = & JFactory::getDBO();
    if (count($cid))
    {
        $cids = implode(',', $cid);
        $query = "DELETE FROM #__responsable WHERE ID IN ( ".$cids." )";
        $db->setQuery($query);
        if (!$db->query())
        {
            echo "script alert('".$db->getErrorMsg()."');
				window.history.go(-1); </script>\n";
        }
    }
    $mainframe->redirect('index.php?option=com_servicios&task='.$task.'', JText::_('ITEM_REMOVED'));
}

function remove_documentos()
{
    global $mainframe;
    $cid = JRequest::getVar('cid', array (), '', 'array');
    $task = "documentos";
    $db = & JFactory::getDBO();
    if (count($cid))
    {
        $cids = implode(',', $cid);
        $query = "DELETE FROM #__tiposDoc WHERE ID IN ( ".$cids." )";
        $db->setQuery($query);
        if (!$db->query())
        {
            echo "script alert('".$db->getErrorMsg()."');
				window.history.go(-1); </script>\n";
        }
    }
    $mainframe->redirect('index.php?option=com_servicios&task='.$task.'', JText::_('ITEM_REMOVED'));
}




function removeItem()

{
    $task = JRequest::getVar('t', 'post');
    global $mainframe;
    $cid = JRequest::getVar('cid', array (), '', 'array');
    $db = & JFactory::getDBO();
    if (count($cid))
    {
        $cids = implode(',', $cid);
        $query = "DELETE FROM #__servicios WHERE id IN ( ".$cids." )";
        $db->setQuery($query);
        if (!$db->query())
        {
            echo "script alert('".$db->getErrorMsg()."');
				window.history.go(-1); </script>\n";
        }
    }
    $mainframe->redirect('index.php?option=com_servicios&task='.$task.'', JText::_('ITEM_REMOVED'));
}

function removeCreadores()

{
    /*$task = JRequest::getVar('t', 'producers');
    global $mainframe;
    $cid = JRequest::getVar('cid', array (), '', 'array');
    $db = & JFactory::getDBO();
    if (count($cid))
    {
        $cids = implode(',', $cid);
        $query = "DELETE FROM #__djcat_producer WHERE id IN ( ".$cids." )";
        $db->setQuery($query);
        if (!$db->query())
        {
            echo "script alert('".$db->getErrorMsg()."');
				window.history.go(-1); </script>\n";
        }
    }
    $mainframe->redirect('index.php?option=com_servicios&task='.$task.'', JText::_('ITEM_REMOVED'));
	*/
		$task = JRequest::getVar( 't','creadores');
		global $mainframe; 

		$cid = JRequest::getVar( 'cid', array(), '', 'array');

		$db =& JFactory::getDBO();

		if(count($cid))

		{	
			$cids = implode(',', $cid);		
			$query = "SELECT id, name FROM #__servicios WHERE idCategoria IN ( ".$cids." )";
			$db->setQuery( $query );
			$servicios = $db->loadObjectList();
			$servicios_c=count($servicios);
			if($servicios_c>0){
				$msg= JText::_('ITEM_REMOVED').'<br /><span style="padding-left:30px;" >';
				foreach($servicios as $it){
					$msg.='<a href = "index.php?option=com_servicios&task=editItem&cid[]='.$it->id.'" >'.$it->nombre_es.'</a> , ';
				}
				$msg.="</span>";
			}else{
				$query = "DELETE FROM #__creador WHERE id IN ( ".$cids." )";
				$db->setQuery( $query );
				if(!$db->query())
				{
					echo "script alert('".$db->getErrorMsg()."');
					window.history.go(-1); </script>\n";
				}	
			$msg=JText::_('ITEM_REMOVED');
			}
		}

		$mainframe->redirect('index.php?option=com_servicios&task='.$task.'', $msg);
	
}


function applyConfig()
{
    global $mainframe;
    jimport('joomla.filesystem.file');

    $reg = new JRegistry('com_ccourses');

    $data = JFile::read(JPATH_COMPONENT_ADMINISTRATOR.DS.'config.ini');
    $reg->loadINI($data);
    $unit = $reg->getValue('price_unit');
    $unit_side = $reg->getValue('unit_side');
    $search_servicios = $reg->getValue('search_servicios');

    $file = JPATH_COMPONENT_ADMINISTRATOR.DS.'config.ini';
    $registry = new JRegistry('com_servicios');

    $sid = JRequest::getVar('price_unit', '', 'post', 'string');
    $cid = JRequest::getVar('unit_side', '', 'post', 'int');
    $iid = JRequest::getVar('search_servicios', '', 'post', 'int');
    $limit = JRequest::getVar('limit', '', 'post', 'int');

    $registry->setValue('limit', $limit);
    $registry->setValue('price_unit', $unit);
    $registry->setValue('unit_side', $unit_side);
    $registry->setValue('search_servicios', $search_servicios);

    $ini = $registry->toString('INI', 'com_servicios');
    JFile::write($file, $ini);
    $msg = JText::_('CONFIG_APPLIED');
    $mainframe->redirect('index.php?option=com_servicios', $msg);
}

	function orderup(){
		global $mainframe;

		$db		= & JFactory::getDBO();

		$cid = JRequest::getVar( 'cid', array(), '', 'array');
		$idCategoria = JRequest::getVar( 'idCategoria', '', '', 'int');
		$ord = JRequest::getVar('order');

		
		if (isset( $cid[0] ))
		{
			$row = & JTable::getInstance('servicios','table');
			$row->load( (int) $cid[0] );
			$row->move(-1, 'idCategoria = ' . (int) $row->idCategoria );
		}
		$mainframe->redirect('index.php?option=com_servicios&task=servicios&idCategoria='.$idCategoria.'&order='.$ord.'');
	}
	
	function orderdown(){
		global $mainframe;

		$db		= & JFactory::getDBO();

		$cid = JRequest::getVar( 'cid', array(), '', 'array');
		$idCategoria = JRequest::getVar( 'idCategoria', '', '', 'int');
		$ord = JRequest::getVar('order');
		
		if (isset( $cid[0] ))
		{
			$row = & JTable::getInstance('servicios','table');
			$row->load( (int) $cid[0] );
			$row->move(1, 'idCategoria = ' . (int) $row->idCategoria);
		}
		$mainframe->redirect('index.php?option=com_servicios&task=servicios&idCategoria='.$idCategoria.'&order='.$ord.'');
	}
	
	
	function saveOrder()
	{
		global $mainframe;
	
		$db			= & JFactory::getDBO();
		$cid = JRequest::getVar( 'cid', array(), '', 'array');
		$order = JRequest::getVar( 'order_p', array (), '', 'array' );
		$idCategoria = JRequest::getVar( 'idCategoria', '', '', 'int');
		$ord = JRequest::getVar('order');
		$total		= count($cid);
		$conditions	= array ();
		
		$row = & JTable::getInstance('servicios','table');

		for ($i = 0; $i < $total; $i ++)
		{
			$row->load( (int) $cid[$i] );
			if ($row->ordering != $order[$i]) {
				$row->ordering = $order[$i];
				if (!$row->store()) {
					JError::raiseError( 500, $db->getErrorMsg() );
					return false;
				}
				$condition = 'idCategoria = ' . (int) $row->idCategoria;
				$found = false;
				foreach ($conditions as $cond)
					if ($cond[1] == $condition) {
						$found = true;
						break;
					}
				if (!$found)
					$conditions[] = array ($row->id, $condition);
			}
		}

		foreach ($conditions as $cond)
		{
			$row->load($cond[0]);
			$row->reorder($cond[1]);
		}
		$mainframe->redirect('index.php?option=com_servicios&task=servicios&idCategoria='.$idCategoria.'&order='.$ord.'');
	}

}

function ciclos($rowservernumero,$id,$idPadre)
{
    // FUNCION CICLOS
    // 
    //JError::raiseError(500, $rowservernumero['0']."HOLA" );

    $db =& JFactory::getDBO();
    $query = "SELECT * FROM #__servicios ORDER BY id ASC";
    $db->setQuery( $query);
    $rowserver = $db->loadObjectList();

    foreach($rowserver as $row)
    {
        $visito[$row->id] = FALSE;
        $camino[$row->id] = FALSE;
        
    }
    $visito[$idPadre] = TRUE;
    $camino[$idPadre] = TRUE;

    $ciclos = FALSE;
    foreach($rowserver as $row)
    {
         if($visito[$row->id] == FALSE)
              $b = DFS_ciclos($visito,$camino,$id,$idPadre);  // COMPROBAR $b CADA VEZ
              $ciclos = $b + $ciclos;
    }
    return $ciclos;
}

// FUNCION DFS_ciclos()
function DFS_ciclos($visito,$camino,$id,$idPadre)
{
    $visito[$id] = TRUE;
    $camino[$id] = TRUE;
    $b = FALSE;

    // CONSULTA EN LA BD
    $db =& JFactory::getDBO();
    $query = "SELECT * FROM #__dependencias WHERE IdServPadre='$id'";
    $db->setQuery( $query);
    $rowserver = $db->loadObjectList();

    foreach($rowserver as $row)
    {
        if($visito[$row->IdServHijo] == TRUE )
        {
            if($camino[$row->IdServHijo] == TRUE )
            {
                $b_aux = TRUE;
            }
        }
        else
        {
            $b_aux = DFS_ciclos($visito,$camino,$row->IdServHijo,$idPadre);
        }   
        $b = $b_aux + $b;
    }
    $camino[$id] = FALSE;
    return $b;
}

function repetido($IdServHijo,$IdServPadre)
{

    $db =& JFactory::getDBO();
    $query = "SELECT * FROM #__dependencias WHERE IdServHijo='$IdServHijo' and IdServPadre='$IdServPadre'";
    $db->setQuery( $query);
    $rowserver = $db->loadObjectList();

    $repetido = 0;

    foreach($rowserver as $row)
    {
        $repetido = 1;
    }
    return $repetido;
}


function repetido_relacionados($Id_Serv_B,$Id_Serv_A)
{
    $db =& JFactory::getDBO();
    $query = "SELECT * FROM #__relacionados WHERE Id_Serv_A='$Id_Serv_A' and Id_Serv_B='$Id_Serv_B'";
    $db->setQuery( $query);
    $rowserver = $db->loadObjectList();

    $repetido = 0;

    foreach($rowserver as $row)
    {
        $repetido = 1;
    }
    return $repetido;
}


function disponible_hijos($id)
{

    $db =& JFactory::getDBO();
    $query = "SELECT * FROM #__dependencias WHERE IdServPadre='$id'";
    $db->setQuery( $query);
    $rowserver = $db->loadObjectList();
    //JError::raiseError(500, $id."HOLA" );

    foreach($rowserver as $row)
    {
        $id_hijo = $row->IdServHijo;
        //JError::raiseError(500, $id_hijo."HOLA" );
        $db_hijo =& JFactory::getDBO();
        $query_hijo = "UPDATE #__servicios SET disponibilidad='0' WHERE id='$id_hijo'";
        $db_hijo->setQuery( $query_hijo);
        $rowserver_hijo = $db_hijo->loadObjectList();
        disponible_hijos($id_hijo);
    }
}


function repetido_hardware($IdHw,$IdServicio)
{
    $db =& JFactory::getDBO();
    $query = "SELECT * FROM #__hardwareServicio WHERE IdHw='$IdHw' and IdServicio='$IdServicio'";
    $db->setQuery( $query);
    $rowserver = $db->loadObjectList();

    $repetido = 0;

    foreach($rowserver as $row)
    {
        $repetido = 1;
    }
    return $repetido;
}


function repetido_software($IdSw,$IdServicio)
{
    $db =& JFactory::getDBO();
    $query = "SELECT * FROM #__softwareServicio WHERE IdSw='$IdSw' and IdServicio='$IdServicio'";
    $db->setQuery( $query);
    $rowserver = $db->loadObjectList();

    $repetido = 0;

    foreach($rowserver as $row)
    {
        $repetido = 1;
    }
    return $repetido;
}


function repetido_host($Idhost,$IdServicio)
{
    $db =& JFactory::getDBO();
    $query = "SELECT * FROM #__hostServicio WHERE IdHost='$Idhost' and IdServicio='$IdServicio'";
    $db->setQuery( $query);
    $rowserver = $db->loadObjectList();

    $repetido = 0;

    foreach($rowserver as $row)
    {
        $repetido = 1;
    }
    return $repetido;
}





function repetido_responsable($IdResponsable,$IdServicio)
{
    $db =& JFactory::getDBO();
    $query = "SELECT * FROM #__responsableServicio WHERE IdResponsable='$IdResponsable' and IdServicio='$IdServicio'";
    $db->setQuery( $query);
    $rowserver = $db->loadObjectList();
    $repetido = 0;

    foreach($rowserver as $row)
    {
        $repetido = 1;
    }
    return $repetido;
}

function repetido_documentos($IdDoc,$IdServicio)
{
    $db =& JFactory::getDBO();
    $query = "SELECT * FROM #__documentosAsociados WHERE IdDoc='$IdDoc' and IdServicio='$IdServicio'";
    $db->setQuery( $query);
    $rowserver = $db->loadObjectList();

    $repetido = 0;

    foreach($rowserver as $row)
    {
        $repetido = 1;
    }
    return $repetido;
}