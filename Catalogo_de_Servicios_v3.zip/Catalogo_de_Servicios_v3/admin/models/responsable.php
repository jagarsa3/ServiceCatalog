<?php

defined ('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');




class serviciosModelresponsable extends JModel{

	var $_responsable;


	function _buildQueryWhere(){
		global $mainframe, $option;

		$filter_state = $mainframe->getUserStateFromRequest($option.'filter_state', 'filter_state');

		$where ='';

		if($filter_state =='P'){
			$where = 'published = 1';
		}
		elseif($filter_state == 'U'){
			$where = 'published = 0';
		}

		return ($where) ? ' WHERE '.$where : '';
	}


	function getResponsable(){

		if(!$this->_responsable){

			$query = "SELECT * FROM #__responsable".$this->_buildQueryWhere()."";

			$this->_responsable = $this->_getList($query, 0, 0);

		}

		return $this->_responsable;
	}
}
?>