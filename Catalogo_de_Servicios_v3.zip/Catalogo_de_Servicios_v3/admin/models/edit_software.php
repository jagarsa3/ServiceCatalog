<?php


defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');



class serviciosModeledit_software extends JModel

{

	function getSoft()

	{
		global $option;

		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row =& JTable::getInstance('software','Table');
		$cid = JRequest::getVar('cid', array(0), '', 'array' );
  		$id = $cid[0];
		$row->load( $id );
		return $row;
	}

	var $_software;
	var $wynik = array();



	function getsoftware(){

		if(!$this->_software){

			$query = "SELECT * FROM #__software ORDER BY Id";

			$this->_software = $this->_getList($query, 0, 0);

		}



		return $this->_software;
	}

}

?>
