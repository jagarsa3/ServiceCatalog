<?php

defined ('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');



class serviciosModelServicios extends JModel{
	
	var $_servicios;
	var $_categorias;
	
	
	function _buildQueryWhere(){
		global $mainframe, $option;
		
		$filter_state = $mainframe->getUserStateFromRequest($option.'filter_state', 'filter_state');
		
		$where ='';
		
		if($filter_state =='P'){
			$where = 's.published = 1';
		}
		elseif($filter_state == 'U'){
			$where = 's.published = 0';
		}
		
		return ($where) ? ' AND '.$where : '';
	}
	
	

	function getServicios(){
		$order = JRequest::getVar('order');
		$cid = JRequest::getVar('idCategoria');

		$c='';
		if($order=='categoria'){
			$ord = ' s.idCategoria';
		}
		elseif($order=='creador'){
			$ord = ' s.creador_id';
		}
		elseif($order=='id'){
			$ord = ' s.id';
		}
		elseif($order=='published'){
			$ord = ' s.published';
		}
		elseif($order=='descripcion_es'){
			$ord = ' s.descripcion_es';
		}
		elseif($order=='ordering'){
			$ord = ' s.nombre_es';
			JRequest::setVar('order','ordering');
		}
		
		if($cid){

			$c = ' AND s.idCategoria LIKE '.$cid.'';
			
		}
		
		$find_nombre_es=JRequest::getVar('find_name_es');
		$fn='';
		if($find_nombre_es){
			$fn=" AND s.nombre_es LIKE '%".$find_nombre_es."%' ";
		}

		$limit = JRequest::getVar('limit', 10, '', 'int');
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		if(!$this->_servicios){
			
		//$query = "SELECT s.*,c.id as idCategoria, s.nombre_es as cat_nombre_es, cr.id as cr_id, cr.nombre as cr_nombre  FROM #__servicios s, #__creador cr,#__categorias c WHERE c.id=s.creador_id AND cr.id = s.creador_id ".$c." ".$fn." ORDER BY ".$ord." ";
		//$query = "SELECT s.*,c.id as idCategoria FROM #__servicios s, #__categorias c, #__creador cr WHERE c.id=s.creador_id";
$query = "SELECT s.*,cr.nombre as cr_nombre, cat.nombre_es as cat_nombre_es FROM #__servicios s, #__categorias cat,#__creador cr WHERE cr.id=s.creador_id AND cat.id=s.idCategoria ".$c." ".$fn." ORDER BY ".$ord." ";

			$this->_servicios = $this->_getList($query, $limitstart, $limit);

		}
		return $this->_servicios;

	}
	
	function getCount(){
		$cid = JRequest::getVar('idCategoria');
		$wherecat='';
		if($cid){
			$wherecat = ' WHERE idCategoria LIKE '.$cid.'';
		}

		$find_name_es=JRequest::getVar('find_name_es');
		$fn='';
		if($find_name_es){
			$fn=" AND nombre_es LIKE '%".$find_name_es."%' ";
		}		
		
		$db= &JFactory::getDBO();
		$query = "SELECT COUNT(*) FROM #__servicios".$wherecat." ".$fn;

		$db->setQuery($query);
		$allelems=$db->loadResult();


		return $allelems;
	}
	
	function getCategorias(){
		if(!$this->_categorias){
			
			$query = "SELECT * FROM #__categorias ORDER BY nombre_es";

			$this->_categorias = $this->_getList($query,0,0);
		}
		return $this->_categorias;

	}
	
}
?>
