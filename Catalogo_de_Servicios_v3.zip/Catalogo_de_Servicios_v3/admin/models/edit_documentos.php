<?php


defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');



class serviciosModeledit_documentos extends JModel

{

	function getDocs()

	{
		global $option;

		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row =& JTable::getInstance('documentos','Table');
		$cid = JRequest::getVar('cid', array(0), '', 'array' );
  		$id = $cid[0];
		$row->load( $id );
		return $row;
	}

	var $_documento;
	var $wynik = array();



	function getDocumentos(){

		if(!$this->_documento){

			$query = "SELECT * FROM #__tiposDoc ORDER BY Id";

			$this->_documento = $this->_getList($query, 0, 0);

		}



		return $this->_documento;
	}

}

?>
