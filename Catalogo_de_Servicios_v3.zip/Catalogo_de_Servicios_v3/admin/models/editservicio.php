<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');



class serviciosModelEditservicio extends JModel

{	

	function getServicio()

	{

		global $option;

		

		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');

		$row =& JTable::getInstance('servicios','Table');

		$cid = JRequest::getVar('cid', array(0), '', 'array' );

		$id = $cid[0];

		$row->load($id); 		

		return $row;

	}
	

	
	
	
	
	var $_categorias;
	var $wynik = array();
	function checkChilds(&$tab){
		
		
		for($i=0; $i< count($tab); $i++){
			$wynik[] = $this->_categorias[$i];
			$query = "SELECT * FROM #__categorias WHERE parent_id LIKE ".$this->_categorias[$i]->id."";
			$wyni = $this->_getList($query,0,0);
			$wynik = array_merge($wynik,$wyni);
			
		}
		$this->checkChilds($wyni);
	}
	
	function getCategorias(){
		
		if(!$this->_categorias){
			
			$query = "SELECT * FROM #__categorias ORDER BY parent_id";

			$this->_categorias = $this->_getList($query, 0, 0);

		}
		
		

		return $this->_categorias;
	}
	
	
	//gettin list of producers
	var $_creadores;
	function getCreador(){
		if(!$this->_creadores){
			
			$query = "SELECT * FROM #__creador ORDER BY nombre";

			$this->_creadores = $this->_getList($query, 0, 0);

		}
		
		

		return $this->_creadores;
	}
	
	 
	

}