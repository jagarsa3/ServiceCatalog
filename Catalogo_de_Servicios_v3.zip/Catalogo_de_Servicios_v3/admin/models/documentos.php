<?php

defined ('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');




class serviciosModeldocumentos extends JModel{

	var $_documentos;


	function _buildQueryWhere(){
		global $mainframe, $option;

		$filter_state = $mainframe->getUserStateFromRequest($option.'filter_state', 'filter_state');

		$where ='';

		if($filter_state =='P'){
			$where = 'published = 1';
		}
		elseif($filter_state == 'U'){
			$where = 'published = 0';
		}

		return ($where) ? ' WHERE '.$where : '';
	}


	function getDocumentos(){

		if(!$this->_documento){

			$query = "SELECT * FROM #__tiposDoc".$this->_buildQueryWhere()."";

			$this->_documento = $this->_getList($query, 0, 0);

		}

		return $this->_documento;
	}
}
?>