<?php


defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');



class serviciosModeledit_hardware extends JModel

{

	function getHard()

	{
		global $option;

		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row =& JTable::getInstance('hardware','Table');
		$cid = JRequest::getVar('cid', array(0), '', 'array' );
  		$id = $cid[0];
		$row->load( $id );
		return $row;
	}

	var $_hardware;
	var $wynik = array();



	function getHardware(){

		if(!$this->_hardware){

			$query = "SELECT * FROM #__hardware ORDER BY Id";

			$this->_hardware = $this->_getList($query, 0, 0);

		}



		return $this->_hardware;
	}

}

?>
