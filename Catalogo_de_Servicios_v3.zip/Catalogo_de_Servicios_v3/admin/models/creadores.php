<?php
defined ('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');

/*Categories Model*/


class serviciosModelcreadores extends JModel{
	
	var $_creadores;
	
	
	
	function getCreadores(){
		$limit = JRequest::getVar('limit', 25, '', 'int');
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
				
		if(!$this->_creadores){
			
			$query = "SELECT * FROM #__creador";

			$this->_creadores = $this->_getList($query, $limitstart, $limit);

		}

		return $this->_creadores;
	}
	
		function getCountCreadores(){
		$db= &JFactory::getDBO();
		$query = "SELECT COUNT(*) FROM #__creador ";
		$db->setQuery($query);
		$r = $db->loadResult();
		return $r;
	}
}
?>