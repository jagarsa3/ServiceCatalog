<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');



class serviciosModeleditcreador extends JModel

{	

	function getCreadores()

	{

		global $option;

		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');

		$row =& JTable::getInstance('creador','Table');

		$cid = JRequest::getVar('cid', array(0), '', 'array' );

	 	$id = $cid[0];

		$row->load($id); 

		return $row;

	}


}
?>