<?php

defined ('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');




class serviciosModelhardware extends JModel{
	
	var $_hardware;
	

	function _buildQueryWhere(){
		global $mainframe, $option;
		
		$filter_state = $mainframe->getUserStateFromRequest($option.'filter_state', 'filter_state');
		
		$where ='';
		
		if($filter_state =='P'){
			$where = 'published = 1';
		}
		elseif($filter_state == 'U'){
			$where = 'published = 0';
		}
		
		return ($where) ? ' WHERE '.$where : '';
	}
	
	
	function getHardware(){
		
		if(!$this->_hardware){
			
			$query = "SELECT * FROM #__hardware".$this->_buildQueryWhere()."";

			$this->_hardware = $this->_getList($query, 0, 0);

		}

		return $this->_hardware;
	}
}
?>