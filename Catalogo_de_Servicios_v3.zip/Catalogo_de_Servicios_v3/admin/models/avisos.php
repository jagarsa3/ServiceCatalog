<?php


defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');



class serviciosModelavisos extends JModel

{

	function getAv()

	{
		global $option;

		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row =& JTable::getInstance('avisos','Table');
		$cid = JRequest::getVar('cid', array(0), '', 'array' );
  		$id = $cid[0];
		$row->load( $id );
		return $row;
	}

	var $_avisos;
	var $wynik = array();



	function getAvisos(){

		if(!$this->_avisos){

			$query = "SELECT * FROM #__avisos ORDER BY Id";

			$this->_avisos = $this->_getList($query, 0, 0);

		}



		return $this->_avisos;
	}

}

?>
