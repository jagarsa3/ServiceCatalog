<?php


defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');



class serviciosModeledit_host extends JModel

{

	function getHo()

	{
		global $option;

		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row =& JTable::getInstance('host','Table');
		$cid = JRequest::getVar('cid', array(0), '', 'array' );
  		$id = $cid[0];
		$row->load( $id );
		return $row;
	}

	var $_host;
	var $wynik = array();



	function getHost(){

		if(!$this->_host){

			$query = "SELECT * FROM #__host ORDER BY Id";

			$this->_host = $this->_getList($query, 0, 0);

		}



		return $this->_host;
	}

}

?>
