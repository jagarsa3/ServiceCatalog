<?php


defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');



class serviciosModeledit_responsable extends JModel

{

	function getResp()

	{
		global $option;

		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row =& JTable::getInstance('responsable','Table');
		$cid = JRequest::getVar('cid', array(0), '', 'array' );
  		$id = $cid[0];
		$row->load( $id );
		return $row;
	}

	var $_responsable;
	var $wynik = array();



	function getResponsable(){

		if(!$this->_responsable){

			$query = "SELECT * FROM #__responsable ORDER BY Id";

			$this->_responsable = $this->_getList($query, 0, 0);

		}



		return $this->_responsable;
	}

}

?>
