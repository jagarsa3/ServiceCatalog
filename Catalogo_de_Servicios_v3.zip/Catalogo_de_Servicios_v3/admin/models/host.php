<?php

defined ('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');




class serviciosModelhost extends JModel{

	var $_host;


	function _buildQueryWhere(){
		global $mainframe, $option;

		$filter_state = $mainframe->getUserStateFromRequest($option.'filter_state', 'filter_state');

		$where ='';

		if($filter_state =='P'){
			$where = 'published = 1';
		}
		elseif($filter_state == 'U'){
			$where = 'published = 0';
		}

		return ($where) ? ' WHERE '.$where : '';
	}


	function getHost(){

		if(!$this->_host){

			$query = "SELECT * FROM #__host".$this->_buildQueryWhere()."";

			$this->_host = $this->_getList($query, 0, 0);

		}

		return $this->_host;
	}
}
?>