<?php

defined ('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.model');

/*Items Model*/


class serviciosModelNocategoryitems extends JModel{
	
	var $_servicios;
	var $_categorias;
	
	//budowa klauzuli where do zapytania przy filtrowaniu
	function _buildQueryWhere(){
		global $mainframe, $option;
		
		$filter_state = $mainframe->getUserStateFromRequest($option.'filter_state', 'filter_state');
		
		$where ='';
		
		if($filter_state =='P'){
			$where = 'i.published = 1';
		}
		elseif($filter_state == 'U'){
			$where = 'i.published = 0';
		}
		
		return ($where) ? ' AND '.$where : '';
	}
	
	

	function getServicios(){
		$limit = JRequest::getVar('limit', 0, '', 'int');
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		if(!$this->_servicios){
			
			$query = "SELECT s.*  FROM #__servicios s WHERE (s.idCategoria NOT IN (SELECT c.id FROM #__categorias c)) OR (s.creador_id NOT IN (SELECT cr.id FROM #__creador cr))	";
			
			$this->_servicios = $this->_getList($query, $limitstart, $limit);

		}
		return $this->_servicios;
	}
	
	function getCount(){
		$db= &JFactory::getDBO();
		$query = "SELECT COUNT(*) FROM #__servicios WHERE (idCategoria NOT IN (SELECT c.id FROM #__categorias c)) OR (creador_id NOT IN (SELECT cr.id FROM #__creador cr))";

		$db->setQuery($query);
		$allelems=$db->loadResult();


		return $allelems;
	}
	
	
	
	
	
	
	//pobieranie kategorii do wylistowania - alfabetycznie
	function getCategorias(){
		
		if(!$this->_categorias){
			
			$query = "SELECT * FROM #__categorias ORDER BY nombre_es";
			
			$this->_categorias = $this->_getList($query,0,0);
		}
		
		return $this->_categorias;
	}
	
}
?>
