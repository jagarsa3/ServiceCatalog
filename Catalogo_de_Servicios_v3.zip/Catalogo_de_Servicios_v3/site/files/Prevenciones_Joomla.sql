-- phpMyAdmin SQL Dump
-- version 3.3.0
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 29-11-2010 a las 13:45:49
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.2-1ubuntu4.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `Joomla`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_prevenciones_CandelaRomana`
--

CREATE TABLE IF NOT EXISTS `jos_prevenciones_CandelaRomana` (
  `idCandela` int(11) NOT NULL AUTO_INCREMENT,
  `Calibre` int(11) NOT NULL,
  `DistEdificio` int(11) NOT NULL,
  `DistPublico` int(11) NOT NULL,
  `Altura` int(11) NOT NULL,
  PRIMARY KEY (`idCandela`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `jos_prevenciones_CandelaRomana`
--

INSERT INTO `jos_prevenciones_CandelaRomana` (`idCandela`, `Calibre`, `DistEdificio`, `DistPublico`, `Altura`) VALUES
(1, 50, 10, 25, 60),
(2, 60, 15, 48, 70),
(3, 70, 25, 56, 90);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_prevenciones_FuegoAereo`
--

CREATE TABLE IF NOT EXISTS `jos_prevenciones_FuegoAereo` (
  `idAereo` int(11) NOT NULL AUTO_INCREMENT,
  `Calibre` int(11) NOT NULL,
  `CoefPublico` float NOT NULL,
  `DistEdificio` int(11) NOT NULL,
  `DistPublico` int(11) NOT NULL,
  PRIMARY KEY (`idAereo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Volcar la base de datos para la tabla `jos_prevenciones_FuegoAereo`
--

INSERT INTO `jos_prevenciones_FuegoAereo` (`idAereo`, `Calibre`, `CoefPublico`, `DistEdificio`, `DistPublico`) VALUES
(1, 50, 0.5, 10, 25),
(2, 60, 0.6, 15, 36),
(3, 75, 0.6, 25, 45),
(4, 100, 0.6, 35, 60),
(5, 120, 0.6, 50, 72),
(6, 125, 0.6, 60, 75),
(7, 150, 0.8, 65, 120),
(8, 175, 0.8, 70, 140),
(9, 180, 0.8, 80, 145),
(10, 200, 1, 90, 200),
(11, 250, 1, 100, 250),
(12, 300, 1, 120, 300),
(13, 350, 1, 140, 350);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_prevenciones_FuegoTerrestre`
--

CREATE TABLE IF NOT EXISTS `jos_prevenciones_FuegoTerrestre` (
  `idTerrestre` int(11) NOT NULL AUTO_INCREMENT,
  `Calibre` int(11) NOT NULL,
  `DistEdificio` int(11) NOT NULL,
  `DistPublico` int(11) NOT NULL,
  PRIMARY KEY (`idTerrestre`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Volcar la base de datos para la tabla `jos_prevenciones_FuegoTerrestre`
--

INSERT INTO `jos_prevenciones_FuegoTerrestre` (`idTerrestre`, `Calibre`, `DistEdificio`, `DistPublico`) VALUES
(1, 20, 2, 10),
(2, 30, 3, 14),
(3, 40, 4, 14),
(4, 50, 10, 20),
(5, 60, 20, 30),
(6, 70, 30, 40);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_prevenciones_Voladores`
--

CREATE TABLE IF NOT EXISTS `jos_prevenciones_Voladores` (
  `idVolador` int(11) NOT NULL AUTO_INCREMENT,
  `Viento` tinyint(4) NOT NULL COMMENT '0->No viento, 1->Viento',
  `DistEdificio` int(11) NOT NULL,
  `DistPublico` int(11) NOT NULL,
  PRIMARY KEY (`idVolador`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `jos_prevenciones_Voladores`
--

INSERT INTO `jos_prevenciones_Voladores` (`idVolador`, `Viento`, `DistEdificio`, `DistPublico`) VALUES
(1, 1, 50, 100),
(2, 0, 25, 50);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_prevenciones_VolcanColor`
--

CREATE TABLE IF NOT EXISTS `jos_prevenciones_VolcanColor` (
  `idVolcan` int(11) NOT NULL AUTO_INCREMENT,
  `Calibre` int(11) NOT NULL,
  `DistEdificio` int(11) NOT NULL,
  `DistPublico` int(11) NOT NULL,
  PRIMARY KEY (`idVolcan`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `jos_prevenciones_VolcanColor`
--

INSERT INTO `jos_prevenciones_VolcanColor` (`idVolcan`, `Calibre`, `DistEdificio`, `DistPublico`) VALUES
(1, 50, 10, 25),
(2, 75, 25, 35),
(3, 100, 40, 50),
(4, 120, 50, 60),
(5, 150, 60, 75);
