<?php



/*
-------------------------------------------------------------------------------------------
FICHERO:		visit.php
-------------------------------------------------------------------------------------------
			editVisit( $option)			

FUNCION(ES):	Prepara los listados (parque,ciudad), genera instancia, llama al html 
		para editar la visita.
LLAMANTE(S):	switch ( $task)
PARAMETROS:	$option -> com_visit

			saveVisit( $option)

FUNCION(ES):	Guarda la visita editada en la base de datos
LLAMANTE(S):	La edición de visita en visit.html.php
PARAMETROS:	$option -> com_visit

			algunCampoVacio( $row)

FUNCION(ES):	Comprueba campos vacios, restricciones...
LLAMANTE(S):	El saveVisit para hacer todas las comprobaciones
PARAMETROS:	$row -> datos visita

            		restarFechas( $dFecIni, $dFecFin)

FUNCION(ES):	Resta dos fechas
LLAMANTE(S):	algunCamopVacio para comprobar los dias entre fechas
PARAMETROS:	$dFecIni->fecha_inicio  $dFecFin->fecha_fin

                        restarFechasperiodos($diaini,$mesini, $diafin, $mesfin)

FUNCION(ES):	Resta dos fechas
LLAMANTE(S):	algunCamopVacio para comprobar si una fecha esta entre el rango
PARAMETROS:	$diaini y $mesini->fecha_inicio  $diafin y $mesfin->fecha_fin
-------------------------------------------------------------------------------------------
CREACIÓN
-------------------------------------------------------------------------------------------
AUTOR:			Javier García San Juan
FECHA:			07/10/2010
-------------------------------------------------------------------------------------------
MODIFICACIONES
-------------------------------------------------------------------------------------------
AUTOR:		Javier García San Juan
FECHA:		11/10/2010
CAMBIOS:	Añadido contador de Solicitudes de visitas

-------------------------------------------------------------------------------------------
AUTOR:		Javier García San Juan
FECHA:		11/10/2010
CAMBIOS:	Añadido función restar fechas para >15 dias y <61dias

-------------------------------------------------------------------------------------------
AUTOR:		Javier García San Juan
FECHA:		11/10/2010
CAMBIOS:        Añadidas restricciones visita miercoles entre 01 Octubre y 31 Mayo

-------------------------------------------------------------------------------------------
AUTOR:		Javier García San Juan
FECHA:		18/10/2010
CAMBIOS:        Añadidas base datos parques y poblaciones
-------------------------------------------------------------------------------------------
AUTOR:
FECHA:
CAMBIOS:

-------------------------------------------------------------------------------------------

*/


// BASE DATOS JUPITER

// require_once("DB.php");
// define ("HOSTDB1","jupiter.bombers.dva.gva.es");
// define ("HOSTDB1","venus.bombers.dva.gva.es");

require_once("DB.php");
//define ("HOSTDB1","venus.bombers.dva.gva.es");



defined ( '_JEXEC' ) or die ( 'Restricted access' );
require_once( JApplicationHelper::getPath( 'html' ) );
JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.$option.DS.'tables');
switch($task)
{
	
	case 'save':
		saveVisit( $option);
		break;
	default:
		editVisit( $option);
		break;

}
function editVisit( $option )
{

        // CARGAMOS EL SERVIDOR DESDE JOOMLA

        $dbcolegios =& JFactory::getDBO();
        $querycolegios = "SELECT * FROM #__servidor WHERE activado='1' and descripcion='Guardar Datos Solicitud'";
        $dbcolegios->setQuery( $querycolegios);
        $rowservercolegios = $dbcolegios->loadRow();


        $dbmaestros =& JFactory::getDBO();
        $querymaestros = "SELECT * FROM #__servidor WHERE activado='1' and descripcion='Listar Parques de Bomberos'";
        $dbmaestros->setQuery( $querymaestros);
        $rowservermaestros = $dbmaestros->loadRow();


        $dbsecretaria =& JFactory::getDBO();
        $querysecretaria = "SELECT * FROM #__servidor WHERE activado='1' and descripcion='Listar Poblaciones'";
        $dbsecretaria->setQuery( $querysecretaria);
        $rowserversecretaria = $dbsecretaria->loadRow();

        //echo $rowserver['4']." ".$rowserver['1']."."."bombers.dva.gva.es";
        
        
        
        define ($rowservercolegios['4'],$rowservercolegios['1']."."."bombers.dva.gva.es");
	$connection=DB::connect("pgsql://".$rowservercolegios['2'].":".$rowservercolegios['3']."@".constant($rowservercolegios['4'])."/".$rowservercolegios['6']."");

	//establecemos la conexion con la BD de parques
        define ($rowservermaestros['4'],$rowservermaestros['1']."."."bombers.dva.gva.es");
	$conn_parques=DB::connect("pgsql://".$rowservermaestros['2'].":".$rowservermaestros['3']."@".constant($rowservermaestros['4'])."/".$rowservermaestros['6']."");
        //echo $rowservermaestros['1'].$rowservermaestros['4'].constant("HOSTDB1");
	//establecemos la conexion con la BD de secretaria
	//$conn_secretaria=DB::connect("pgsql://usuario_apps:adrian@".HOSTDB1."/secretaria");
        define ($rowserversecretaria['4'],$rowserversecretaria['1']."."."bombers.dva.gva.es");
        $conn_secretaria=DB::connect("pgsql://".$rowserversecretaria['2'].":".$rowserversecretaria['3']."@".constant($rowserversecretaria['4'])."/".$rowserversecretaria['6']."");
        //echo $rowservermaestros['1'].$rowservermaestros['4'].constant("HOSTDB1");
	//obtenemos todas las poblaciones
	$sql_poblacion = "select ayuntamiento from ayuntamientos order by ayuntamiento asc";
	$res_poblacion = $conn_secretaria->query($sql_poblacion);
	if (DB::isError($res_poblacion)){
		die($res_poblacion->getMessage());
	}
       

	//obtenemos todos los parques
	$sql_parques = "select poblacion from parques where codparque !='001' order by codparque asc";
	$res_parques = $conn_parques->query($sql_parques);
	if (DB::isError($res_parques)){
		die($res_parques->getMessage());
	}




	$row =& JTable::getInstance('visit', 'Table');
	$lists = array();


        $parque[0] = array('value' => JText::_( 'Seleccionaparque'),'text'=> JText::_( 'Seleccionaparque'));
        $i=1;

        while($parques=$res_parques->fetchRow(DB_FETCHMODE_ASSOC)){
                    $parque[$i] = array('value' => $parques['poblacion'],'text'=>$parques['poblacion']);
                    $i++;
        }


	$lists['parque'] = JHTML::_('select.genericList',
			$parque,'parque','class="inputbox" '.' ', 'value','text',
			$row->parque );

             $city[0] = array('value' => JText::_( 'Seleccionaciudad'),'text'=> JText::_( 'Seleccionaciudad'));
             $i=1;
             while($poblacion=$res_poblacion->fetchRow(DB_FETCHMODE_ASSOC)){
                     $city[$i] = array('value' => $poblacion['ayuntamiento'],'text'=>$poblacion['ayuntamiento']);
                     $i++;
            }
                
	
	
	$lists['city'] = JHTML::_('select.genericList',
			$city,'city','class="inputbox" '.' ', 'value','text',
			$row->city );	
                        
	HTML_visit::editVisit($row, $lists, $option);
}






function saveVisit( $option )
{
	global $mainframe;
	$row =& JTable::getInstance('visit', 'Table');
	



	if (!$row->bind(JRequest::get('post'))) {
        return JError::raiseWarning( 500, $row->getError() );
	}
        // EVITAR COMILLAS SIMPLES Y CARACTERES RAROS

        $row->parque =addslashes($row->parque);
        $row->city =addslashes($row->city);
        $row->nameCole =addslashes($row->nameCole);
        $row->dir =addslashes($row->dir);
        $row->nameProfe =addslashes($row->nameProfe);
        $row->telf =addslashes($row->telf);
        $row->movil =addslashes($row->movil);
        $row->email =addslashes($row->email);
        $row->numInf =addslashes($row->numInf);
        $row->numPrim =addslashes($row->numPrim);
        $row->numAcomp =addslashes($row->numAcomp);
        $row->observaciones=addslashes($row->observaciones);
        $row->fecha=addslashes($row->fecha);


	//Comprobacion de los datos
	$vacio = algunCampoVacio( $row);


	if($vacio==false){

                // CARGAMOS EL SERVIDOR DESDE JOOMLA                $db =& JFactory::getDBO();


                $dbcolegios =& JFactory::getDBO();
                $querycolegios = "SELECT * FROM #__servidor WHERE activado='1' and descripcion='Guardar Datos Solicitud'";
                $dbcolegios->setQuery( $querycolegios);
                $rowservercolegios = $dbcolegios->loadRow();

                //echo $rowserver['4']." ".$rowserver['1']."."."bombers.dva.gva.es";
                define ($rowservercolegios['4'],$rowservercolegios['1']."."."bombers.dva.gva.es");

                //establecemos la conexion con la BD
                $connection=DB::connect("pgsql://".$rowservercolegios['2'].":".$rowservercolegios['3']."@".constant($rowservercolegios['4'])."/".$rowservercolegios['6']."");


		$date = getdate();
		$fecha = $date['year']."-".$date['mon']."-".$date['mday'];
		$anyo=intval(substr($fecha,0,4));
	   	$mes=intval(substr($fecha,5,2));
	  	if($mes>=9){
                    $curso_academico=$anyo."/".intval($anyo+1);
                }else{
                    $curso_academico=intval($anyo-1)."/".$anyo;
                }
                //echo $curso_academico;
                $sql_maximo = "select max(num_visita) from solicitud_visita where curso_academico='".$curso_academico."'";
		$res_maximo = $connection->query($sql_maximo);
			if (DB::isError($res)){
			die($res->getMessage());
		}
		$max_num=$res_maximo->fetchRow(DB_FETCHMODE_ASSOC);
		if($max_num["max"]==null){
			$prefijo=substr($curso_academico,2,2).substr($curso_academico,7,2);
			$num_visita=$prefijo."001";
		}
                
		else{
			$num_visita=++$max_num["max"];
			if(strlen($num_visita)==6)
			$num_visita="0".$num_visita;
		}
                if($row->fecha == ''){
                    $fecha_visita = "9999-11-11";
                }
                else{
                    $fecha_visita = "2"."0".substr($row->fecha,0);
                }
                $fecha_actual = date(Y."-".m."-".d);
                
		$sql="insert into solicitud_visita(curso_academico,nombre_centro,direccion_centro,poblacion_centro,fecha_solicitud,nombre_responsable,telefono_responsable,movil_responsable,email_responsable,num_alumnos_infantil,num_alumnos_primaria,num_acompanyantes,parque_visita,fecha_visita,observaciones_fecha,num_visita)";
		$sql.=" values('".$curso_academico."','".mb_strtoupper($row->nameCole,"utf-8")."','".mb_strtoupper($row->dir,"utf-8")."','".mb_strtoupper($row->city,"utf-8")."','".$fecha_actual."','".mb_strtoupper($row->nameProfe,"utf-8")."','".$row->telf."','".$row->movil."','".$row->email."',".$row->numInf.",".$row->numPrim.",".$row->numAcomp.",'".mb_strtoupper($row->parque,"utf-8")."','".$fecha_visita."','".mb_strtoupper($row->observaciones,"utf-8")."','$num_visita')";
		$res = $connection->query($sql);
		if (DB::isError($res)) {
			die($res->getMessage());
                }

		if (!$row->store()) {
       			JError::raiseError(500, $row->getError() );
		}
		//$mainframe->redirect('index.php?option=' . $option,'Visita Añadida con exito.');
		HTML_visit::showVisit($row, $lists, $option, $num_visita);
	}
	
}


 

function algunCampoVacio( $row )
{
	//$direccion ='http://localhost/Joomla/index.php/solicitud-de-visitas';
	//$direccion ='http://localhost/PruebaJoomla/index.php/component/visit/index.php';
	
	?>

	<script type="text/javascript">

		var pagina = '?option=com_visit';


	</script>
	<?php

	//var pagina 'http://localhost/Joomla/index.php/solicitud-de-visitas';
	//var pagina = 'http://localhost/PruebaJoomla/index.php/en/solicitud-de-visitas';
	//dir=location.href;
	//$dire="http://localhost/PruebaJoomla/index.php/en/solicitud-de-visitas";
	//echo $dire;

	
	
	//nombre_centro
	if($row->nameCole==""){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("El nombre del centro no es correcto");
		location.href=pagina;
                
		</script>
		<?php
		die("");
	}
	//direccion_centro
	if($row->dir==""){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("La dirección del centro no es correcta");
		location.href=pagina;
		</script>
		<?php
		die("");
	}
	//poblacion_centro
	if($row->city==""){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("La población del centro no es correcta");
		location.href=pagina;
		</script>
		<?php
		die("");
	}
        	//poblacion_centro
	if($row->city==JText::_( 'Seleccionaciudad')){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("La población del centro no es correcta");
		location.href=pagina;
		</script>
		<?php
		die("");
	}
	//nombre_responsable
	if($row->nameProfe==""){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("El nombre completo del profesor no es correcto");
		location.href=pagina;
		</script>
		<?php
		die("");
	}
	//telefono_responsable
	if(($row->telf=="") || (!is_numeric($row->telf))){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("El telefono del responsable no es correcto");
		location.href=pagina;
		</script>
		<?php
		die("");
	}

	//movil_responsable
	if((!$row->movil=="") && (!is_numeric($row->movil))){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("El movil del responsable no es un numero");
		location.href=pagina;
		</script>
		<?php
		die("");
	}

        



	//comprobacion que los 2 num_alumnos no estan en blanco
	if (($row->numInf=="" || $row->numInf=="0") && ($row->numPrim=="" || $row->numPrim=="0")){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("El número de alumnos no es correcto");
		//location.href=pagina;
		</script>
		<?php
		die("");
	}

	//comprobacion solo debe haber un tipo de alumnos: primaria o infantil
	if (($row->numInf!="" && $row->numInf!="0") && ($row->numPrim!="" && $row->numPrim!="0")){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("En la visita no se pueden mezclar alumnos de infantil y de primaria");
		location.href=pagina;
		</script>
		<?php
		die("");
	}

	//comprobacion que alguno de los 2 num_alumnos no sea numerico
	if ((!is_numeric($row->numInf) || $row->numInf=="") && (!is_numeric($row->numPrim) || $row->numPrim!="")){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("El número de alumnos no es correcto");
		location.href=pagina;
		</script>
		<?php
		die("");
	}


	//comprobacion que el número de alumons no sea mayor de 60
	if ($row->numInf>60 || $row->numPrim>60){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("No debe haber más de 60 alumnos por visita");
		location.href=pagina;
		</script>
		<?php
		die("");
	}
	//Numero de Acompañantes
	if($row->numAcomp==""){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("El número de acompañantes no es correcto");
		location.href=pagina;
		</script>
		<?php
		die("");
	}


        $dia = substr($row->fecha,6 ,2 );
      	$mes =   substr($row->fecha,3 ,2 );
      	$ano = substr($row->fecha,0 ,2 );
	$ano = "2"."0".$ano;
        $fecha_correcta = $dia."-".$mes."-".$ano;
	//Hacer la comprobacion de checkdate en fecha_visita solo si hay algun campo de la fecha que no este en blanco
	if($row->fecha!=""){
		if(!checkdate($mes,$dia,$ano)){
			$alguncampoesvacio=true;
			?>
			<script>
			alert("La fecha no es correcta");
			location.href=pagina;
			</script>
			<?php
			die("");
		}
	}

	//comprobamos que observaciones_fecha no este en blanco ya que fecha_visita si lo esta
	if ($row->observaciones=="" && $row->fecha==""){
			$alguncampoesvacio=true;
			?>
			<script>
			alert("La fecha de visita y las observaciones están vacias");
			location.href=pagina;
			</script>
			<?
			die("");
	}

        if($row->fecha!=""){
            if(restarFechas(date(d."-".m."-".Y),$fecha_correcta)<0){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("La fecha de solicitud no debe ser anterior a la actual");
		location.href=pagina;
		</script>
		<?php
		die("");
            }
         }


	// Restar Fechas

        if($row->fecha!=""){
            if(restarFechas(date(d."-".m."-".Y),$fecha_correcta)<7){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("La solicitud debe hacerse con 7 dias de antelación");
		location.href=pagina;
		</script>
		<?php
		die("");
            }
		
	}


        // Entre el 1 de Octubre y el 31 de Mayo
        // 1 de Octubre
        $diao = "01";
      	$meso =   "10";
		$anoo= "2"."0".$ano;
        $fecha_correctao = $diao."-".$meso."-".$anoo;
        // 31 de Mayo
        $diam = "31";
      	$mesm =   "05";
		$anom= "2"."0".$ano;
        $fecha_correctam = $diam."-".$mesm."-".$anom;
        if($row->fecha!=""){
            if((restarFechasperiodos($dia,$mes,$diam,$mesm)<0) && (restarFechasperiodos($diao,$meso,$dia,$mes)<0) ) {
		$alguncampoesvacio=true;
		?>
		<script>
		alert("El periodo de fechas debe estar entre el  01 de Octubre y el 31 de Mayo");
		location.href=pagina;
		</script>
		<?php
		die("");
            }

	}

        // Dia Miercoles
        if($row->fecha!=""){
            if(date(l,mktime(0, 0, 0, $mes, $dia, $ano))!=Wednesday){
                $alguncampoesvacio=true;
		?>
		<script>
		alert("El dia de la semana debe ser miercoles, para otros dias: apartado observaciones");
		location.href=pagina;
		</script>
		<?php
		die("");
            }

	}

	
	


	//Parque Bomberos
	if($row->parque==""){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("El parque de bomberos no es correcto");
		location.href=pagina;
		</script>
		<?php
		die("");
	}
        	//Parque Bomberos
	if($row->parque==JText::_( 'Seleccionaparque')){
		$alguncampoesvacio=true;
		?>
		<script>
		alert("El parque de bomberos no es correcto");
		location.href=pagina;
		</script>
		<?php
		die("");
	}
	

	return false;


}

function restarFechas($dFecIni, $dFecFin)
{
	$dFecIni = str_replace("-","",$dFecIni);
	$dFecIni = str_replace("/","",$dFecIni);
	$dFecFin = str_replace("-","",$dFecFin);
	$dFecFin = str_replace("/","",$dFecFin);

	ereg( "([0-9]{1,2})([0-9]{1,2})([0-9]{2,4})", $dFecIni, $aFecIni);
	ereg( "([0-9]{1,2})([0-9]{1,2})([0-9]{2,4})", $dFecFin, $aFecFin);

	$date1 = mktime(0,0,0,$aFecIni[2], $aFecIni[1], $aFecIni[3]);
	$date2 = mktime(0,0,0,$aFecFin[2], $aFecFin[1], $aFecFin[3]);

	return round(($date2 - $date1) / (60 * 60 * 24));
}

function restarFechasperiodos($diaini,$mesini, $diafin, $mesfin)
{
	$dia = $diafin - $diaini;
        $mes = $mesfin - $mesini;
        $mes = $mes * 31;
        $dia = $dia + $mes;
	return $dia;
}

?>

