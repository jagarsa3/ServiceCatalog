<?php


class Options{
var $id;

function __construct(){
$id=null;
}
	
}


class TreeHelper{
var $parent_id;
var $id;
var $nombre_es;
var $nombre_val;
var $childs = Array();
var $level;

function __construct(){
$parent_id=null;
$id=null;
$nombre_es=null;
$nombre_val=null;
$childs[]=null;
$elem[]=null;
$level=0;
}


public function getList(& $lists,& $lists_const,& $option=Array(),& $sprawdzone=Array()){

	$liczba = count($lists_const);
		
			$op= new Options;
			$op->id=$lists->id;
			$option[]=$op;
			
			
				   for($i=0; $i<$liczba;$i++ ){
					if($lists_const[$i]->parent_id==$lists->id){		
						$child=new TreeHelper();
						$child->id=$lists_const[$i]->id;
						$child->parent_id=$lists_const[$i]->parent_id;
						$child->level=$list->level+1;
						$new_nombre_es=$lists_const[$i]->nombre_es;
						$new_nombre_val=$lists_const[$i]->nombre_val;
							for($lev=0;$lev<$child->level;$lev++){
								$new_nombre_es=$lists_const[$i]->nombre_es;
								$new_nombre_val=$lists_const[$i]->nombre_val;
							}
						$child->nombre_es=$new_nombre_es;
						$child->nombre_val=$new_nombre_val;

						
						$this->childs[]=$child;
						$this->getSortList($this->childs,$lists_const,$option,$sprawdzone);			
					}
				}	
				$result = Array();
				foreach($option as $opt)
				{
					$result[]=$opt->id;
				}
			
	
	return($result);		
}







public function getSortList(& $lists,& $lists_const,& $option=Array(),& $sprawdzone=Array()){

	$liczba = count($lists_const);
	foreach($lists as $list){

				$flaga=0;
				for($l=0;$l<count($sprawdzone);$l++){
					if($sprawdzone[$l]==$list->id){
						$flaga=1;
					}
				}
			
			if($flaga==0){
			$sprawdzone[]=$list->id;
			
			$this->parent_id = $list->parent_id;
			$this->id = $list->id;
			$this->nombre_es = $list->nombre_es;
			$this->nombre_val = $list->nombre_val;
			$op= new Options;
			$op->id=$this->id;
			$option[]=$op;
			
			
				   for($i=0; $i<$liczba;$i++ ){
					if($lists_const[$i]->parent_id==$list->id){		
						$child=new TreeHelper();
						$child->id=$lists_const[$i]->id;
						$child->parent_id=$lists_const[$i]->parent_id;
						$child->level=$list->level+1;
						$new_nombre_es=$lists_const[$i]->nombre_es;
						$new_nombre_val=$lists_const[$i]->nombre_val;
							for($lev=0;$lev<$child->level;$lev++){
								$new_nombre_es="&nbsp;&nbsp;&nbsp;".$new_nombre_es;
								$new_nombre_val="&nbsp;&nbsp;&nbsp;".$new_nombre_val;
							}
						$child->nombre_es=$new_nombre_es;
						$child->nombre_val=$new_nombre_val;

						
						$this->childs[]=$child;
						$this->getSortList($this->childs,$lists_const,$option,$sprawdzone);
					
					}
				}	
				
			}
	}
	return($option);		
}




}

?>

