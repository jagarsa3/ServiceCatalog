<?php 

defined('_JEXEC') or die('Restricted access');
//require_once(JApplicationHelper::getPath( 'admin_html' ));
require_once(JPATH_COMPONENT.DS.'controller.php');

	$controller = new serviciosController();
	$controller->execute( JRequest::getVar('view'));
	$controller->redirect();

?>

