<?php

function serviciosBuildRoute(&$query){

	$segments = array();
	if(isset($query['view'])){
			if($query['view']=='showServicio'){
				$segments[]='details';
				unset($query['view']);
				if(isset($query['id'])){
					$segments[] = $query['id'];
					unset($query['id']);
				}
				if(isset($query['cid'])){
					$segments[] = $query['cid'];
					unset($query['cid']);
				}
				if(isset($query['pid'])){
					$segments[] = $query['pid'];
					unset($query['pid']);
				}
			}
			elseif($query['view']=='show'){
				$segments[]='categorias';
				unset($query['view']);
				if(isset($query['layout'])){
					$segments[] = $query['layout'];
					unset($query['layout']);
				}
				else {
					$sements[]='default';
				}
				if(isset($query['cid'])){
					$segments[] = $query['cid'];
					unset($query['cid']);
				}
				else {
					$segments[] = '0';
				}
				if(isset($query['pid'])){
					$segments[] = $query['pid'];
					unset($query['pid']);
				}
				else {
					$segments[] = '0';
				}
				if(isset($query['order'])){
					$segments[] = $query['order'];
					unset($query['order']);
				}
			}			
	}

	return $segments;
}

function serviciosParseRoute(&$segments){
$query=array();

		if($segments[0]){
			if($segments[0]=='details'){
				$query['view']='showServicio';
				if(isset($segments[1])){
					$query['id']=$segments[1];
				}
				if(isset($segments[2])){
					$query['cid']=$segments[2];
				}
				if(isset($segments[3])){
					$query['pid']=$segments[3];
				}
			}
			elseif($segments[0]=='categorias'){
				$query['view']='show';
				if(isset($segments[1])){
					$query['layout']=$segments[1];
				}
				if(isset($segments[2])){
					$query['cid']=$segments[2];
				}
				if(isset($segments[3])){
					$query['pid']=$segments[3];
				}
				if(isset($segments[4])){
					$query['order']=$segments[4];
				}
			}
		}
	return $query;
}

?>