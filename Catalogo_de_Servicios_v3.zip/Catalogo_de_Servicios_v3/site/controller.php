<?php

defined ('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');
jimport('joomla.filesystem.file');
JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
$lang =& JFactory::GetLanguage();
$lang->load('com_servicios');

class serviciosController extends JController
{
	
	function display()
	{	
		parent::display();
	}
}