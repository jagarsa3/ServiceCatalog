<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');

class serviciosModelshowServicio extends JModel {	
	var $_servicio;
	var $_catpath=Array();

	function getServicio($_id){
		
		if(!$this->_servicio){
			$db= &JFactory::getDBO();
			$query = "
					SELECT s.*, c.nombre_val AS cat_nombre_val
					FROM #__servicios AS s
					LEFT JOIN  #__categorias AS c
					ON c.id = s.idCategoria
					WHERE s.id LIKE ".$_id;

			$db->setQuery($query);
			$this->_servicio = $db->loadObject();
		}
			return $this->_servicio;
	}
	
	function getPath($catid){
		if(!$this->_catpath){
			$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__categorias";
			$db->setQuery($query);
			$categorias = $db->loadObjectList();
			$this->buildPath($categorias, $catid,$this->_catpath);
		}
		return $this->_catpath;
	}
	
	function buildPath(&$categorias, $catid, &$pathTable) {

$idioma= JRequest::getVar('lang');
		foreach ($categorias as $row) {

			if ($row->id == $catid) {
				if ($row->parent_id == 0) {

					if($idioma=="val")
					{
						  $pathTable[]= Array('id' => $row->id, 'nombre_val'=> $row->nombre_val);
					}
					else
					{
						  $pathTable[]= Array('id' => $row->id, 'nombre_es'=> $row->nombre_es);
					}
					return true;
				}
				else {
					if($idioma=="val")
					{
						  $pathTable[]= Array('id' => $row->id, 'nombre_val'=> $row->nombre_val);
					}
					else
					{
						 $pathTable[]= Array('id' => $row->id, 'nombre_val'=> $row->nombre_es);
					}

					$this->buildPath($categorias, $row->parent_id, $pathTable);
				}
			}
		}
		return false;
	}
}