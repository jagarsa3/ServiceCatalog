<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.model');

JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');



class serviciosModelShow extends JModel
{	

	function getCat()

	{

		global $option;

		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row =& JTable::getInstance('categorias','Table');
		$cid = JRequest::getVar('cid', array(0), '', 'array' );
  		$id = $cid[0];
		$row->load( $id ); 
		return $row;

	}
	
	var $_categorias;
	var $_categoria;
	var $_elems;
	var $wynik = array();
	var $_catpath = array();
	

	function checkChilds(&$tab){
		
		for($i=0; $i< count($tab); $i++){
			$wynik[] = $this->_categorias[$i];
			$query = "SELECT * FROM #__categorias WHERE parent_id LIKE ".$this->_categorias[$i]->id."";
			$wyni = $this->_getList($query,0,0);
			$wynik = array_merge($wynik,$wyni);
			
		}
		$this->checkChilds($wyni);
	}
	
	function getCategorias(){
		
		if(!$this->_categorias){
			
			$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__categorias";
			$db->setQuery($query);
			$this->_categorias=$db->loadObjectList();
		
		
		}
		return $this->_categorias;
	}
	
	
	function getElements($id){
		global $mainframe;
		$par =& $mainframe->getParams('com_servicios');
		$list = implode(",", $id);
			$limit		= $par->get('limit_servicios_show');
			$limitstart	= JRequest::getVar('limitstart', 0, '', 'int');
			$creador_id = JRequest::getVar('pid', 0, '', 'int');
			$search = '';
			if(JRequest::getVar('search','0','string')!='0'){
				$search = " AND nombre_es LIKE '%".JRequest::getVar('search','0','string')."%' ";
			}
			
			$creador = '';
			if($creador_id){
				$creador = ' AND creador_id LIKE '.$creador_id. '';
			}
			$order = JRequest::getVar('order');
			$db= &JFactory::getDBO();
			switch ($order) {
				case 'anombre_es':
							$orderQuery=' ORDER BY nombre_es ASC, price';
							break;
				case 'dnombre_es':
							$orderQuery=' ORDER BY nombre_es DESC, price';
							break;
				default: 
							$orderQuery = ' ORDER BY ordering';
							break;
			}
			$query = "SELECT * FROM #__servicios WHERE idCategoria IN (".$list.")".$creador.$search.$orderQuery;
			$db->setQuery($query);
			$Arows = $this->_getList($query, $limitstart, $limit);	

			return $Arows;
	}
		function getCountElements($id){
		$list = implode(",", $id);
			$creador_id = JRequest::getVar('pid', 0, '', 'int');
			$search = '';
			if(JRequest::getVar('search','0','string')!='0'){
				$search = " AND nombre_es LIKE '%".JRequest::getVar('search','0','string')."%' ";
			}
			
			$creador = '';
			if($creador_id){
				$creador = ' AND creador_id LIKE '.$creador_id. '';
			}
			$db= &JFactory::getDBO();
			$query = "SELECT COUNT(*) FROM #__servicios WHERE idCategoria IN (".$list.")".$creador.$search;

			$db->setQuery($query);
			$allelems=$db->loadResult();
			

			return $allelems;
	}
	function getCategoria($_id){
		
		if(!$this->_categoria){
			$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__categorias WHERE id LIKE ".$_id;

			$db->setQuery($query);
			$this->_categoria=$db->loadObject();

		}
		
			return $this->_categoria;
	}	
	
	function getAllCountElements(){
			$creador_id = JRequest::getVar('pid', 0, '', 'int');
			$search = '';
			if(JRequest::getVar('search','0','string')!='0'){
				$search = " AND nombre_es LIKE '%".JRequest::getVar('search','0','string')."%' ";
			}
			
			$creador = '';
			if($creador_id){
				$creador = ' AND creador_id LIKE '.$creador_id. '';
			}
			$db= &JFactory::getDBO();
			$query = "SELECT COUNT(*) FROM #__servicios WHERE 1 ".$creador.$search;

			$db->setQuery($query);
			$allelems=$db->loadResult();
			

			return $allelems;
	}
	
	function getAllElements(){
			
			global $mainframe;
		$par =& $mainframe->getParams('com_servicios');
		
			$limit		= $par->get('limit_servicios_show');
			
			$limitstart	= JRequest::getVar('limitstart', 0, '', 'int');
			$creador_id = JRequest::getVar('pid', 0, '', 'int');
			$search = '';
			if(JRequest::getVar('search','0','string')!='0'){
				$search = " AND nombre_es LIKE '%".JRequest::getVar('search','0','string')."%' ";
			}
			
			$creador = '';
			if($creador_id){
				$creador = ' AND creador_id LIKE '.$creador_id. '';
			}
			$order = JRequest::getVar('order');
			$db= &JFactory::getDBO();
			switch ($order) {
				case 'anombre_es':
							$orderQuery=' ORDER BY nombre_es ASC, price';
							break;
				case 'dnombre_es':
							$orderQuery=' ORDER BY nombre_es DESC, price';
							break;
				case 'aprice':
							$orderQuery=' ORDER BY CAST(price as UNSIGNED) ASC, nombre_es';
							break;
				case 'dprice':
							$orderQuery=' ORDER BY CAST(price as UNSIGNED) DESC, nombre_es';
							break;
				default: 
							$orderQuery = ' ORDER BY ordering';
							break;
			}
			$query = "SELECT * FROM #__servicios WHERE 1 ".$creador.$search.$orderQuery;
			$db->setQuery($query);
			$Arows = $this->_getList($query, $limitstart, $limit);	

			return $Arows;
	}
	
	function getPath($catid){
		if(!$this->_catpath){
			$db= &JFactory::getDBO();
			$query = "SELECT * FROM #__categorias";
			$db->setQuery($query);
			$categorias = $db->loadObjectList();
			$this->buildPath($categorias, $catid,$this->_catpath);
		}
		return $this->_catpath;
	}
	
	function buildPath(&$categorias, $catid, &$pathTable) {
	$idioma= JRequest::getVar('lang');

		foreach ($categorias as $row) {
			if ($row->id == $catid) {
				if ($row->parent_id == 0) {
				if($idioma=="val")
				{
					$pathTable[]= Array('id' => $row->id, 'nombre_val'=> $row->nombre_val);
					return true;
				}
				else
				{
					$pathTable[]= Array('id' => $row->id, 'nombre_es'=> $row->nombre_es);
					return true;
				}
				}
				else {
				if($idioma=="val")
				{
					$pathTable[]= Array('id' => $row->id, 'nombre_val'=> $row->nombre_val);
					$this->buildPath($categorias, $row->parent_id, $pathTable);
				}
				else
				{
					$pathTable[]= Array('id' => $row->id, 'nombre_es'=> $row->nombre_es);
					$this->buildPath($categorias, $row->parent_id, $pathTable);
				}
				}
			}
		}
		return false;
	}
	
}

