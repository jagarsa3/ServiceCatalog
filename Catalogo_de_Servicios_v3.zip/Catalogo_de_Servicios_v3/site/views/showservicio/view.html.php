  <?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');
$document=& JFactory::getDocument();
$cs = JURI::base().'components/com_servicios/views/showServicio/tmpl/style.css';
$document->addStyleSheet($cs);
class serviciosViewshowServicio extends JView

{
	var $row;
	var $pagination;
	function display($tpl = null)
    
    {
    global $idioma;
    $idioma= JRequest::getVar('lang');	
    global $mainframe;
    $par = & $mainframe->getParams('com_servicios');
    JHTML::_('behavior.modal');
    $model = & $this->getModel();
    $servicio_id = JRequest::getVar('id', 0, '', 'int');
    $this->row = $model->getServicio($servicio_id);
    $document = & JFactory::getDocument();
    $cs = JURI::base().'components/com_servicio/views/showServicio/tmpl/style.css';
    $document->addStyleSheet($cs);
	
	$params = $mainframe->getParams();

	$menus	= &JSite::getMenu();
	$menu	= $menus->getActive();

	if (is_object( $menu )) {
		$menu_params = new JParameter( $menu->params );
		if (!$menu_params->get( 'page_title')) 
		{	 
			if($idioma=="val")
			{
                            $params->set('page_title',	$this->row->idCategoria);


			}
			else {
			$params->set('page_title',	$this->row->idCategoria);
			}
		}
	} 

else {
		    if($idioma=="val")
		    {
                        $params->set('page_title',	$this->row->nombre_val);

		    }

		   else
		    {
                       $params->set('page_title',	$this->row->nombre_es);
		    }


	}
	
	  if($idioma=="val")
	    {
              	$document->setTitle( $params->set( 'page_title' ).' - '.$this->row->nombre_val );

	    }
	  else 
	      {
		$document->setTitle( $params->set( 'page_title' ).' - '.$this->row->nombre_es );
	      }


	$pu=$par->get('price_unit');
	$us=$par->get('unit_side');
	$price = number_format($this->row->price, 2, ',', ' ');
	if($us){
		$this->row->price = $price.'&nbsp;'.$pu; 
	}else{
		$this->row->price = $pu.'&nbsp;'.$price; 
	}
	$showprice = $par->get('show_price');
	$showfooter = $par->get('show_footer');
	$footer = '<div style="margin: 0 auto; clear: both; text-align: center; width: 100%"><br /><a target="_blank" href="http://design-joomla.eu">joomla templates &amp; addons</a></div>';

	

	$images = array();
	if($this->row->image_url) {
		$temp = explode(";",$this->row->image_url);
		for($i=0; $i<count($temp)-1;$i++ )
                $images[] = '<a class="modal servicios_thumbnail" href="'.JURI::base().'components/com_servicios/images/'.$temp[$i].'" target="_blank"><img src="'.JURI::base().'components/com_servicios/images/'.$temp[$i].'.th.jpg" style="top: 0;" alt="'.$this->row->nombre_es.'" /></a>';	
	}
	

	
	$files = array();
	if($this->row->files_url){
		$temp = explode(";",$this->row->files_url);
		for($i=0; $i<count($temp)-1;$i++ ){
			$file=explode(".", substr($temp[$i], 0));
            $fileHTML = '<a href="'.JURI::base().'components/com_servicios/files/'.$temp[$i].'" class="servicios_file" title="'.$temp[0].'">';
			switch($file[1]){
 				case 'pdf':{
 					$obrazek='pdf.png';
 					break;
 				}
				case 'zip':
				case 'rar':
				{
					$obrazek='rar.png';
					break;
				}
				case 'mp3':
				case 'ogg':
				case 'wav':
				{
					$obrazek='mp3.png';
					break;
				}
				case 'doc':
				case 'odt':
				case 'docx':
				{
					$obrazek='word.png';
					break;
				}
				case 'xls':
				case 'xlsx':
				{
					$obrazek='excel.png';
					break;
				}
				case 'mov':
				case 'avi':
				case 'mpeg':
				case 'mpg':
				case 'wmv':
				{
					$obrazek='movie.png';
					break;
				}
				case 'jpg':
				case 'jpeg':
				case 'tiff':
				case 'jpg':
				case 'png':
				{
					$obrazek='imagen.png';
					break;
				}
				default:{
					$obrazek='other.png';
					break;
				}
			}
			$fileHTML .= '<img src="'.JURI::base().'/components/com_servicios/icons/'.$obrazek.'" alt="'.$file[0].'" class="ikonka" />'.$file[0].'</a>';
			$files[] = $fileHTML;
			}	
		}
	
	$this->assignRef('files',$files);
	$this->assignRef('images',$images);
	$this->assignRef('showprice',$showprice);
	$page = (int)JRequest::getInt('limitstart', 0);
	$this->ContentPagebreak($this->row, $this->pagination, $page);
	
	$this->assignRef('servicio',$this->row);
	$this->assignRef('pagination',$this->pagination);
	
	$this->assignRef('showfooter',$showfooter);
	$this->assignRef('footer',$footer);
	$this->assignRef('params',	$params);
	$this->assignRef('idioma',	$idioma);
	
	 
    $app = & JFactory::getApplication();
    $pathway = & $app->getPathway();
	$catpath = $model->getPath($this->row->idCategoria);
	
	$layout = JRequest::getVar('layout', 'default', 'default', 'string');
	
	for ($i = count($catpath) - 1; $i >= 0;  $i--) {
	    
	    if($idioma=="val")
	    {
                $pathway->addItem($catpath[$i][nombre_val], JRoute::_('index.php?option=com_servicios&view=show&layout='.$layout.'&cid='.$catpath[$i][id]));
		
	    }
	    else
	    {
		$pathway->addItem($catpath[$i][nombre_es], JRoute::_('index.php?option=com_servicios&view=show&layout='.$layout.'&cid='.$catpath[$i][id]));
	    }
	}
	
	if($idioma=="val")
	{
            $pathway->addItem($this->row->nombre_val);
	  
	}
	else
	{
            $pathway->addItem($this->row->nombre_es);
	 
	}
	    
	
	parent::display($tpl);
	}
function ContentPagebreak( &$row, &$pagination,$page=0 )
{

	$regex = '#<hr([^>]*?)class=(\"|\')system-pagebreak(\"|\')([^>]*?)\/*>#iU';

	if(!$page) {
		$page = 0;
	}
	
	$matches = array();
	preg_match_all( $regex, $row->descripcion, $matches, PREG_SET_ORDER );

	$text = preg_split( $regex, $row->descripcion );

	$n = count( $text );

	if ($n > 1)
	{
		if ( $page ) {
			$page_text = $page + 1;
			if ( $page && @$matches[$page-1][2] )
			{
				$attrs = JUtility::parseAttributes($matches[$page-1][1]);

				if ( @$attrs['title'] ) 
				{
				    
					$row->nombre_val = $attrs['title'];
					
				}
			}
		}
		$row->descripcion = '';

		jimport('joomla.html.pagination');
		$pageNav = new JPagination( $n, $page, 1 );

		$text[$page] = str_replace("<hr id=\"\"system-readmore\"\" />", "", $text[$page]);
		$row->description .= $text[$page];

		$pagination .= '<div class="pagenavbar">';
		$pagination .= $pageNav->getPagesLinks();
		$pagination .= '</div>';
		$pagination .= '<div class="pagenavcounter">';
		$pagination .= $pageNav->getPagesCounter();
		$pagination .= '</div>';
	}
	return true;
}

function ContentCreateNavigation( &$row, $page, $n )
{
	$pnSpace = "";
	if (JText::_( '&lt' ) || JText::_( '&gt' )) $pnSpace = " ";

	if ( $page < $n-1 )
	{
		$page_next = $page + 1;

		$link_next = JRoute::_( '&limitstart='. ( $page_next ) );
		// Next >>
		$next = '<a href="'. $link_next .'">' . JText::_( 'Next' ) . $pnSpace . JText::_( '&gt' ) . JText::_( '&gt' ) .'</a>';
	}
	else
	{
		$next = JText::_( 'Next' );
	}

	if ( $page > 0 )
	{
		$page_prev = $page - 1 == 0 ? "" : $page - 1;

		$link_prev = JRoute::_(  '&limitstart='. ( $page_prev) );
		// << Prev
		$prev = '<a href="'. $link_prev .'">'. JText::_( '&lt' ) . JText::_( '&lt' ) . $pnSpace . JText::_( 'Prev' ) .'</a>';
	}
	else
	{
		$prev = JText::_( 'Prev' );
	}

	$row->text .= '<div>' . $prev . ' - ' . $next .'</div>';
}

}

?>