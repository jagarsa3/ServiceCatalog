<?php

defined ('_JEXEC') or die('Restricted access');
$servicio = $this->servicio;

$dbdepende =& JFactory::getDBO();
$querydepende = "SELECT * FROM #__dependencias WHERE IdServHijo='$servicio->id'";
$dbdepende->setQuery( $querydepende);
$rowserverdepende = $dbdepende->loadObjectList();

$db =& JFactory::getDBO();
$query = "SELECT * FROM #__responsableServicio WHERE IdServicio='$servicio->id'";
$db->setQuery( $query);
$rowserver = $db->loadObjectList();

$db_h =& JFactory::getDBO();
$query_h = "SELECT * FROM #__hardwareServicio WHERE IdServicio='$servicio->id'";
$db_h->setQuery( $query_h);
$rowserver_h = $db_h->loadObjectList();


$db_ho =& JFactory::getDBO();
$query_ho = "SELECT * FROM #__hostServicio WHERE IdServicio='$servicio->id'";
$db_ho->setQuery( $query_ho);
$rowserver_ho = $db_ho->loadObjectList();


$db_s =& JFactory::getDBO();
$query_s = "SELECT * FROM #__softwareServicio WHERE IdServicio='$servicio->id'";
$db_s->setQuery( $query_s);
$rowserver_s = $db_s->loadObjectList();

$dbaviso =& JFactory::getDBO();
$queryaviso = "SELECT * FROM #__avisos WHERE IdServicio='$servicio->id'";
$dbaviso->setQuery( $queryaviso);
$rowserveraviso = $dbaviso->loadRow();

$dbdocumentos =& JFactory::getDBO();
$querydocumentos = "SELECT * FROM #__documentosAsociados WHERE IdServicio='$servicio->id'";
$dbdocumentos->setQuery( $querydocumentos);
$rowserverdocumentos = $dbdocumentos->loadObjectList();



$idioma= JRequest::getVar('lang');

// GESTION FECHAS AVISOS






$dia = substr($rowserveraviso[1],8 ,2 );
$mes =   substr($rowserveraviso[1],5 ,2 );
$ano = substr($rowserveraviso[1],0 ,4 );

$fecha_correcta = $dia."-".$mes."-".$ano;


?>
<?php
if($servicio->published=='1'){   
?>
<?php if ($this->params->get( 'show_page_title', 1)) : ?>
<div class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ) ?>">
	<?php echo JText::_('TITULO'); ?>

</div>

<?php endif;
//////////////////////////// REVISAR /////////////////////////
if(!$rowserveraviso )
{
    $fecha_correcta = '31-12-2037';
}

if($servicio->disponibilidad == 0 || restarFechas(date(d."-".m."-".Y),$fecha_correcta)<=0)
{
    echo "<table class='contentpaneopen' cellpadding='0' cellspacing='0' width='100%'><tr><td align='right'";
    if($idoma=="val")
    {
          $link = JURI::base().'index.php?option=com_servicios&view=show&layout=blog&lang=val';
    }
    else
    {
          $link = JURI::base().'index.php?option=com_servicios&view=show&layout=blog&lang=es';
    }
    
    echo "<a href='$link'>";
    echo JText::_( 'Listadodeservicios');
    echo "</a></td></tr></table>";
    //echo "<center><img src='".JURI::base()."components/com_servicios/images/escudo_bombers.jpg' alt='Escudo_Consorcio'/></center>";
    
    echo "<center><h1>";
    echo JText::_('El_servicio_esta_temporalmente_desactivado');
    echo "</h1></center>";
}
else{


?>
<table class="contentpaneopen" cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <tr>
                <td align="right">
                    <?php
                    if($idioma=="val")
                    {
                        $link = JURI::base().'index.php?option=com_servicios&view=show&layout=blog&lang=val';
                    }
                    else
                    {
                        $link = JURI::base().'index.php?option=com_servicios&view=show&layout=blog&lang=es';
                    }
                    
                    ?>
                    <a href="<?php echo $link; ?>"><?php echo JText::_( 'Listadodeservicios'); ?></a>
                </td>
            </tr>
            <td class="contentheading" width="100%">
		<?php
                        if($idioma=="val")
			{
			    
                            $temp = explode(";",$this->row->image_url);
                            if($temp[0]==""){?>
                            <img src="<?php echo JURI::base().'components/com_servicios/images/images.jpeg';?>" alt="error"  align="middle"/>
                            <?php

                            }
                            
                            else{
                                
                                ?>
                            <img src="<?php echo JURI::base().'components/com_servicios/images/'.$temp[0];?>" alt="Imagen" width="70" height="70" align="middle"/>
                            <?php

                            }
                            echo $servicio->nombre_val;

			}
			else
			{

                            $temp = explode(";",$this->row->image_url);
                            if($temp[0]==""){?>
                            <img src="<?php echo JURI::base().'components/com_servicios/images/images.jpeg';?>" alt="error"  align="middle"/>
                            <?php }
                            else{
                                
                                ?>
                            <img src="<?php echo JURI::base().'components/com_servicios/images/'.$temp[0];?>" alt="Imagen" width="70" height="70" align="middle"/>
                            <?php
                            }
                            echo $servicio->nombre_es;

			}
			
		?>
            </td>
            
		</tr>

                
	</table>
<div class="article-inside">
	<table class="contentpaneopen" cellpadding="0" cellspacing="0">
		<?php if ($this->showprice) {?>
        <tr>
            <td valign="top">
                <span class="small"><?php 
				if($servicio->price > 0) echo JText::_('PRICE').'&nbsp;'.$servicio->price; 
				else echo JText::_('NO_PRICE');
				?>
				</span>
            </td>
        </tr>
		<?php }?>
        <tr>
            <td >
                <?php
                        
			if($idioma=="val")
			{
                            echo "<br/>";
			    echo $servicio->descripcion_val;
                            
			}
			else
                        {
                            echo "<br/>";
                            echo $servicio->descripcion_es;
                        }
                        
		?>
            
                 <?php
                    if($rowserveraviso)
                    {
                        echo "<strong><h3><img src='".JURI::base()."components/com_servicios/images/Aviso_Icon.jpeg' width='32' height='32' alt='Icono Aviso' align='middle'/>";
                        echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".JText::_('Disponibilidad_del_Servicio')."</h3</strong>";
			echo $rowserveraviso[2]." [".$rowserveraviso[1]."] - [".$rowserveraviso[4]."]<br/><br/>";

                    }
		?>
                <?php
                if($rowserver)
                {
                    echo "<strong><h3><img src='".JURI::base()."components/com_servicios/images/icon_helpdesk.png' width='32' height='32' alt='Ayuda Servicio'  align='middle'/>";
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".JText::_('Ayuda_del_Servicio')."</h3></strong>";
                    echo JText::_(AYUDA)."<br/>";
                    
                
                foreach($rowserver as $row)
                {
                    $db2 =& JFactory::getDBO();
                    $query2= "SELECT * FROM #__responsable WHERE id='$row->IdResponsable'";
                    $db2->setQuery( $query2);
                    $rowserver2 = $db2->loadRow();
                    echo $rowserver2[1]."<br/>";
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$rowserver2[2]."<br/>";
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$rowserver2[3]."<br/>";
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ".JText::_('Extension').": ".$rowserver2[4]."<br/>";
                }
                echo "<br/>";
                }
                
		?>


                <?php
                if($rowserverdepende)
                {
                    echo "<strong><h3><img src='".JURI::base()."components/com_servicios/images/Dependencias_Icon.jpeg' width='32' height='32' alt='Dependencias Asociadas' align='middle'/>";
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".JText::_('Dependencias_del_Servicio')."</h3></strong>";
                    echo $servicio->nombre_es." ".JText::_('Depende')."<br/>";

                foreach($rowserverdepende as $row)
                {
                    $db2 =& JFactory::getDBO();
                    $query2= "SELECT * FROM #__servicios WHERE id='$row->IdServPadre'";
                    $db2->setQuery( $query2);
                    $rowserver2 = $db2->loadRow();
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$rowserver2[1]."<br/>";
                    //echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$rowserver2[2]."<br/>";
                }
                echo "<br/><br/>";
                }
                ?>

                <?php
                if($rowserver_h)
                {
                    echo "<strong><h3><img src='".JURI::base()."components/com_servicios/images/Hardware_Icon.jpg' width='32' height='32' alt='Hardware Asociado' align='middle'/>";
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".JText::_('Hardware_Asociado_al_Servicio')."</h3></strong>";
                    
                
                foreach($rowserver_h as $row2)
                {
                    $db3 =& JFactory::getDBO();
                    $query3= "SELECT * FROM #__hardware WHERE Id='$row2->IdHw'";
                    $db3->setQuery( $query3);
                    $rowserver3 = $db3->loadRow();
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$rowserver3[2]."<br/>";
                }
                echo "<br/>";
                }
                
                if($rowserver_s)
                {
                echo "<strong><h3><img src='".JURI::base()."components/com_servicios/images/Software_Icon.jpeg' width='32' height='32' alt='Software Asociado'/>";
                echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".JText::_('Software_Asociado_al_Servicio')."</h3></strong>";
                
                
                foreach($rowserver_s as $row)
                {
                    $db2 =& JFactory::getDBO();
                    $query2= "SELECT * FROM #__software WHERE id='$row->IdSw'";
                    $db2->setQuery( $query2);
                    $rowserver4 = $db2->loadRow();
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$rowserver4[1]."<br/>";
                }
               
                


                echo "<br/>";
                 }
		?>

                                <?php
                if($rowserver_ho)
                {
                    echo "<strong><h3><img src='".JURI::base()."components/com_servicios/images/Host_Icon.jpeg' width='32' height='32' alt='Host Asociado' align='middle'/> ";
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".JText::_('Host_Asociado_al_Servicio')."</h3></strong>";
                    
                
                foreach($rowserver_ho as $row)
                {
                    $db4 =& JFactory::getDBO();
                    $query4= "SELECT * FROM #__host WHERE Id='$row->IdHost'";
                    $db4->setQuery( $query4);
                    $rowserver4 = $db4->loadRow();
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$rowserver4[1]."<br/>";
                }
                echo "<br/>";
                echo "<br/><br/>";
                }
		?>


                <?php
                if($rowserverdocumentos)
                {
                    echo "<strong><h3><img src='".JURI::base()."components/com_servicios/images/Documentos_Icon.jpeg' width='32' height='32' alt='Documentos Asociados' align='middle'/>";
                    echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".JText::_('Documentos_Asociado_al_Servicio')."</h3></strong>";
                    
                
                foreach($rowserverdocumentos as $row)
                {
                    //echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;->".$row->Version;
                    echo $row->RutaDoc_es;
                    //echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;->".$row->Fecha."<br/>";
                }
                
                echo "<br/>";
                }
                if ($this->images!= null)
                {
		?>
                <strong><h3><?php echo JText::_('Imagenes_Adjuntas'); ?></h3</strong>
                <?php

		foreach($this->images as $image)
			echo $image;
                }
		?>
                <?php
		  if ($this->files!= null)
		    { ?>

		    <strong><h3><?php echo JText::_('Ficheros_Asociados'); ?></h3</strong>
		    <?}
				foreach($this->files as $file)
					echo "$file <br> \n";

		?>

            </td>

		</tr>

                <tr>
            <td valign="top" class="servicios-gallery">
                
            </td>
        </tr>
		<tr>
            <td valign="top" class="servicios-files">	    
                
            </td>

        </tr>
		<tr>
            <td valign="top" align="center">
        		<?php echo $this->pagination; ?>
            </td>
        </tr>

    </table>
</div>
	<span class="article_separator"></span>
	<?php if ($this->showfooter) echo $this->footer; ?>
<?php
}

} 
else{
	echo JText::_('ITEM_IS_NOT_PUBLISHED');
}



function restarFechas($dFecIni, $dFecFin)
{
	$dFecIni = str_replace("-","",$dFecIni);
	$dFecIni = str_replace("/","",$dFecIni);
	$dFecFin = str_replace("-","",$dFecFin);
	$dFecFin = str_replace("/","",$dFecFin);

	ereg( "([0-9]{1,2})([0-9]{1,2})([0-9]{2,4})", $dFecIni, $aFecIni);
	ereg( "([0-9]{1,2})([0-9]{1,2})([0-9]{2,4})", $dFecFin, $aFecFin);

	$date1 = mktime(0,0,0,$aFecIni[2], $aFecIni[1], $aFecIni[3]);
	$date2 = mktime(0,0,0,$aFecFin[2], $aFecFin[1], $aFecFin[3]);

	return round(($date2 - $date1) / (60 * 60 * 24));
}
?>
