<?php

defined ('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.view');

$idioma= JRequest::getVar('lang');

class serviciosViewShow extends JView

{

	function display($tpl = null)

	{
		global $idioma;
		$idioma= JRequest::getVar('lang');
		global $mainframe;
		$path= JURI::base().'components/com_servicios/helpers/';
		require_once(dirname(__FILE__).DS.'helper.php');
		$document=& JFactory::getDocument();
		$cs = JURI::base().'components/com_servicios/views/show/tmpl/style.css';
		$document->addStyleSheet($cs); 
		
		$model =& $this->getModel();
		$el_id= JRequest::getVar('cid', 0, '', 'int');
		
		$params = &JComponentHelper::getParams( 'com_servicios' );
	
		$menus	= &JSite::getMenu();
		$menu	= $menus->getActive();	

		$lista_all_c=$model->getCategorias();

		if ($el_id=="" || $el_id == 0){
			$lista_servicios = $model->getAllElements();
			$lista_count_servicios=$model->getAllCountElements();
			
			if (is_object( $menu )) {
				$menu_params = new JParameter( $menu->params );
				if (!$menu_params->get( 'page_title')) {
					$params->set('page_title',	JText::_('ALL_ITEMS'));
				}
			} 
			else {
				$params->set('page_title',	JText::_('ALL_ITEMS'));
			}
			
		}
		else {
			$li = $model->getCategoria($el_id);
			$lista_all_c=$model->getCategorias();
			$_list = new TreeHelper();
			$lists = $_list->getList($li,$lista_all_c);
			
			$lista_servicios=$model->getElements($lists);
			$lista_count_servicios=$model->getCountElements($lists);

			if (is_object( $menu )) {
				$menu_params = new JParameter( $menu->params );
				if (!$menu_params->get( 'page_title')) 
				{
                                if($idioma=="val")
				{
				$params->set('page_title',$li->nombre_val);
				}
                                
				else
				{
					$params->set('page_title',$li->nombre_es);
				}
				
				}
			} 
			else 
			{
			if($idioma=="val")
				{
                                $params->set('page_title',$li->nombre_val);
				}
			else
				{
				$params->set('page_title',$li->nombre_es);
				}
		
			}
							
		}
		
		//$document->setTitle( $params->get( 'page_title' ) );
                if($idioma == "val")
                {
                    $document->setTitle("Catàleg de Servicis");
                    
                }
                else{
                    $document->setTitle("Catálogo de Servicios");
                }
		jimport('joomla.html.pagination');
		JHTML::_( 'behavior.modal' );
		
		$limit		= $params->get('limit_servicios_show', 10);
		$limitstart	= JRequest::getVar('limitstart', 0, 'default', 'int');

		$pagination = new JPagination($lista_count_servicios, $limitstart, $limit);

		$us=$params->get('unit_side');
		$se=$params->get('search_servicios');
		$showfooter = $params->get('show_footer');
		$footer = '<div style="margin: 0 auto; clear: both; text-align: center; width: 100%"><br /><a target="_blank" href="http://design-joomla.eu">joomla templates &amp; addons</a></div>';

		
		$app = & JFactory::getApplication();
		$pathway = & $app->getPathway();
		$catpath = $model->getPath($el_id);
		
		$layout = JRequest::getVar('layout', 'default', 'default', 'string');
		
		for ($i = count($catpath) - 1; $i >= 0;  $i--) {
			if($i == 0 || count($catpath) == 1)
			{
			    if($idioma=="val")
			    {
				$pathway->addItem($catpath[$i][nombre_val]);
			    }
			    else
			    {
				$pathway->addItem($catpath[$i][nombre_es]);
			    }
			}
			else
			{
			    if($idioma=="val")
			    {
				$pathway->addItem($catpath[$i][nombre_val], JRoute::_('index.php?option=com_servicios&view=show&layout='.$layout.'&cid='.$catpath[$i][id]));
			    }
			    else
			    {
				$pathway->addItem($catpath[$i][nombre_es], JRoute::_('index.php?option=com_servicios&view=show&layout='.$layout.'&cid='.$catpath[$i][id]));
			    }
			}
		}
		
		$this->assignRef('pagination',$pagination);
		$this->assignRef('servicios',$lista_servicios);
		$this->assignRef('li',$li);
		$this->assignRef('unit_side',$us);
		$this->assignRef('showfooter',$showfooter);
		$this->assignRef('footer',$footer);
		$this->assignRef('search',$se);
		$this->assignRef('params',	$params);
		$this->assignRef('categorias',	$lista_all_c);

        parent::display($tpl);
	}

}




