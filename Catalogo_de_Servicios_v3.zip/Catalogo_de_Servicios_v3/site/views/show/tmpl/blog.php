<?php

defined ('_JEXEC') or die('Restricted access');
$limitstart= JRequest::getVar('limitstart',0);
$cid= JRequest::getVar('cid');
$servicioid = JRequest::getVar('servicioid');
$creador_id = JRequest::getVar('pid');
$idioma= JRequest::getVar('lang');

$dbcat =& JFactory::getDBO();
$querycat = "SELECT * FROM #__categorias";
$dbcat->setQuery( $querycat);
$rowservercat = $dbcat->loadObjectList();


$pid = "";
if($creador_id){
	$pid="&pid=".$creador_id."";
}
$search = JRequest::getVar('search', '', '', 'string');
?>

<?php if ($this->params->get( 'show_page_title', 1)) : ?>
<div class="componentheading<?php echo $this->params->get( 'pageclass_sfx' ) ?>">
	<? echo JText::_('TITULO');?>
</div>
<?php endif; ?>

<div id="filtro">
    <form action=""  name="form_filtrado" id="form_filtrado">
<!--b><? echo JText::_('FILTRAR');?></b>
<select name="select_filtrado" id="select_filtrado" onchange="destino()">
<option value="">Todos los servicios
 <?php
        foreach ($this->categorias as $list_categorias)
        {

	if($idioma=="val")
	{ ?>
	 <option value="<?php echo JURI::base().'index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id.'&lang=val';?>"/> <?= $list_categorias-> nombre_val ; ?>
        <?}
        else
	{
        ?>
        <option value="<?php echo JURI::base().'index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id.'&lang=es';?>"/> <?= $list_categorias-> nombre_es ; ?>
	<? }

        }
        

        ?>

</select-->
</form>

<script type="text/javascript">	

function destino(){

url = document.form_filtrado.select_filtrado.options[document.form_filtrado.select_filtrado.selectedIndex].value

 window.location = url;

}


var global = new Array();

var global_display = new Array();

//global_display[2] = 'none';
//alert(global_display[2]);





</script>
</div>
<br/>




<div id="servicios">
        <table cellpadding="0" cellspacing="0" >
                <tr class="sectiontableheader">
                    <!--td class = "serv_picture" width="10%">&nbsp;
		    <?php //echo JText::_('IMAGEN'); ?>
                    </td-->
                    <td class = "serv_servicio" width="90%">
                        <?php //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&cid='.$cid.'&limitstart='.$limitstart.'&order='.$nameorder.$pid.'&layout='.$layout), JText::_('SERVICIO_NOMBRE'))); ?>
                    </td>
                    <!--td class = "serv_intro">
                        <?php echo JText::_('SHORT_DESCRIPTION'); ?>
                    </td-->
                    
                </tr>
            <?php
						$class = 1;
                                                $i=1;
                                                $cuenta = 1;
                                               
			foreach($rowservercat as $list_e){
				$class = ($class==1)?2:1;
                                
                                $db =& JFactory::getDBO();
                                $id_cat = $list_e->id;
                                $query = "SELECT * FROM #__servicios WHERE idCategoria='$id_cat'";
                                $db->setQuery( $query);
                                $rowserver = $db->loadObjectList();

if($list_e->published==1 && $list_e->parent_id == 0)
//if($list_categorias->published==1)
{
?>
            <tr class="sectiontableentry<?php echo $class;?>">
                <script type="text/javascript">

                    global[<?php echo $i;?>]=1;
                    global_display[<?php echo $i;?>]='none';


                </script>

            
                 <td class = "serv_servicio" >
                 <a style="cursor:pointer" onclick="muestra_oculta('uploader<?php echo $i;?>',global[<?php echo $i;?>],<?php echo $i;?>);">
                    <?
                    
		      if($idioma=="val")
			    {
			      //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_es ));
                                echo "<strong>".$list_e->nombre_val."</strong>";
			    }
			else{
                            //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_val)) ;
                            echo "<strong>".$list_e->nombre_es."</strong>";
                            
                            
                        }

		    ?>
                </a>
                     </td>
            
                
            </tr>
            <tr>
                     <td>
                     <div id="uploader<?php echo $i;?>" style='display:none;'>

                     <?php
                     
                     
                     $dbcat =& JFactory::getDBO();
                     $id_padre = $list_e->id;
                     $querycat = "SELECT * FROM #__categorias WHERE parent_id='$id_padre'";
                     $dbcat->setQuery( $querycat);
                     $rowservercat2 = $dbcat->loadObjectList();


                         foreach($rowservercat2 as $list_b){

                                $db =& JFactory::getDBO();
                                $id_cat2 = $list_b->id;
                                $query = "SELECT * FROM #__servicios WHERE idCategoria='$id_cat2'";
                                $db->setQuery( $query);
                                $rowserver2 = $db->loadObjectList();
                                $i++;
                                $cuenta++;
                                ?>
                             <div id="servicios">
                                <table cellpadding="0" cellspacing="0" >
                                <tr class="sectiontableentry<?php echo $class;?>">
                                <script type="text/javascript">

                                    global[<?php echo $i;?>]=1;
                                    global_display[<?php echo $i;?>]='none';


                                </script>


                                 <td class = "serv_servicio" >
                                 <a style="cursor:pointer" onclick="muestra_oculta('uploader<?php echo $i;?>',global[<?php echo $i;?>],<?php echo $i;?>);">
                                    <?

                                      if($idioma=="val")
                                            {
                                              //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_es ));
                                                echo "<strong>".$list_b->nombre_val."</strong>";
                                            }
                                        else {
                                            //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_val)) ;
                                            echo "<strong>".$list_b->nombre_es."</strong>";


                                        }

                                    ?>
                                </a>
                                     </td>


                            </tr>
                            <tr>
                                <td>
                                <div id="uploader<?php echo $i;?>" style='display:none;'>








                                    


                                    <?php


                                     $dbcat =& JFactory::getDBO();
                                     $id_padre = $list_b->id;
                                     $querycat = "SELECT * FROM #__categorias WHERE parent_id='$id_padre'";
                                     $dbcat->setQuery( $querycat);
                                     $rowservercat3 = $dbcat->loadObjectList();


                                         foreach($rowservercat3 as $list_d){

                                                $db =& JFactory::getDBO();
                                                $id_cat2 = $list_d->id;
                                                $query = "SELECT * FROM #__servicios WHERE idCategoria='$id_cat2'";
                                                $db->setQuery( $query);
                                                $rowserver4 = $db->loadObjectList();
                                                $i++;
                                                $cuenta++;
                                                ?>
                                             <div id="servicios">
                                                <table cellpadding="0" cellspacing="0" >
                                                <tr class="sectiontableentry<?php echo $class;?>">
                                                <script type="text/javascript">

                                                    global[<?php echo $i;?>]=1;
                                                    global_display[<?php echo $i;?>]='none';


                                                </script>


                                                 <td class = "serv_servicio" >
                                                 <a style="cursor:pointer" onclick="muestra_oculta('uploader<?php echo $i;?>',global[<?php echo $i;?>],<?php echo $i;?>);">
                                                    <?

                                                      if($idioma=="val")
                                                            {
                                                              //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_es ));
                                                                echo "<strong>".$list_d->nombre_val."</strong>";
                                                            }
                                                        else {
                                                            //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_val)) ;
                                                            echo "<strong>".$list_d->nombre_es."</strong>";


                                                        }

                                                    ?>
                                                </a>
                                                     </td>


                                            </tr>
                                            <tr>
                                                <td>
                                                <div id="uploader<?php echo $i;?>" style='display:none;'>
                                                     <?php
                                                     foreach($rowserver4 as $list_e){
                                                                echo "<br><table><tr><td class='serv_picture' width = '10%'>";
                                                                $images = explode(";",$list_e->image_url);
                                                                if($list_e->image_url==""){?>
                                                                    <img src="<?php echo JURI::base().'components/com_servicios/images/images.jpeg';?>" alt="error"/>
                                                                <?php }
                                                                else{
                                                                ?>
                                                                <a class="modal" style="display: block;" href="<?php echo JURI::base().'components/com_servicios/images/'.$images[0];?>" target="_blank"><img src="<?php echo JURI::base().'components/com_servicios/images/'.$images[0];?>" style="top: 0;" alt="<?php echo $list_e->nombre_es; ?>"/></a>
                                                                <?php }
                                                                echo "</td><td>";
                                                                if($idioma=="val")
                                                                {
                                                                  //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_es ));
                                                                    echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_e->id.'&cid='.$list_e->idCategoria.'&pid='.$list_e->creador_id.'&lang=val'), $list_e->nombre_val));
                                                                }
                                                                else {
                                                                    //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_val)) ;
                                                                    echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_e->id.'&cid='.$list_e->idCategoria.'&pid='.$list_e->creador_id.'&lang=es'), $list_e->nombre_es));
                                                                }

                                                                
                                                                if($idioma=="val")
                                                                {
                                                                    echo $list_e->intro_desc_val;
                                                               }
                                                               else
                                                               {
                                                                    echo $list_e->intro_desc_es;
                                                                   // echo $list_categorias->intro_desc_es;
                                                                }
                                                               echo "</td></tr></table>";


                                                            }


                                                     ?>

                                                     </div>
                                                     </td>
                                            </tr>
                                             </table>































                                     <?php
                                         }
                                     foreach($rowserver2 as $list_c){
                                                echo "<br><table><tr><td class='serv_picture' width = '10%'>";
                                                $images = explode(";",$list_c->image_url);
                                                if($list_c->image_url==""){?>
                                                    <img src="<?php echo JURI::base().'components/com_servicios/images/images.jpeg';?>" alt="error"/>
                                                <?php }
                                                else{
                                                ?>
                                                <a class="modal" style="display: block;" href="<?php echo JURI::base().'components/com_servicios/images/'.$images[0];?>" target="_blank"><img src="<?php echo JURI::base().'components/com_servicios/images/'.$images[0];?>" style="top: 0;" alt="<?php echo $list_c->nombre_es; ?>"/></a>
                                                <?php }
                                                echo "</td><td>";
                                                if($idioma=="val")
                                                {
                                                  //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_es ));
                                                    echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_c->id.'&cid='.$list_c->idCategoria.'&pid='.$list_c->creador_id.'&lang=val'), $list_c->nombre_val));
                                                }
                                                else {
                                                    //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_val)) ;
                                                    echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_c->id.'&cid='.$list_c->idCategoria.'&pid='.$list_c->creador_id.'&lang=es'), $list_c->nombre_es));
                                                }
                                                if($idioma=="val")
                                                {
                                                    echo $list_c->intro_desc_val;
                                               }

                                                else
                                               {
                                                    echo $list_c->intro_desc_es;
                                                   // echo $list_categorias->intro_desc_es;
                                                }
                                                
                                               echo "</td></tr></table>";


                                            }


                                     ?>

                                     </div>
                                     </td>
                            </tr>
                             </table>
                             </div>
                             <?php

                            }

                     ?>
                     <?php
                     foreach($rowserver as $list_a){
                                echo "<br><table><tr><td class='serv_picture' width = '10%'>";
                                $images = explode(";",$list_a->image_url);
                                if($list_a->image_url==""){?>
                                    <img src="<?php echo JURI::base().'components/com_servicios/images/images.jpeg';?>" alt="error"  width="83" height="71"/>
                                <?php }
				else{

				?>
                                <a class="modal" style="display: block;" href="<?php echo JURI::base().'components/com_servicios/images/'.$images[0];?>" target="_blank"><img src="<?php echo JURI::base().'components/com_servicios/images/'.$images[0];?>" style="top: 0;" alt="<?php echo $list_a->nombre_es; ?>" width="83" height="71"/></a>
                                <?php }
                                echo "</td><td>";
                                if($idioma=="val")
                                {
                                  //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_es ));
                                    echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_a->id.'&cid='.$list_a->idCategoria.'&pid='.$list_a->creador_id.'&lang=val'), $list_a->nombre_val));
                                }
                                else {
                                    //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_val)) ;
                                    echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_a->id.'&cid='.$list_a->idCategoria.'&pid='.$list_a->creador_id.'&lang=es'), $list_a->nombre_es));
                                }
                                if($idioma=="val")
                                {
                                    echo $list_a->intro_desc_val;
                               }

                                else
                               {
                                    echo $list_a->intro_desc_es;
                                   // echo $list_categorias->intro_desc_es;
                                }
                                
                               echo "</td></tr></table>";

                 
                            }
                            $i++;
                            $cuenta++;

                            
                     ?>
                         
                     </div>
                     </td>
            </tr>

                

				<?php if ($this->showprice) { ?>
                <!--td class = "serv_price">
                    <?php
					 	$price = number_format($list_e->price, 2, ',', ' ');

						if($list_e->price > 0) {
							if($this->unit_side) {
								echo $price.'&nbsp;'.$this->price_unit;
							}
							else {
								echo $this->price_unit.'&nbsp;'.$price;
							}
						}
						else echo JText::_('NO_PRICE');

						?>
                </td-->
				<?php }?>
               
            </tr>
<? } ?>
            <?php
		}
            ?>
            <tr>
                <td class="serv_pag" colspan="<?php echo $footerspan;?>">
                    <?php
					echo $this->pagination->getPagesLinks();
					?>
				</td>
            </tr>
        </table>
		<?php if ($this->showfooter) echo $this->footer; ?>
</div>





    <!--div id="servicios_blog"-->
        <?php/*
        foreach ($this->servicios as $list_e)
        {
	if($list_e->published==1)
	{
        ?>
		<div class="contentheading">
        <?php
	if($idioma=="es")
	{
          echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_e->id.'&cid='.$list_e->idCategoria.'&pid='.$list_e->creador_id), $list_e->nombre_es));
	}
	else
	{
	echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_e->id.'&cid='.$list_e->idCategoria.'&pid='.$list_e->creador_id), $list_e->nombre_val));
	}
        ?>
        </div>
        <div class="servicios_blog_servicio">
            <div class="servicios_blog_text">
            	<div class = "servicios_picture_blog">
                <?php
                $images = explode(";", $list_e->image_url);
                if ($list_e->image_url == "") { ?>
                	<img src="<?php echo JURI::base().'components/com_servicios/images/'.'error.jpg';?>" />
                <?php } 
	    else { 
		if($idioma=="es")
		{
		?>
                	<a class="modal" href="<?php echo JURI::base().'components/com_servicios/images/'.$images[0];?>" target="_blank"><img src="<?php echo JURI::base().'components/com_servicios/images/'.$images[0].'.th.jpg'; ?>" style="top: 0;" alt="<?php echo $list_e->nombre_es;  ?>" /></a>
		
                <?php 
		 }
		  
		else
		{?>
		  <a class="modal" href="<?php echo JURI::base().'components/com_servicios/images/'.$images[0];?>" target="_blank"><img src="<?php echo JURI::base().'components/com_servicios/images/'.$images[0].'.th.jpg'; ?>" style="top: 0;" alt="<?php echo $list_e->nombre_val;  ?>" /></a>
		<?}
	    }?>
            </div>
                
                <div class = "servicios_intro_blog">
                    <?php
		    if($idioma=="val")
                    {
			echo $list_e->intro_desc_val;
		    }
		    else
		    {
		      echo $list_e->intro_desc_es;
		     }
                    ?>
                </div>
				<div>
					<a href="<?php echo JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_e->id.'&cid='.$list_e->idCategoria.'&pid='.$list_e->creador_id); ?>" class="readon"><?php echo JText::sprintf('Read more...'); ?></a>
				</div>
            </div>
        </div>
		<div class="clear"> </div>
        <span class="article_separator">&nbsp;</span>
        <?php
	  }
        }
        ?>
    </div>
    <div class="servicios_blog_pagination">
        <?php
        echo $this->pagination->getPagesLinks();
        ?>
    </div>
    <?php
    if ($this->showfooter)
        echo $this->footer;
*/    ?>


    <?php
    // EJEMPLO SERVICIOS HECHO
/*

    	foreach($rowservercat as $list_e){
				$class = ($class==1)?2:1;

if($list_e->published==1)
//if($list_categorias->published==1)
{
?>
            <tr class="sectiontableentry<?php echo $class;?>">



                 <td class = "serv_picture"  >
                    <?php $images = explode(";",$list_e->image_url);
					if($list_e->image_url==""){?>
		   <img src="<?php echo JURI::base().'components/com_servicios/images/'.'error.jpg';?>" alt="error"/>
                    <?php }
					else{
					?>
                    <a class="modal" style="display: block;" href="<?php echo JURI::base().'components/com_servicios/images/'.$images[0];?>" target="_blank"><img src="<?php echo JURI::base().'components/com_servicios/images/'.$images[0].'.ths.jpg';?>" style="top: 0;" alt="<?php echo $list_e->nombre_es; ?>"/></a>
                    <?php } ?>

                </td>

                <td class = "serv_servicio">
                    <?
		      if($idioma=="val")
			    {
			      //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_es ));
                                echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_e->id.'&cid='.$list_e->idCategoria.'&pid='.$list_e->creador_id), $list_e->nombre_val));
			    }
			else {
                            //echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=show&layout=default&cid='.$list_categorias->id),$list_categorias-> nombre_val)) ;
                            echo (JHTML::link(JRoute::_('index.php?option=com_servicios&view=showServicio&id='.$list_e->id.'&cid='.$list_e->idCategoria.'&pid='.$list_e->creador_id), $list_e->nombre_es));

                        }
		    ?>

                    <? if($idioma=="es")
                   {
			echo $list_e->intro_desc_es;
                       // echo $list_categorias->intro_desc_es;
		    }
		    else
		    {
			echo $list_e->intro_desc_val;
		   }
		?>
                </td>
                <!--td class = "serv_intro">

                </td-->
				<?php if ($this->showprice) { ?>
                <!--td class = "serv_price">
                    <?php
					 	$price = number_format($list_e->price, 2, ',', ' ');

						if($list_e->price > 0) {
							if($this->unit_side) {
								echo $price.'&nbsp;'.$this->price_unit;
							}
							else {
								echo $this->price_unit.'&nbsp;'.$price;
							}
						}
						else echo JText::_('NO_PRICE');

						?>
                </td-->
				<?php }?>

            </tr>
<? } ?>
            <?php
		}
            ?>
            <tr>
                <td class="serv_pag" colspan="<?php echo $footerspan;?>">
                    <?php
					echo $this->pagination->getPagesLinks();
					?>
				</td>
            </tr>
        </table>
		<?php if ($this->showfooter) echo $this->footer; ?>
</div>

*/ 

    ?>
    <script type="text/javascript">

                        function muestra_oculta(id,variable,numero){

                            /*var i = 1;
                            for(i=1;i<100;i++)
                                {
                                    var id2 = 'uploader'+i;
                                    if(id2 != id)
                                    {
                                        document.getElementById(id2).style.display = 'none';
                                        //ella.style.display = 'none'
                                    }
                                    
                                }*/
                            var cuenta = "<?php echo $cuenta; ?>";
                            
                            if (document.getElementById){ //se obtiene el id
                                var el = document.getElementById(id); //se define la variable "el" igual a nuestro div
                                
                                
                                if(variable)
                                {

                                    el.style.display = 'block'
                                    for(var i=1;i<cuenta;i++)
                                    {
                                        global_display[i] = 'none';
                                    }
                                    global[numero] = 0;
                                    
                                }
                                else
                                {

                                    el.style.display = 'none'
                                    global[numero] = 1;
                                    
                                }
                                //el.style.display = (el.style.display == 'none') ? 'block' : 'none'; //damos un atributo display:none que oculta el div
                            }
                        }

                        window.onload = function(){/*hace que se cargue la función lo que predetermina que div estará oculto hasta llamar a la función nuevamente*/
                            muestra_oculta('contenido_a_mostrar',variable,numero);/* "contenido_a_mostrar" es el nombre de la etiqueta DIV que deseamos mostrar */
                        }
                        </script>
